package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;

public class Payment2_2Activity extends AppCompatActivity {
    ImageButton btnPayment22Close;
    Button btnPayment22ConnectNow;
    ProgressDialog progressDialog; // Declare ProgressDialog variable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment22);
        addViews();

        progressDialog = new ProgressDialog(this); // Initialize the ProgressDialog

        //back previous screen
        btnPayment22Close.setOnClickListener(v -> onBackPressed());

        // Navigate to Payment2_1Activity
        btnPayment22ConnectNow.setOnClickListener(v -> {
            progressDialog.setMessage("Connecting..."); // Set message for the ProgressDialog
            progressDialog.setCancelable(false); // Make it not cancelable
            progressDialog.show(); // Show the ProgressDialog

            Intent intent = new Intent(Payment2_2Activity.this, Payment2_1Activity.class);
            startActivity(intent);

            progressDialog.dismiss(); // Dismiss the ProgressDialog when the operation is complete

        });
    }

    private void addViews() {
        btnPayment22Close = findViewById(R.id.btnPayment22Close);
        btnPayment22ConnectNow = findViewById(R.id.btnPayment22ConnectNow);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, Payment1Activity.class);
        startActivity(intent);
        finish();
    }
}