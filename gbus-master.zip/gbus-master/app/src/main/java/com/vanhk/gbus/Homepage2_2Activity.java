package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.LocationAdapter;
import com.vanhk.gbus.adapter.TripAdapter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Homepage2_2Activity extends AppCompatActivity {
    ImageView imgHomepage22Back;
    EditText edtHomepage22Search;
    ListView lvHomepage22Locations;
    LocationAdapter locationAdapter;
    String TAG= "FIREBASE";
    DatabaseReference myRef;

    ProgressDialog progressDialog; // Declare ProgressDialog

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage22);
        addViews();
        addEvents();
    }

    public static final String DATABASE_NAME = "GBUS.db";
    public static final String DB_PATH_SUFFIX = "/databases/";
    public static SQLiteDatabase database = null;

    private void copyDataBase(){
        try{
            File dbFile = getDatabasePath(DATABASE_NAME);
            if(!dbFile.exists()){
                if(CopyDBFromAsset()){
                    Log.d("Database","Copy Successful");
                }else{
                    Log.w("Database","Copy Failed");
                }
            }
        }catch (Exception e){
            Log.e("Error: ", e.toString());
        }
    }

    private boolean CopyDBFromAsset() {
        String dbPath = getApplicationInfo().dataDir + DB_PATH_SUFFIX + DATABASE_NAME;
        try {
            InputStream inputStream = getAssets().open(DATABASE_NAME);
            File f = new File(getApplicationInfo().dataDir + DB_PATH_SUFFIX);
            if(!f.exists()){
                f.mkdir();
            }
            OutputStream outputStream = new FileOutputStream(dbPath);
            byte[] buffer = new byte[1024]; int length;
            while((length=inputStream.read(buffer))>0){
                outputStream.write(buffer,0, length);
            }
            outputStream.flush();  outputStream.close(); inputStream.close();
            return  true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void loadLocation() {
        database = openOrCreateDatabase(DATABASE_NAME,MODE_PRIVATE,null);
        Cursor cursor = database.rawQuery("select * from Location", null);
        while (cursor.moveToNext()) {
            String location = cursor.getString(1);
            locationAdapter.add(location);
        }
    }

    private void addEvents() {
        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog

        imgHomepage22Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show ProgressDialog before starting the activity
                progressDialog.setMessage("Loading...");
                progressDialog.show();

                Intent intent=new Intent(Homepage2_2Activity.this, HomepageActivity.class);
                Intent returnIntent = getIntent();
                intent.putExtra("ALocation",returnIntent.getStringExtra("ALocation"));
                intent.putExtra("DLocation",returnIntent.getStringExtra("DLocation"));
                startActivity(intent);

                // Dismiss ProgressDialog after starting the activity
                progressDialog.dismiss();
            }
        });
        lvHomepage22Locations.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String location = locationAdapter.getItem(position);
                Intent intent=new Intent(Homepage2_2Activity.this, HomepageActivity.class);
                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                editor.putString("ALocation",location);
                editor.apply();
                startActivity(intent);
            }
        });
    }

    private void addViews() {
        imgHomepage22Back=findViewById(R.id.imgHomepage22Back);
        edtHomepage22Search=findViewById(R.id.edtHomepage22Search);
        lvHomepage22Locations=findViewById(R.id.lvHomepage22Locations);
        locationAdapter = new LocationAdapter(Homepage2_2Activity.this, R.layout.lvhomepage21location);
        lvHomepage22Locations.setAdapter(locationAdapter);

        copyDataBase();
        loadLocation();
    }
}