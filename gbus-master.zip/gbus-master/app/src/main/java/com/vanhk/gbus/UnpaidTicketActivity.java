package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.UnPaidAdapter;
import com.vanhk.gbus.model.Booked;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.PassengerInfo;
import com.vanhk.gbus.model.Point2;
import com.vanhk.gbus.model.UnPaidTicket;

import java.util.ArrayList;

public class UnpaidTicketActivity extends AppCompatActivity implements UnPaidAdapter.OnCancelTicketClickListener {
    ImageView imgUnpaidTicketBack;
    TextView txtUnpaidTicketUnpaid,txtUnpaidTicketPaid,txtUnpaidTicketCancelled
            ,txtUnpaidTicketDate;
    ListView lvUnpaidTicket;
    UnPaidAdapter unPaidAdapter;

    String TAG = "FIREBASE";

    ArrayList<UnPaidTicket> UnpaidTickets = new ArrayList<>();

    // Declare ProgressDialog variable
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unpaid_ticket);
        // Initialize the progressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable
        addViews();
        addEvents();
    }

    private void addEvents() {
        imgUnpaidTicketBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HomepageActivity.class);
                startActivity(intent);
                finish();
            }
        });
        txtUnpaidTicketPaid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UnpaidTicketActivity.this,PaidTicketActivity.class);
                startActivity(intent);
            }
        });
        txtUnpaidTicketCancelled.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UnpaidTicketActivity.this, CancellationActivity.class);
                startActivity(intent);
            }
        });
    }

    private void addViews() {
        imgUnpaidTicketBack=findViewById(R.id.imgUnpaidTicketBack);
        txtUnpaidTicketUnpaid=findViewById(R.id.txtUnpaidTicketUnpaid);
        txtUnpaidTicketPaid=findViewById(R.id.txtUnpaidTicketPaid);
        txtUnpaidTicketCancelled=findViewById(R.id.txtUnpaidTicketCancelled);
        txtUnpaidTicketDate=findViewById(R.id.txtUnpaidTicketDate);
        lvUnpaidTicket=findViewById(R.id.lvUnpaidTicket);
        unPaidAdapter = new UnPaidAdapter(UnpaidTicketActivity.this, R.layout.lv_unpaid_ticket, UnpaidTickets);
        unPaidAdapter.setonCancelTicketClickListener((UnPaidAdapter.OnCancelTicketClickListener) this);
        lvUnpaidTicket.setAdapter(unPaidAdapter);
        loadData();
    }

    private void loadData() {
        // Show the ProgressDialog
        progressDialog.show();

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String accountId = sharedPreferences.getString("accountId","account1");

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myUnPaidTicket = database.getReference("BookedTicket");
        myUnPaidTicket.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot data : snapshot.getChildren()) {
                    String status = data.child("status").getValue(String.class);
                    String ticketAccountId = data.child("accountId").getValue(String.class);
                    if (accountId.equals(ticketAccountId) && status != null && status.equals("Unpaid")) {
                        String transactionNumber = data.child("TransactionNumber").getValue(String.class);
                        String bookedTime = data.child("bookedTime").getValue(String.class);
                        Booked departureTicket = data.child("departure").getValue(Booked.class);
                        Booked returnTicket = data.child("return").getValue(Booked.class);

                        UnPaidTicket newTicket = new UnPaidTicket();
                        newTicket.set_id(transactionNumber);
                        newTicket.setTransactionNumber(transactionNumber);
                        newTicket.setAccountId(ticketAccountId);
                        newTicket.setDeparture(departureTicket);
                        newTicket.setReturn(returnTicket);
                        newTicket.setBookedTime(bookedTime);

                        unPaidAdapter.add(newTicket);
                        UnpaidTickets.add(newTicket);

                    }
                }
                // Dismiss the ProgressDialog when data loading is complete
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                // Dismiss the ProgressDialog if loading is canceled or fails
                progressDialog.dismiss();
            }
        });
//        DatabaseReference myRef = database.getReference("Tickets");
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                for (DataSnapshot data : snapshot.getChildren()) {
//                    String ticketId = data.getKey();
//                    assert ticketId != null;
//                    // Now you can use the routeId string as needed
//                    if (ticketId.equals("661173fd29cada4e5f00eb41")) {
//                        String timeDepart = data.child("DTime").getValue(String.class);
//                        String dateDepart = data.child("Date").getValue(String.class);
//                        String busDepart = data.child("Bus").getValue(String.class);
//                        // Now you have routeDepart and routeReturn for the specified routeId
//                        // You can use these values as needed
//                        Log.d("TimeDepart", timeDepart);
//                        Log.d("DateDepart", dateDepart);
//                        Log.d("BusDepart", busDepart);
//                    }
//                    // You can add similar conditions for other routeIds as needed
//                    else if (ticketId.equals("661173fd29cada4e5f00eb42")) {
//                        String timeDepartSecond = data.child("DTime").getValue(String.class);
//                        String dateDepartSecond = data.child("Date").getValue(String.class);
//                        String busDepartSecond = data.child("Bus").getValue(String.class);
//                        // Now you have routeDepart and routeReturn for the second specified routeId
//                        // You can use these values as needed
//                        Log.d("TimeDepartSecond", timeDepartSecond);
//                        Log.d("DateDepart", dateDepartSecond);
//                        Log.d("BusDepartSecond", busDepartSecond);
//                    }
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//                // Handle error
//
//            }
//        });
//        myRef = database.getReference("RouteWithPoints");
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                for (DataSnapshot data : snapshot.getChildren()) {
//                    String routeId = data.getKey();
//                    assert routeId != null;
//                    // Now you can use the routeId string as needed
//                    if (routeId.equals("66100befbf18bf63fb4898de")) {
//                        String routeDepart = data.child("ALocation").getValue(String.class);
//                        String routeReturn = data.child("DLocation").getValue(String.class);
//                        // Now you have routeDepart and routeReturn for the specified routeId
//                        // You can use these values as needed
//                        Log.d("RouteDepart", routeDepart);
//                        Log.d("RouteReturn", routeReturn);
//                    }
//                    // You can add similar conditions for other routeIds as needed
//                    else if (routeId.equals("66100f8abf18bf63fb4898e0")) {
//                        String routeDepart = data.child("ALocation").getValue(String.class);
//                        String routeReturn = data.child("DLocation").getValue(String.class);
//                        // Now you have routeDepart and routeReturn for the second specified routeId
//                        // You can use these values as needed
//                        Log.d("RouteDepartSecond", routeDepart);
//                        Log.d("RouteReturnSecond", routeReturn);
//                    }
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//                // Handle error
//
//            }
//        });
    }



    public void onCancelTicketClick(int position) {
        UnPaidTicket unPaidTicket = unPaidAdapter.getItem(position);
    }

}