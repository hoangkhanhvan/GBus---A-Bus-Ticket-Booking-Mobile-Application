package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class SignUp3Activity extends AppCompatActivity {
    EditText edtSignUp3NewPassword;
    EditText edtSignUp3ConfirmNewPassWord;
    Button btnSignUp3Confirm;
    Toolbar toolbarBack;
    FirebaseDatabase database;
    DatabaseReference reference;

    // Declare ProgressDialog variable
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up3);
        addViews();
        addEvents();

        // Initialize the progressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable
    }

    private void addEvents() {
        toolbarBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btnSignUp3Confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show the ProgressDialog when confirm button is clicked
                progressDialog.show();

                String password = edtSignUp3NewPassword.getText().toString().trim();
                String confirmPassword = edtSignUp3ConfirmNewPassWord.getText().toString().trim();

                if (password.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please input your password", Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                } else if (confirmPassword.length() < 8) {
                    Toast.makeText(getApplicationContext(), "Password must have at lease 8 characters", Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                } else {
                    if (password.equals(confirmPassword)) {
                        // Simulate a long-running task (e.g., saving password)
                        saveAccount(password);
                    } else {
                        progressDialog.dismiss(); // Dismiss the ProgressDialog
                        Toast.makeText(SignUp3Activity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        edtSignUp3NewPassword.addTextChangedListener(textWatcher);
        edtSignUp3ConfirmNewPassWord.addTextChangedListener(textWatcher);
    }

    private void saveAccount(String password) {
        database = FirebaseDatabase.getInstance();
        reference = database.getReference("account");
        Map<String, Object> userData = new HashMap<>();
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String email = sharedPreferences.getString("Email","");
        userData.put("accountUserName",email);
        userData.put("accountPassword",password);
        reference.push().setValue(userData).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                String key = reference.getKey();

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("accountId",key);
                editor.apply();
                Intent intent = new Intent(SignUp3Activity.this, HomepageActivity.class);
                startActivity(intent);
            }
        });

        progressDialog.dismiss();
    }

    private void addViews() {
        edtSignUp3ConfirmNewPassWord = findViewById(R.id.edtSignUp3ConfirmNewPassWord);
        edtSignUp3NewPassword = findViewById(R.id.edtSignUp3NewPassword);
        btnSignUp3Confirm = findViewById(R.id.btnSignUp3Confirm);
        toolbarBack = findViewById(R.id.toolbarBack);
    }

    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            if (!edtSignUp3NewPassword.getText().toString().isEmpty() &&
                    !edtSignUp3ConfirmNewPassWord.getText().toString().isEmpty()) {
                btnSignUp3Confirm.setEnabled(true);
            } else {
                btnSignUp3Confirm.setEnabled(false);
            }
        }
    };

    // Simulate task completion after a short delay
}