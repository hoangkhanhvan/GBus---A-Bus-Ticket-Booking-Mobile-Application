package com.vanhk.gbus.model;

import java.util.List;

public class Ticket1 {
    private String transactionNumber;
    private String accountId;
    private String bookedTime;
    private Departure departure;
    private Passenger passenger;
    private Journey returnJourney;
    private String status;

    public Ticket1() {
    }

    public Ticket1(String transactionNumber, String accountId, String bookedTime, Departure departure, Passenger passenger, Journey returnJourney, String status) {
        this.transactionNumber = transactionNumber;
        this.accountId = accountId;
        this.bookedTime = bookedTime;
        this.departure = departure;
        this.passenger = passenger;
        this.returnJourney = returnJourney;
        this.status = status;
    }

    public String getTransactionNumber() {
        return transactionNumber;
    }

    public void setTransactionNumber(String transactionNumber) {
        this.transactionNumber = transactionNumber;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getBookedTime() {
        return bookedTime;
    }

    public void setBookedTime(String bookedTime) {
        this.bookedTime = bookedTime;
    }

    public Departure getDeparture() {
        return departure;
    }

    public void setDeparture(Departure departure) {
        this.departure = departure;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public void setPassenger(Passenger passenger) {
        this.passenger = passenger;
    }

    public Journey getReturnJourney() {
        return returnJourney;
    }

    public void setReturnJourney(Journey returnJourney) {
        this.returnJourney = returnJourney;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Constructor, Getters and Setters

    public static class Departure {
        private String alocation;
        private String bus;
        private String dlocation;
        private Point dropOffPoint;
        private Point pickUpPoint;
        private List<String> seat;
        private TicketInfo ticket;
        private double totalPrice;

        public Departure() {
        }

        public Departure(String alocation, String bus, String dlocation, Point dropOffPoint, Point pickUpPoint, List<String> seat, TicketInfo ticket, double totalPrice) {
            this.alocation = alocation;
            this.bus = bus;
            this.dlocation = dlocation;
            this.dropOffPoint = dropOffPoint;
            this.pickUpPoint = pickUpPoint;
            this.seat = seat;
            this.ticket = ticket;
            this.totalPrice = totalPrice;
        }

        public String getAlocation() {
            return alocation;
        }

        public void setAlocation(String alocation) {
            this.alocation = alocation;
        }

        public String getBus() {
            return bus;
        }

        public void setBus(String bus) {
            this.bus = bus;
        }

        public String getDlocation() {
            return dlocation;
        }

        public void setDlocation(String dlocation) {
            this.dlocation = dlocation;
        }

        public Point getDropOffPoint() {
            return dropOffPoint;
        }

        public void setDropOffPoint(Point dropOffPoint) {
            this.dropOffPoint = dropOffPoint;
        }

        public Point getPickUpPoint() {
            return pickUpPoint;
        }

        public void setPickUpPoint(Point pickUpPoint) {
            this.pickUpPoint = pickUpPoint;
        }

        public List<String> getSeat() {
            return seat;
        }

        public void setSeat(List<String> seat) {
            this.seat = seat;
        }

        public TicketInfo getTicket() {
            return ticket;
        }

        public void setTicket(TicketInfo ticket) {
            this.ticket = ticket;
        }

        public double getTotalPrice() {
            return totalPrice;
        }

        public void setTotalPrice(double totalPrice) {
            this.totalPrice = totalPrice;
        }

        // Constructor, Getters and Setters
    }

    public static class Point {
        private String address;
        private boolean checked;
        private String dateStr;
        private String point;
        private boolean shuttleBus;
        private String time;

        public Point(){}

        public Point(String address, boolean checked, String dateStr, String point, boolean shuttleBus, String time) {
            this.address = address;
            this.checked = checked;
            this.dateStr = dateStr;
            this.point = point;
            this.shuttleBus = shuttleBus;
            this.time = time;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public boolean isChecked() {
            return checked;
        }

        public void setChecked(boolean checked) {
            this.checked = checked;
        }

        public String getDateStr() {
            return dateStr;
        }

        public void setDateStr(String dateStr) {
            this.dateStr = dateStr;
        }

        public String getPoint() {
            return point;
        }

        public void setPoint(String point) {
            this.point = point;
        }

        public boolean isShuttleBus() {
            return shuttleBus;
        }

        public void setShuttleBus(boolean shuttleBus) {
            this.shuttleBus = shuttleBus;
        }

        public String getTime() {
            return time;
        }

        public void setTime(String time) {
            this.time = time;
        }
    }

    public static class TicketInfo {
        private String _id;
        private List<String> amenities;
        private String aoffice;
        private String atime;
        private String bus;
        private String date;
        private String doffice;
        private List<String> driver;
        private String dtime;
        private int price;
        private List<String> reviews;
        private String route;
        private List<String> seat;

        public TicketInfo(){}

        public TicketInfo(String _id, List<String> amenities, String aoffice, String atime, String bus, String date, String doffice, List<String> driver, String dtime, int price, List<String> reviews, String route, List<String> seat) {
            this._id = _id;
            this.amenities = amenities;
            this.aoffice = aoffice;
            this.atime = atime;
            this.bus = bus;
            this.date = date;
            this.doffice = doffice;
            this.driver = driver;
            this.dtime = dtime;
            this.price = price;
            this.reviews = reviews;
            this.route = route;
            this.seat = seat;
        }

        public String get_id() {
            return _id;
        }

        public void set_id(String _id) {
            this._id = _id;
        }

        public List<String> getAmenities() {
            return amenities;
        }

        public void setAmenities(List<String> amenities) {
            this.amenities = amenities;
        }

        public String getAoffice() {
            return aoffice;
        }

        public void setAoffice(String aoffice) {
            this.aoffice = aoffice;
        }

        public String getAtime() {
            return atime;
        }

        public void setAtime(String atime) {
            this.atime = atime;
        }

        public String getBus() {
            return bus;
        }

        public void setBus(String bus) {
            this.bus = bus;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public String getDoffice() {
            return doffice;
        }

        public void setDoffice(String doffice) {
            this.doffice = doffice;
        }

        public List<String> getDriver() {
            return driver;
        }

        public void setDriver(List<String> driver) {
            this.driver = driver;
        }

        public String getDtime() {
            return dtime;
        }

        public void setDtime(String dtime) {
            this.dtime = dtime;
        }

        public int getPrice() {
            return price;
        }

        public void setPrice(int price) {
            this.price = price;
        }

        public List<String> getReviews() {
            return reviews;
        }

        public void setReviews(List<String> reviews) {
            this.reviews = reviews;
        }

        public String getRoute() {
            return route;
        }

        public void setRoute(String route) {
            this.route = route;
        }

        public List<String> getSeat() {
            return seat;
        }

        public void setSeat(List<String> seat) {
            this.seat = seat;
        }

        // Constructor, Getters and Setters
    }

    public static class Passenger {
        private String email;
        private String name;
        private String phoneNumber;
        public Passenger() {}

        public Passenger(String email, String name, String phoneNumber) {
            this.email = email;
            this.name = name;
            this.phoneNumber = phoneNumber;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }
    }

    public static class Journey {
        private String alocation;
        private String bus;
        private String dlocation;
        private Point dropOffPoint;
        private Point pickUpPoint;
        private List<String> seat;
        private TicketInfo ticket;
        private double totalPrice;

        public Journey(String alocation, String bus, String dlocation, Point dropOffPoint, Point pickUpPoint, List<String> seat, TicketInfo ticket, double totalPrice) {
            this.alocation = alocation;
            this.bus = bus;
            this.dlocation = dlocation;
            this.dropOffPoint = dropOffPoint;
            this.pickUpPoint = pickUpPoint;
            this.seat = seat;
            this.ticket = ticket;
            this.totalPrice = totalPrice;
        }

        public String getAlocation() {
            return alocation;
        }

        public void setAlocation(String alocation) {
            this.alocation = alocation;
        }

        public String getBus() {
            return bus;
        }

        public void setBus(String bus) {
            this.bus = bus;
        }

        public String getDlocation() {
            return dlocation;
        }

        public void setDlocation(String dlocation) {
            this.dlocation = dlocation;
        }

        public Point getDropOffPoint() {
            return dropOffPoint;
        }

        public void setDropOffPoint(Point dropOffPoint) {
            this.dropOffPoint = dropOffPoint;
        }

        public Point getPickUpPoint() {
            return pickUpPoint;
        }

        public void setPickUpPoint(Point pickUpPoint) {
            this.pickUpPoint = pickUpPoint;
        }

        public List<String> getSeat() {
            return seat;
        }

        public void setSeat(List<String> seat) {
            this.seat = seat;
        }

        public TicketInfo getTicket() {
            return ticket;
        }

        public void setTicket(TicketInfo ticket) {
            this.ticket = ticket;
        }

        public double getTotalPrice() {
            return totalPrice;
        }

        public void setTotalPrice(double totalPrice) {
            this.totalPrice = totalPrice;
        }
    }

    // Constructor, Getters and Setters for Ticket class
}