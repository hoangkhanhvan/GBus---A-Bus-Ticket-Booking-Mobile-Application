package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import androidx.core.content.ContextCompat;

import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.Ticket;

public class ChooseSeat_Depart_1Activity extends AppCompatActivity implements View.OnClickListener {

    // Declare Buttons for each seat
    private ArrayList<Button> seatButtons = new ArrayList<>();
    private ArrayList<SeatInfo> seatInfoList = new ArrayList<>();
    private ArrayList<String> seats = new ArrayList<>();
    private int totalPrice = 0;
    Ticket selectedTicket;
    ArrayList<String> selectedSeats = new ArrayList<>();
    TextView textView64, textView26, textView29, textView27, textView28;
    ArrayList<String> search;

    ProgressDialog progressDialog; // ProgressDialog instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_seat_depart1);

        // Initialize ProgressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        addViews();
        setupClickListeners();
        initializeSeatInfo();
        updateTotalPrice();

        Button btnBookTickets = findViewById(R.id.btnChooseSeatDepart1Book);
        btnBookTickets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bookTickets();
            }
        });

        // Dismiss the ProgressDialog after initializing views and processing initial data
        progressDialog.dismiss();
    }

    // Phương thức xử lý khi nhấn nút "Book Tickets"
    private void bookTickets() {
        // Chuyển qua PickupDeparture1Activity
        if (selectedSeats.size() < 1) {
            Toast.makeText(this, "Please select a seat", Toast.LENGTH_SHORT).show();
        } else {
            Intent getIntent = getIntent();
            String accountId = getIntent.getStringExtra("accountId");

            Intent intent = new Intent(this, PickupDeparture1Activity.class);
            intent.putExtra("totalPrice", totalPrice);
            intent.putExtra("ticket",selectedTicket);
            intent.putStringArrayListExtra("search",search);

            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            boolean isReturn = sharedPreferences.getBoolean("isReturn",false);
            if (isReturn) {
                editor.putString("RTotalPrice", String.valueOf(totalPrice));
                Set<String> seatSet = new HashSet<>(selectedSeats); // Convert ArrayList to Set
                editor.putStringSet("RSeat", seatSet); // Store the Set in SharedPreferences
            } else {
                editor.putString("DTotalPrice", String.valueOf(totalPrice));
                editor.putString("RTotalPrice", String.valueOf(0));
                Set<String> seatSet = new HashSet<>(selectedSeats); // Convert ArrayList to Set
                editor.putStringSet("DSeat", seatSet); // Store the Set in SharedPreferences
            }
            editor.apply();

            startActivity(intent);
            finish();
        }
    }

    private void initializeSeatInfo() {
        // Initialize seat information, assuming all seats are available and priced at 300000 VND
        for (int i = 0; i < seatButtons.size(); i++) {
            seatInfoList.add(new SeatInfo(i + 1, true, selectedTicket.getPrice()));
        }
    }

    private void updateTotalPrice() {
        // Tính và hiển thị giá tổng
        totalPrice = 0;
        for (SeatInfo seatInfo : seatInfoList) {
            if (!seatInfo.isAvailable()) {
                totalPrice += seatInfo.getPrice();
            }
        }
        TextView txtChooseSeatDepart1Price = findViewById(R.id.txtChooseSeatDepart1Price);
        txtChooseSeatDepart1Price.setText(String.format("%,d VND", totalPrice));
    }

    // Set up click listeners for each seat button
    private void setupClickListeners() {
        for (Button button : seatButtons) {
            button.setOnClickListener(this);
        }
    }

    // Handle click events for each seat button
    @Override
    public void onClick(View v) {
        int seatIndex = seatButtons.indexOf(v);
        if (seatIndex != -1) {
            SeatInfo seatInfo = seatInfoList.get(seatIndex);
            Button button = (Button) v;
            String seatText = button.getText().toString(); // Get the text of the button

            if (seatInfo.isAvailable()) {
                seatInfo.setAvailable(false);
                v.setBackground(ContextCompat.getDrawable(this, R.drawable.ic_seatselected));
                selectedSeats.add(seatText); // Add the text of the button to the array
            } else {
                seatInfo.setAvailable(true);
                v.setBackground(ContextCompat.getDrawable(this, R.drawable.ic_seatavailable));
                selectedSeats.remove(seatText); // Remove the text of the button from the array
            }
            updateTotalPrice(); // Update total price after seat selection/deselection
        }
    }

    // Initialize views
    private void addViews() {
        openDialog();
        // Add buttons for each seat
        seatButtons.add((Button) findViewById(R.id.btnChooseSeatDepart1Enable1A));
        seatButtons.add((Button) findViewById(R.id.btn1b));
        seatButtons.add((Button) findViewById(R.id.btn1c));
        seatButtons.add((Button) findViewById(R.id.btnChooseSeatDepart1Enable1D));
        seatButtons.add((Button) findViewById(R.id.btn2a));
        seatButtons.add((Button) findViewById(R.id.btnChooseSeatDepart1Enable2B));
        seatButtons.add((Button) findViewById(R.id.btn2c));
        seatButtons.add((Button) findViewById(R.id.btn2d));
        seatButtons.add((Button) findViewById(R.id.btn3a));
        seatButtons.add((Button) findViewById(R.id.btnChooseSeatDepart1Enable3B));
        seatButtons.add((Button) findViewById(R.id.btnChooseSeatDepart1Enable3C));
        seatButtons.add((Button) findViewById(R.id.btn3d));
        seatButtons.add((Button) findViewById(R.id.btnChooseSeatDepart1Enable4A));
        seatButtons.add((Button) findViewById(R.id.btnChooseSeatDepart1Enable4B));
        seatButtons.add((Button) findViewById(R.id.btnChooseSeatDepart1Enable4C));
        seatButtons.add((Button) findViewById(R.id.btn4d));
        seatButtons.add((Button) findViewById(R.id.btn5a));
        seatButtons.add((Button) findViewById(R.id.btn5b));
        seatButtons.add((Button) findViewById(R.id.btn5c));
        seatButtons.add((Button) findViewById(R.id.btn5d));

        textView64=findViewById(R.id.textView64);
        textView26=findViewById(R.id.txtTripDetail5DepartLocation);
        textView29=findViewById(R.id.txtTripDetail5ArrivalLocation);
        textView27=findViewById(R.id.textView27);
        textView28=findViewById(R.id.textView28);

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String DLocation = sharedPreferences.getString("DLocation","");
        String ALocation = sharedPreferences.getString("ALocation","");
        String DDate = sharedPreferences.getString("DDate","");
        String RDate = sharedPreferences.getString("RDate","");

        Intent intent = getIntent();
        selectedTicket = (Ticket) intent.getSerializableExtra("ticket");
        search = intent.getStringArrayListExtra("search");
        textView64.setText(selectedTicket.getBus());
        textView26.setText(DLocation);
        textView29.setText(ALocation);
        if (RDate.equals("Select Return Date")) {
            textView27.setText("One Way Trip");
        } else {
            textView27.setText("Round Trip");
        }
        textView28.setText(DDate);

        assert selectedTicket != null;
        seats=selectedTicket.getSeat();

        for (int i = 0; i < seatButtons.size(); i++) {
            String seatCode = seatButtons.get(i).getText().toString();

            GradientDrawable drawable = new GradientDrawable();
            drawable.setCornerRadius(8); // Set the corner radius in pixels
            drawable.setColor(Color.parseColor("#E2E4E7"));

            boolean isSeatExist = false; // Flag to indicate if the seat code exists in the list
            for (int j = 0; j < seats.size(); j++) {
                String existSeatCode = seats.get(j); // Get the seat code from the seats list
                if (seatCode.equals(existSeatCode)) {
                    isSeatExist = true;
                    break; // Exit the loop once a match is found
                }
            }
            // Set text color and background based on seat existence
            if (isSeatExist) {
                seatButtons.get(i).setTextColor(Color.BLACK);
                seatButtons.get(i).setBackground(drawable);
                seatButtons.get(i).setEnabled(false); // Disable the button
            } else {
                seatButtons.get(i).setTextColor(Color.parseColor("#4D56BE"));
                seatButtons.get(i).setBackgroundResource(R.drawable.button_outline);
                seatButtons.get(i).setEnabled(true); // Enable the button
            }
        }

    }

    private void openDialog() {
        final Dialog dialog = new Dialog(ChooseSeat_Depart_1Activity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_seatdeparture0);

        Window window = dialog.getWindow();
        if (window == null) {
            return;
        }

        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.copyFrom(window.getAttributes());
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        layoutParams.gravity = Gravity.BOTTOM;
        layoutParams.horizontalMargin = 0;

        window.setAttributes(layoutParams);

        dialog.setCancelable(true);

        Button btnAgree = dialog.findViewById(R.id.btnSeatDepart1Agree);
        Button btnBack = dialog.findViewById(R.id.btnSeatDepart1Back);

        btnAgree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // User agreed, allow to continue viewing the current screen
                dialog.dismiss(); // Just close the dialog
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(ChooseSeat_Depart_1Activity.this, ResultList1Activity.class);
//                startActivity(intent);
                dialog.dismiss(); // Close the dialog
                finish();
            }
        });

        dialog.show();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, TripDetails1Activity.class);
        startActivity(intent);
        finish();
    }

    public void selectSeat(View view) {
        Button button = (Button) view;

    }

    private static class SeatInfo {
        private int seatNumber;
        private boolean available;
        private int price;

        SeatInfo(int seatNumber, boolean available, int price) {
            this.seatNumber = seatNumber;
            this.available = available;
            this.price = price;
        }

        int getSeatNumber() {
            return seatNumber;
        }

        boolean isAvailable() {
            return available;
        }

        void setAvailable(boolean available) {
            this.available = available;
        }

        int getPrice() {
            return price;
        }
    }
}
