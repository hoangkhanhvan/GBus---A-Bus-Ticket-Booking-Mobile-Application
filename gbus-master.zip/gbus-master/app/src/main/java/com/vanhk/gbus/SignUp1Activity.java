package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.SharedPreferences;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.AccountAdapter;
import com.vanhk.gbus.model.UserHelperClass;
import com.vanhk.gbus.model.UserHelperClass2;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.PasswordAuthentication;

public class SignUp1Activity extends AppCompatActivity {
    EditText edtSignUp1;
    Button btnSignUp1Next;
    Button btnSignUp1Google;
    Toolbar toolbarBack;
    DatabaseReference myRef;
    FirebaseAuth auth;
    FirebaseDatabase database;
    DatabaseReference reference;
    String TAG = "FIREBASE";
    private GoogleSignInClient client;
    private String accountPhoneNumber;
    private String s;

    int emailcode;
    ProgressDialog progressDialog; // Declare ProgressDialog variable

    GoogleSignInClient mGoogleSignInClient;
    int RC_SIGN_IN = 20;

    final String PREF_NAME = "LoginData";

    BroadcastReceiver internetReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Toast.makeText(context, "Internet changed", Toast.LENGTH_LONG).show();
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            if (networkInfo != null && networkInfo.isConnected()) {
                btnSignUp1Next.setEnabled(true);
                btnSignUp1Google.setEnabled(true);
            } else {
                btnSignUp1Next.setBackgroundResource(R.drawable.button_background_disable);
                btnSignUp1Next.setEnabled(false);
                btnSignUp1Google.setEnabled(false);
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up1);
        addViews();
        addEvents();
        setSupportActionBar(toolbarBack);

        // Initialize the progressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable
    }

    private void addViews() {
        edtSignUp1 = findViewById(R.id.edtSignUp1);
        btnSignUp1Next = findViewById(R.id.btnSignUp1Next);
        btnSignUp1Google = findViewById(R.id.btnSignUp1Google);
        toolbarBack = findViewById(R.id.toolbarBack);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("account");
        auth = FirebaseAuth.getInstance();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == 1234) ;
        Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
        try {
            GoogleSignInAccount account = task.getResult(ApiException.class);
            AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
            FirebaseAuth.getInstance().signInWithCredential(credential)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Intent intent = new Intent(getApplicationContext(), HomepageActivity.class);
                                startActivity(intent);

                            } else {
                                Toast.makeText(SignUp1Activity.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    });
        } catch (ApiException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            Intent intent = new Intent(this, HomepageActivity.class);
            startActivity(intent);
        }
    }

    private void addEvents() {
        toolbarBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Create an intent to navigate to the desired screen
                Intent intent = new Intent(SignUp1Activity.this, LoginActivity.class);
                // Start the other activity
                startActivity(intent);
            }
        });


        GoogleSignInOptions options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        client = GoogleSignIn.getClient(this, options);
        btnSignUp1Google.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = client.getSignInIntent();
                startActivityForResult(i, 1234);

            }

        });

        btnSignUp1Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkUserCredentials(edtSignUp1.getText().toString());
            }
        });
    }

    private void checkUserCredentials(String enteredCredential) {
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("account");

        progressDialog.setMessage("Checking account information...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                progressDialog.dismiss();
                boolean found = false;

                for (DataSnapshot data : dataSnapshot.getChildren()) {

                    String userName = data.child("accountUserName").getValue(String.class);

                    if (userName != null && isValidEmail(enteredCredential) && enteredCredential.equals(userName)) {
                        found = true;
                        break;
                    } else if (userName != null && isValidPhoneNumber(enteredCredential) && enteredCredential.equals(userName)) {
                        found = true;
                        break;
                    }
                }

                if (found) {
                    Toast.makeText(getApplicationContext(), "Account is already registered", Toast.LENGTH_LONG).show();
                } else {
                    if (isValidEmail(enteredCredential)) {
                        sendEmail(enteredCredential);
                        editor.putString("Email", enteredCredential); // Assuming userEmail is the correct one to store
                        editor.apply();
                        proceedToSignUp("Email", enteredCredential);
                    } else if (isValidPhoneNumber(enteredCredential)) {
                        proceedToSignUp("Phone",enteredCredential);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Log.w(TAG, "onCancelled", databaseError.toException());
                Toast.makeText(getApplicationContext(), "Error checking account. Please try again later.", Toast.LENGTH_LONG).show();
            }
        });
    }

    private boolean isValidPhoneNumber(String enteredUserName) {
        String phonePattern = "^\\d{10}$";
        return enteredUserName.matches(phonePattern);
    }

    private boolean isValidEmail(String enteredUserName) {
        String emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        return enteredUserName.matches(emailPattern);
    }

    private void proceedToSignUp(String method, String credential) {
        Intent intent;
        if (method.equals("Email")) {
            intent = new Intent(getApplicationContext(), SignUp2_2Activity.class);
        } else {
            intent = new Intent(getApplicationContext(), SignUp2_1Activity.class);
        }
        startActivity(intent);
    }

    private void sendEmail(String email) {
        try {

            String OTP = generateOTP();


            String stringSenderEmail = "gbusbookingapp@gmail.com";
            String stringPasswordSenderEmail = "zfrn jxxy bqfy trtu";

            String stringHost = "smtp.gmail.com";

            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("OTP", OTP);
            editor.putString("Email", email);
            editor.apply();

            Properties properties = System.getProperties();

            properties.put("mail.smtp.host", stringHost);
            properties.put("mail.smtp.port", "465");
            properties.put("mail.smtp.ssl.enable", "true");
            properties.put("mail.smtp.auth", "true");

            javax.mail.Session session = Session.getInstance(properties, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(stringSenderEmail, stringPasswordSenderEmail);
                }
            });

            MimeMessage mimeMessage = new MimeMessage(session);
            mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(email));

            mimeMessage.setSubject("OTP Code Verification");
            mimeMessage.setText("Hello,\n\nYour OTP (One-Time Password) verification code is: " + OTP + "\n\nPlease use this code to verify your identity.\n\nIf you did not request this OTP, please ignore this email.\n\nThank you,\nGBus");

            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Transport.send(mimeMessage);
                    } catch (MessagingException e) {
                        e.printStackTrace();
                    }
                }
            });
            thread.start();

        } catch (AddressException e) {
            e.printStackTrace();
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    private void onClickVerifyPhoneNumber(String accountPhoneNumber) {
        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(auth)
                        .setPhoneNumber(accountPhoneNumber)
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(this)
                        // If no activity is passed, reCAPTCHA verification can not be used.
                        .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                                signInWithPhoneAuthCredential(phoneAuthCredential);
                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                Toast.makeText(SignUp1Activity.this,"Verification Failed", Toast.LENGTH_LONG).show();

                            }

                            @Override
                            public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                super.onCodeSent(s, forceResendingToken);
                                goToSignUp2_1Activity(accountPhoneNumber, s);
                            }
                        })
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);

    }




    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.e(TAG, "signInWithCredential:success");

                            FirebaseUser user = task.getResult().getUser();
                            goToSignUp3Activity(user.getPhoneNumber());

                        } else {
                            // Sign in failed, display a message and update the UI
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                                Toast.makeText(SignUp1Activity.this,"The verification code entered was invalid", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                });
    }

    private void goToSignUp3Activity(String phoneNumber) {
        Intent intent = new Intent(this, SignUp3Activity.class);
        intent.putExtra("mobile", phoneNumber);
        startActivity(intent);
    }

    private void goToSignUp2_1Activity(String accountPhoneNumber, String s) {
        Intent intent=new Intent(SignUp1Activity.this, SignUp2_1Activity.class);
        intent.putExtra("mobile", accountPhoneNumber);
        intent.putExtra("s", s);
        startActivity(intent);
    }

    public static String generateOTP() {
        // Define the length of the OTP
        int otpLength = 4;

        // Generate random digits for the OTP
        Random random = new Random();
        StringBuilder otp = new StringBuilder();

        for (int i = 0; i < otpLength; i++) {
            otp.append(random.nextInt(10)); // Generates a random digit (0-9)
        }

        return otp.toString();
    }
}