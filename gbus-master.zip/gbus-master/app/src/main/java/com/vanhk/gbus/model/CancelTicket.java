package com.vanhk.gbus.model;

import java.io.Serializable;

public class CancelTicket implements Serializable {
    private String BookedTime;
    private String TransactionNumber;
    private String AccountId;
    private String _id;

    public String getBookedTime() {
        return BookedTime;
    }

    public void setBookedTime(String bookedTime) {
        BookedTime = bookedTime;
    }

    public String getTransactionNumber() {
        return TransactionNumber;
    }

    public void setTransactionNumber(String transactionNumber) {
        TransactionNumber = transactionNumber;
    }

    public String getAccountId() {
        return AccountId;
    }

    public void setAccountId(String accountId) {
        AccountId = accountId;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public Booked getDeparture() {
        return Departure;
    }

    public void setDeparture(Booked departure) {
        Departure = departure;
    }

    public Booked getReturn() {
        return Return;
    }

    public void setReturn(Booked aReturn) {
        Return = aReturn;
    }
    private String Status;
    private Booked Departure;
    private Booked Return;

    public CancelTicket() {
    }

    public CancelTicket(String bookedTime, String transactionNumber, String accountId, String _id, String status, Booked departure, Booked aReturn) {
        BookedTime = bookedTime;
        TransactionNumber = transactionNumber;
        AccountId = accountId;
        this._id = _id;
        Status = status;
        Departure = departure;
        Return = aReturn;
    }
}
