package com.vanhk.gbus;

import android.app.Dialog;
import android.app.ProgressDialog; // Import ProgressDialog
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.EditPoint;
import com.vanhk.gbus.adapter.PointAdapter;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.Point;
import com.vanhk.gbus.model.Point2;
import com.vanhk.gbus.model.Ticket;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class EditPickupPoint_Depart1Activity extends AppCompatActivity {
    ImageView imgEditPickupPointDepart1Back;
    ListView lvEditPickupPointDepart1;
    EditPoint pointAdapter;
    String TAG = "FIREBASE";
    ArrayList<Point2> Points;
    Button btnEditPickupPointDepart1Update;
    ProgressDialog progressDialog; // Declare ProgressDialog
    String ticketType, type, routeId;
    Ticket selectedTicket;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_pickup_point_depart1);
        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.show(); // Show ProgressDialog
        addViews();
        addEvents();
    }

    private void addEvents() {
        imgEditPickupPointDepart1Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnEditPickupPointDepart1Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processUpdate();
            }
        });

        lvEditPickupPointDepart1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Point2 point2 = pointAdapter.getItem(position);
                String pointStr = point2.getPoint();
                String address = point2.getAddress();

                for (int i = 0; i < pointAdapter.getCount(); i++) {
                    Point2 pointSelected = pointAdapter.getItem(i);
                    assert pointSelected != null;
                    pointSelected.setChecked(false);
                }
                point2.setChecked(true);
                if (point2.isShuttleBus()) {
                    //Handle open dialog
                }
                Toast.makeText(EditPickupPoint_Depart1Activity.this, pointStr+","+address, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addViews() {
        Intent getIntent = getIntent();
        routeId = getIntent.getStringExtra("Route");
        type = getIntent.getStringExtra("Type");
        ticketType = getIntent.getStringExtra("TicketType");
        selectedTicket = (Ticket) getIntent.getSerializableExtra("Ticket");

        imgEditPickupPointDepart1Back = findViewById(R.id.imgEditPickupPointDepart1Back);
        lvEditPickupPointDepart1 = findViewById(R.id.lvEditPickupPointDepart1);
        btnEditPickupPointDepart1Update = findViewById(R.id.btnEditPickupPointDepart1Update);

        Points = new ArrayList<>();

        pointAdapter = new EditPoint(EditPickupPoint_Depart1Activity.this, R.layout.lv_editpickuppoint_depart1_shuttlebus_edt,Points);
        lvEditPickupPointDepart1.setAdapter(pointAdapter);
        loadData();
    }

    private void loadData() {


        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String DLocation = sharedPreferences.getString("DLocation","");
        String ALocation = sharedPreferences.getString("ALocation","");
        String DDate = sharedPreferences.getString("DDate","");
        String RDate = sharedPreferences.getString("RDate","");

        TextView txtEditPickupPointDepart1BusName = findViewById(R.id.txtEditPickupPointDepart1BusName);
        TextView txtEditPickupPointDepart1DepartLocation = findViewById(R.id.txtEditPickupPointDepart1DepartLocation);
        TextView txtEditPickupPointDepart1ReturnLocation = findViewById(R.id.txtEditPickupPointDepart1ReturnLocation);
        TextView txtEditPickupPointDepart1TagTripType = findViewById(R.id.txtEditPickupPointDepart1TagTripType);
        TextView txtEditPickupPointDepart1Date = findViewById(R.id.txtEditPickupPointDepart1Date);

        txtEditPickupPointDepart1BusName.setText(selectedTicket.getBus());
        txtEditPickupPointDepart1DepartLocation.setText(DLocation);
        txtEditPickupPointDepart1ReturnLocation.setText(ALocation);
        txtEditPickupPointDepart1Date.setText(DDate);
        if (RDate.equals("Select Return Date")) {
            txtEditPickupPointDepart1TagTripType.setText("One Way Trip");
        } else {
            txtEditPickupPointDepart1TagTripType.setText("Round Trip");
        }

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("RouteWithPoints");
        ArrayList<Point2> count = new ArrayList<>();
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot data : dataSnapshot.getChildren()) {

                    String _id = data.child("_id").getValue(String.class);
                    if (_id.equals(routeId)) {
                        for (DataSnapshot points : data.child(type).getChildren()) {
                            Point2 point = new Point2();
                            Long time = points.child("Time").getValue(Long.class);
                            if (time != null) {
                                point.setPoint(points.child("Point").getValue(String.class));
                                point.setAddress(points.child("Address").getValue(String.class));
                                point.setShuttleBus(points.child("ShuttleBus").getValue(Boolean.class));
                                String timeStr = calculateTime(selectedTicket.getDTime(),time.intValue());
                                point.setTime(timeStr);
                                String dateStr = calculateDate(selectedTicket.getDate(),selectedTicket.getDTime(),time.intValue());
                                point.setDateStr(dateStr);
                                pointAdapter.add(point);
                                count.add(point);
                            }

                        }
                    }

                }
                progressDialog.dismiss(); // Dismiss the ProgressDialog after loading data
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e(TAG, "loadPost:onCancelled", databaseError.toException());
                progressDialog.dismiss(); // Dismiss the ProgressDialog in case of error
            }
        });

    }

    public static String calculateDate(String dateString, String timeString, int minutesToAdd) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(dateFormat.parse(dateString + " " + timeString));
            calendar.add(Calendar.MINUTE, minutesToAdd);
            SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd/MM");
            return outputDateFormat.format(calendar.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String calculateTime(String timeString, int minutesToAdd) {
        // Split the time string into hours and minutes
        String[] parts = timeString.split(":");
        int hours = Integer.parseInt(parts[0]);
        int minutes = Integer.parseInt(parts[1]);

        // Convert time to minutes
        int totalMinutes = hours * 60 + minutes;

        // Add the minutes
        totalMinutes += minutesToAdd;

        // Adjust if the total minutes is negative
        if (totalMinutes < 0) {
            totalMinutes += 24 * 60; // Add 24 hours worth of minutes
        }

        // Calculate the new hours and minutes
        int newHours = totalMinutes / 60;
        int newMinutes = totalMinutes % 60;

        // Format the new time
        String newTimeString = String.format("%02d:%02d", newHours, newMinutes);
        return newTimeString;
    }

    // Method to open custom dialog
    private void openCustomDialog(Point2 point) {
        // Implement your custom dialog here to input information related to the shuttle service
        final Dialog dialog = new Dialog(EditPickupPoint_Depart1Activity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.activity_dropoff_return3);

        Window window = dialog.getWindow();
        if (window == null){
            return;
        }

        WindowManager.LayoutParams windowAttribute = window.getAttributes();
        windowAttribute.gravity = Gravity.CENTER;
        window.setAttributes(windowAttribute);

        dialog.setCancelable(true);

        EditText edtInputShuttleLocation = dialog.findViewById(R.id.edtDropOffReturn3);
        Button btnSave = dialog.findViewById(R.id.btnDropOffReturn3Confirm);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ContentValues record = new ContentValues();

                String date = (new Date()).toString();

                record.put("ShuttleLocation", edtInputShuttleLocation.getText().toString());
//                long result = record.insert("PickUpPoints", null, record);
//                if (result > 0) {
//                    Toast.makeText(EditPickupPoint_Depart1Activity.this,"Yes you did it!",Toast.LENGTH_LONG).show();
//                }
            }
        });
        dialog.show();
    }

    private void processUpdate() {
        Point2 selectedPoint = pointAdapter.getSelectedPoint();
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        boolean isReturn = sharedPreferences.getBoolean("isReturn",false);
        if (ticketType.equals("Depart")) {
            if (type.equals("PickUpPoints")) {
                MySharedPreferences.saveObject(getApplicationContext(), "DPickUpPoint", selectedPoint);
            } else {
                MySharedPreferences.saveObject(getApplicationContext(), "DDropOffPoint", selectedPoint);
            }
        } else {
            if (type.equals("PickUpPoints")) {
                MySharedPreferences.saveObject(getApplicationContext(), "RPickUpPoint", selectedPoint);
            } else {
                MySharedPreferences.saveObject(getApplicationContext(), "RDropOffPoint", selectedPoint);
            }
        }



        finish();
    }

//    public static String calculateDate(String dateString, String timeString, int minutesToAdd) {
//        try {
//            // Parse the input date and time strings
//            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
//            Calendar calendar = Calendar.getInstance();
//            calendar.setTime(dateFormat.parse(dateString + " " + timeString));
//
//            // Add the minutes
//            calendar.add(Calendar.MINUTE, minutesToAdd);
//
//            // Get the updated date
//            SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd/MM");
//            return outputDateFormat.format(calendar.getTime());
//        } catch (ParseException e) {
//            e.printStackTrace();
//            return null; // Return null if parsing fails
//        }
//    }
}
