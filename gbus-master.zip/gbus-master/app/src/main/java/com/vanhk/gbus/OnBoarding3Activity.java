package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class OnBoarding3Activity extends AppCompatActivity {
    Button btnOnBoarding3Skip, btnOnBoarding3GotIt;
    ProgressDialog progressDialog; // Declare ProgressDialog

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_on_boarding3);
        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog
        progressDialog.setMessage("Processing...");
        progressDialog.setCancelable(false);
        addViews();
        addEvents();
    }

    private void addEvents() {
        btnOnBoarding3Skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show(); // Show ProgressDialog when skip button is clicked
                processSkip();
            }
        });
        btnOnBoarding3GotIt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show(); // Show ProgressDialog when got it button is clicked
                processGotIt();
            }
        });
    }

    private void processGotIt() {
        Intent intent=new Intent(OnBoarding3Activity.this, LoginActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        progressDialog.dismiss(); // Dismiss ProgressDialog after starting the login activity
    }

    private void processSkip() {
        Intent intent=new Intent(OnBoarding3Activity.this,LoginActivity.class);
        startActivity(intent);
        progressDialog.dismiss(); // Dismiss ProgressDialog after starting the login activity
    }

    private void addViews() {
        btnOnBoarding3Skip=findViewById(R.id.btnOnBoarding3Skip);
        btnOnBoarding3GotIt=findViewById(R.id.btnOnBoarding3GotIt);
    }
}
