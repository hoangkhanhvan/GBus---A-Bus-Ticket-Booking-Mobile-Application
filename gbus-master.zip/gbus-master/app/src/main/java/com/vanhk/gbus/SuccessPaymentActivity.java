package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.Payment;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class SuccessPaymentActivity extends AppCompatActivity {
    TextView txtPaymentSuccessfulPrice, txtPaymentSuccessfulTimestamp, txtPaymentSuccessfulPaymentMethod, txtPaymentSuccessfulTransactionNo;
    Button btnPaymentSuccessfulViewInvoice, btnPaymentSuccessfulBackToHomepage;

    // Declare ProgressDialog variable
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success_payment);

        addViews();
        addEvents();
        changeOrderStatus();

        subtractVoucher();

        // Initialize the progressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable
    }

    private void changeOrderStatus() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("BookedTicket");

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String transactionNumber = sharedPreferences.getString("TransactionNumber","");
        Toast.makeText(this, transactionNumber, Toast.LENGTH_SHORT).show();

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot data: snapshot.getChildren()) {
                    String transaction_id = data.child("TransactionNumber").getValue(String.class);

                    if (transaction_id!=null && transaction_id.equals(transactionNumber)) {
                        // Get a reference to the "status" path
                        DatabaseReference statusRef = data.getRef().child("status");
                        statusRef.setValue("Paid");
                        // Set the value for the "status" path to "Paid"
                        //statusRef.setValue("Paid");
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    private void addEvents() {
        btnPaymentSuccessfulViewInvoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                String transactionNumber = sharedPreferences.getString("TransactionNumber","");

                editor.putString("BookedTicketId",transactionNumber);
                editor.apply();

                Intent intent = new Intent(SuccessPaymentActivity.this, ViewInvoice_UpcomingActivity.class);
                startActivity(intent);

                // Dismiss the ProgressDialog after starting the new activity

            }
        });

        btnPaymentSuccessfulBackToHomepage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SuccessPaymentActivity.this, HomepageActivity.class);
                startActivity(intent);
            }
        });
    }
    private static final String CHANNEL_ID = "BOOKING";
    private void showNotification() {
        // Create an explicit intent for the activity you want to open when the notification is clicked

        // Create a notification builder
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_payment_2_2_gbus_logo)
                .setContentTitle("Payment success")
                .setContentText("Your Ticket is confirmed by the system!")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // Check if device is running Android Oreo or higher
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Create the notification channel
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, "Channel Name", NotificationManager.IMPORTANCE_HIGH);
            notificationChannel.enableVibration(true);
            notificationManager.createNotificationChannel(notificationChannel);
        }

        // Notify the system to display the notification
        notificationManager.notify(0, builder.build());
    }

    private void subtractVoucher() {
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String voucherId = sharedPreferences.getString("voucherChecked","");

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Vouchers");

        // Listen for a single snapshot of the voucher data
        myRef.child(voucherId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Long amount = snapshot.child("amount").getValue(Long.class);
                    if (amount != null && amount > 0) {
                        int newAmount = amount.intValue() - 1; // Decrement the amount by 1
                        // Set the new amount only after fetching and decrementing
                        myRef.child(voucherId).child("amount").setValue(newAmount);
                    } else {
                        Log.d("Voucher Error", "Voucher amount is null or zero");
                    }
                } else {
                    Log.d("Voucher Error", "Voucher does not exist");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.d("Firebase Error", "Failed to read voucher: " + error.getMessage());
            }
        });
    }



    private void saveNotification(String DLocation, String ALocation, String accountId) {
        long negatedTimestamp = -1 * new Date().getTime();
        String ticketKey = Long.toString(negatedTimestamp);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Notification");

        Map<String, Object> userData = new HashMap<>();
        userData.put("Description", "Your ticket from " +DLocation+ " to "+ALocation+" has been confirmed by the system. View to see detail.");
        userData.put("Image","data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAE1SURBVHgB7Za9agJBEMf/e1hESGGOFPkqlCRFCKkSrAJpErAKpEmRJs/gG+gb+BQWNoKVYCVYiZ2Ihcid4FchaiGoIJ67W3qz5y3cFYI/GLib3dnZmd2dXWb1nP+tgxyAGILFNhgyrGs7Fv+JIxzmRoiDC2IGQub4HURUDfXGGH6JRiN4eb7076BcsblY0CH1FeeScOnJFE1nK0oN0zyTQtusSb3WGqQ+E0i+XumY0Cm6vTknO+cLbah4uKcLARnBx/sdmc/k27WUfURfVWTKXQQ4PnVeekDUIldrtdZHsdSBDj/fjzLyfcgUDYYLSi1T8ff7BB0bjxS5qTdG0IV0YF6o9jp9PqSN4nyQayBotiZYLjfwg1epUDoIitN9cNgB4xczQoKJlwV/sqTFBwJGTJyPnd0BIcJSBzUR3fwAAAAASUVORK5CYII=");
        userData.put("Timestamp", new Date().getTime());
        userData.put("Title", "Your ticket is confirmed");
        userData.put("_id", accountId+new Date().getTime());

        DatabaseReference newNotificationRef = myRef.child(accountId).child(ticketKey);
        newNotificationRef.setValue(userData);
    }

    private void addViews() {
        txtPaymentSuccessfulPrice=findViewById(R.id.txtPaymentSuccessfulPrice);
        txtPaymentSuccessfulTimestamp=findViewById(R.id.txtPaymentSuccessfulTimestamp);
        txtPaymentSuccessfulPaymentMethod=findViewById(R.id.txtPaymentSuccessfulPaymentMethod);
        txtPaymentSuccessfulTransactionNo=findViewById(R.id.txtPaymentSuccessfulTransactionNo);
        btnPaymentSuccessfulViewInvoice=findViewById(R.id.btnPaymentSuccessfulViewInvoice);
        btnPaymentSuccessfulBackToHomepage=findViewById(R.id.btnPaymentSuccessfulBackToHomepage);

        Intent getIntent = getIntent();
        String totalPrice = getIntent.getStringExtra("discountPrice");
        if (totalPrice != null) {
            txtPaymentSuccessfulPrice.setText(totalPrice);
        }
        txtPaymentSuccessfulTimestamp.setText(getCurrentDateFormatted());
        Payment selectedPayment = MySharedPreferences.getObject(this,"PaymentMethod",Payment.class);
        if (selectedPayment != null && selectedPayment.getMethod() != null) {
            txtPaymentSuccessfulPaymentMethod.setText(selectedPayment.getMethod());
        } else {
            txtPaymentSuccessfulPaymentMethod.setText("Momo");
        }

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String transactionNumber = sharedPreferences.getString("TransactionNumber","");
        txtPaymentSuccessfulTransactionNo.setText(transactionNumber);

        String DLocation = sharedPreferences.getString("DLocation", "");
        String ALocation = sharedPreferences.getString("ALocation", "");
        String accountId = sharedPreferences.getString("accountId", "");
        showNotification();
        saveNotification(DLocation, ALocation, accountId);
    }

    public String getCurrentDateFormatted() {
        // Create a SimpleDateFormat object with the desired format
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy 'at' hh:mm a", Locale.US);

        // Get the current date and time
        Date currentDate = new Date();

        // Format the current date and return it as a string
        return dateFormat.format(currentDate);
    }

    private void clearVoucherFromFirebase() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference voucherRef = database.getReference("Vouchers");

        // Lấy TransactionNumber từ SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String transactionNumber = sharedPreferences.getString("TransactionNumber", "");

        // Xóa voucher dựa trên TransactionNumber
        voucherRef.child(transactionNumber).removeValue(new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(@Nullable DatabaseError error, @NonNull DatabaseReference ref) {
                if (error != null) {
                    Log.e("Firebase", "Error deleting voucher: " + error.getMessage());
                } else {
                    // Xóa voucher thành công
                    Log.d("Firebase", "Voucher deleted successfully");
                }
            }
        });
    }
}