package com.vanhk.gbus.model;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;

public class MySharedPreferences {
    private static final String PREF_NAME = "MyPrefs";

    // Save object to SharedPreferences
    public static void saveObject(Context context, String key, Object object) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        Gson gson = new Gson();
        String serializedObject = gson.toJson(object);
        editor.putString(key, serializedObject);
        editor.apply();
    }

    // Retrieve object from SharedPreferences
    public static <T> T getObject(Context context, String key, Class<T> classOfT) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String serializedObject = sharedPreferences.getString(key, null);

        if (serializedObject != null) {
            Gson gson = new Gson();
            return gson.fromJson(serializedObject, classOfT);
        } else {
            return null;
        }
    }
}
