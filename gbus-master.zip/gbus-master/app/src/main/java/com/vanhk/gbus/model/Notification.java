package com.vanhk.gbus.model;

import android.graphics.Bitmap;

public class Notification {
    private String Description;
    private String Title;
    private Bitmap Image;
    private String _id;
    private long Timestamp;

    public Notification(String description, String title, Bitmap image, String _id, long timestamp) {
        Description = description;
        Title = title;
        Image = image;
        this._id = _id;
        Timestamp = timestamp;
    }

    public Notification(){

    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public Bitmap getImage() {
        return Image;
    }

    public void setImage(Bitmap image) {
        Image = image;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public long getTimestamp() {
        return Timestamp;
    }

    public void setTimestamp(long timestamp) {
        Timestamp = timestamp;
    }
}
