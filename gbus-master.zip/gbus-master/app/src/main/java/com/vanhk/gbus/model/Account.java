package com.vanhk.gbus.model;

public class Account {
    private String accounId;
    private String accountPhoneNumber;
    private String accountName;
    private String accountPassword;
    private String accountType;
    private String accountUserName;

    public Account(String accounId, String accountPhoneNumber, String accountName, String accountPassword, String accountType, String accountUserName) {
        this.accounId = accounId;
        this.accountPhoneNumber = accountPhoneNumber;
        this.accountName = accountName;
        this.accountPassword = accountPassword;
        this.accountType = accountType;
        this.accountUserName = accountUserName;
    }

    public Account() {
    }

    public String getAccounId() {
        return accounId;
    }

    public void setAccounId(String accounId) {
        this.accounId = accounId;
    }

    public String getAccountPhoneNumber() {
        return accountPhoneNumber;
    }

    public void setAccountPhoneNumber(String act) {
        this.accountPhoneNumber = accountPhoneNumber;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getAccountPassword() {
        return accountPassword;
    }

    public void setAccountPassword(String accountPassword) {
        this.accountPassword = accountPassword;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getAccountUserName() {
        return accountUserName;
    }

    public void setAccountUserName(String accountUserName) {
        this.accountUserName = accountUserName;
    }
}
