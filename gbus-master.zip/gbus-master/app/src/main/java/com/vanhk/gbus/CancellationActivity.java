package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.CancelTicketAdapter;
import com.vanhk.gbus.adapter.UnPaidAdapter;
import com.vanhk.gbus.model.Booked;
import com.vanhk.gbus.model.CancelTicket;
import com.vanhk.gbus.model.UnPaidTicket;

import java.util.ArrayList;

public class CancellationActivity extends AppCompatActivity implements CancelTicketAdapter.OnRepurchaseClickListener{
    ImageView imgCancallationBack;
    TextView txtCancellationUnpaid,txtCancellationPaid,txtCancellationCancelled;
    TextView txtCancellationDate;
    ListView lvCancellation;
    CancelTicketAdapter cancelTicketAdapter;

    String TAG = "FIREBASE";

    ProgressDialog progressDialog; // ProgressDialog instance

    ArrayList<CancelTicket> CancelTickets = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancellation);

        progressDialog = new ProgressDialog(this); // Initialize progressDialog
        progressDialog.setMessage("Loading Data..."); // Set message for progressDialog
        progressDialog.setCancelable(false); // Make progressDialog not cancellable
        progressDialog.show(); // Show progressDialog when activity starts
        addViews();
        addEvents();
    }

    private void addEvents() {
        imgCancallationBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HomepageActivity.class);
                startActivity(intent);
                finish();
            }
        });
        txtCancellationUnpaid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CancellationActivity.this,UnpaidTicketActivity.class);
                startActivity(intent);
                finish();
            }
        });
        txtCancellationPaid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CancellationActivity.this,PaidTicketActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void addViews() {
        imgCancallationBack=findViewById(R.id.imgCancallationBack);
        txtCancellationUnpaid=findViewById(R.id.txtCancellationUnpaid);
        txtCancellationPaid=findViewById(R.id.txtCancellationPaid);
        txtCancellationCancelled=findViewById(R.id.txtPaidTicketCancelled);

        lvCancellation=findViewById(R.id.lvCancellation);
        cancelTicketAdapter = new CancelTicketAdapter(CancellationActivity.this, R.layout.lv_cancellation, CancelTickets);
        cancelTicketAdapter.setonRepurchaseClickListener((CancelTicketAdapter.OnRepurchaseClickListener) this);
        lvCancellation.setAdapter(cancelTicketAdapter);
        loadData();

    }

    private void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String accountId = sharedPreferences.getString("accountId","account1");

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myCancellationTicket = database.getReference("BookedTicket");
        myCancellationTicket.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                progressDialog.dismiss(); // Dismiss progressDialog after data loading is complete
                for (DataSnapshot data : snapshot.getChildren()) {
                    String status = data.child("status").getValue(String.class);
                    String ticketAccountId = data.child("accountId").getValue(String.class);
                    Toast.makeText(CancellationActivity.this, status, Toast.LENGTH_SHORT).show();
                    if (accountId.equals(ticketAccountId) && status != null && status.equals("Cancel")) {
                        String transactionNumber = data.child("TransactionNumber").getValue(String.class);
                        String bookedTime = data.child("bookedTime").getValue(String.class);
                        Booked departureTicket = data.child("departure").getValue(Booked.class);
                        Booked returnTicket = data.child("return").getValue(Booked.class);

                        CancelTicket cancelNewTicket = new CancelTicket();
                        cancelNewTicket.set_id(transactionNumber);
                        cancelNewTicket.setTransactionNumber(transactionNumber);
                        cancelNewTicket.setAccountId(ticketAccountId);
                        cancelNewTicket.setDeparture(departureTicket);
                        cancelNewTicket.setReturn(returnTicket);
                        cancelNewTicket.setBookedTime(bookedTime);

                        cancelTicketAdapter.add(cancelNewTicket);
                        CancelTickets.add(cancelNewTicket);

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss(); // Dismiss progressDialog if data loading is cancelled
                Toast.makeText(CancellationActivity.this, "Failed to load data", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void onRepurchaseClick(int position) {
        CancelTicket cancelTicket = cancelTicketAdapter.getItem(position);
        Intent getIntent = getIntent();
        String accountId = getIntent().getStringExtra("accountId");
        Intent intent = new Intent(CancellationActivity.this,BookingPreview1Activity.class);
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("bookedTicketId",cancelTicket.get_id());
        editor.apply();

        intent.putExtra("BookedTicket", cancelTicket);
        Object MySharedPreferences = null;

        startActivity(intent);
    }
}