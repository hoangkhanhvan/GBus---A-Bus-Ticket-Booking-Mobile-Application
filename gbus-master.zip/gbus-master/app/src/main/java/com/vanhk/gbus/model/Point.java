package com.vanhk.gbus.model;

public class Point {
    private String Point;

    private String Date;

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public Point(String point, String address, String time, boolean shuttleBus, String date) {
        Point = point;
        Address = address;
        Time = time;
        Date = date;
        ShuttleBus = shuttleBus;
    }

    private String Address;

    public Point() {
    }

    public String getPoint() {
        return Point;
    }

    public void setPoint(String point) {
        Point = point;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public boolean isShuttleBus() {
        return ShuttleBus;
    }

    public void setShuttleBus(boolean shuttleBus) {
        ShuttleBus = shuttleBus;
    }

    private String Time;
    private boolean ShuttleBus;
}
