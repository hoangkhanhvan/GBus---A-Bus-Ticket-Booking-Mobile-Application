package com.vanhk.gbus.model;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

public class Booked implements Serializable {
    private Ticket Ticket;

    public Booked() {
    }

    public com.vanhk.gbus.model.Ticket getTicket() {
        return Ticket;
    }

    public void setTicket(com.vanhk.gbus.model.Ticket ticket) {
        Ticket = ticket;
    }

    public int getTotalPrice() {
        return TotalPrice;
    }

    public void setTotalPrice(int totalPrice) {
        TotalPrice = totalPrice;
    }

    public List<String> getSeat() {
        return Seat;
    }

    public void setSeat(List<String> seat) {
        Seat = seat;
    }

    public Point2 getPickUpPoint() {
        return PickUpPoint;
    }

    public void setPickUpPoint(Point2 pickUpPoint) {
        PickUpPoint = pickUpPoint;
    }

    public Point2 getDropOffPoint() {
        return DropOffPoint;
    }

    public void setDropOffPoint(Point2 dropOffPoint) {
        DropOffPoint = dropOffPoint;
    }

    public String getBus() {
        return Bus;
    }

    public void setBus(String bus) {
        Bus = bus;
    }

    public String getDLocation() {
        return DLocation;
    }

    public void setDLocation(String DLocation) {
        this.DLocation = DLocation;
    }

    public String getALocation() {
        return ALocation;
    }

    public void setALocation(String ALocation) {
        this.ALocation = ALocation;
    }

    private int TotalPrice;
    private List<String> Seat;
    private Point2 PickUpPoint;
    private Point2 DropOffPoint;
    private String Bus;

    public Booked(com.vanhk.gbus.model.Ticket ticket, int totalPrice, List<String> seat, Point2 pickUpPoint, Point2 dropOffPoint, String bus, String DLocation, String ALocation) {
        Ticket = ticket;
        TotalPrice = totalPrice;
        Seat = seat;
        PickUpPoint = pickUpPoint;
        DropOffPoint = dropOffPoint;
        Bus = bus;
        this.DLocation = DLocation;
        this.ALocation = ALocation;
    }

    private String DLocation;
    private String ALocation;
}
