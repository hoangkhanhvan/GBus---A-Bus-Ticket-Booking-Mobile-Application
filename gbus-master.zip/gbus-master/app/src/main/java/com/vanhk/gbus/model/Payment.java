package com.vanhk.gbus.model;

public class Payment {
    private String method;
    private String time;
    private String image;

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Payment(String method, String time, String image) {
        this.method = method;
        this.time = time;
        this.image = image;
    }

    public Payment() {
    }
}

