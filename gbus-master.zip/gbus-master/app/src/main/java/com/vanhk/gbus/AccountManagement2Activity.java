package com.vanhk.gbus;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AccountManagement2Activity extends AppCompatActivity {

    private boolean hasChanged = false;
    private Spinner spinnerPhoneCode;
    private ImageView imgAvatar;
    private ImageView imgFlag;
    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int REQUEST_IMAGE_PICK = 2;
    private static final int REQUEST_CAMERA_PERMISSION = 2;
    private String currentPhotoPath;
    EditText edtName;
    EditText edtPhoneNumber;
    EditText edtEmail;
    String accountId;

    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_management2);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);

        addViews();
        Button btnSave = findViewById(R.id.btnAccountManagement2);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!isNetworkConnected()) {
                    Toast.makeText(AccountManagement2Activity.this, "No internet connection", Toast.LENGTH_SHORT).show();
                    return;
                }

                String name = edtName.getText().toString().trim();
                String phoneNumber = edtPhoneNumber.getText().toString().trim();
                String email = edtEmail.getText().toString().trim();

                if (name.isEmpty() || phoneNumber.isEmpty() || email.isEmpty()) {
                    Toast.makeText(AccountManagement2Activity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    saveDataToFirebase(name, phoneNumber, email);
                    Toast.makeText(AccountManagement2Activity.this, "Personal Profile saved successfully", Toast.LENGTH_SHORT).show();
                }
            }
        });

        ImageView imgBack = findViewById(R.id.imgAccountManagement2Back);

        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hasChanged) {
                    finish();
                } else {
                    showConfirmationDialog();
                }
            }
        });

        spinnerPhoneCode = findViewById(R.id.spinnerAccountManagement2PhoneCode);

        String[] phoneCodes = {"+1", "+44", "+61", "+81", "+84", "+86"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, phoneCodes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPhoneCode.setAdapter(adapter);

        imgAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showImagePickerDialog();
            }
        });

        imgFlag = findViewById(R.id.imgFlag);

        spinnerPhoneCode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                updateFlagImage(parentView.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }
        });
    }

    private void addViews() {
        edtName = findViewById(R.id.edtAccountManagement2Name);
        edtPhoneNumber = findViewById(R.id.edtAccountManagement2PhoneNumber);
        edtEmail = findViewById(R.id.edtAccountManagement2Email);
        imgAvatar = findViewById(R.id.imgAccountManagement2Ava);

        edtName.addTextChangedListener(new GenericTextWatcher(edtName));
        edtPhoneNumber.addTextChangedListener(new GenericTextWatcher(edtPhoneNumber));
        edtEmail.addTextChangedListener(new GenericTextWatcher(edtEmail));

        imgAvatar.setOnClickListener(v -> {
            hasChanged = true;  // Mark as changed when image is clicked for changing
            showImagePickerDialog();
        });

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        accountId = sharedPreferences.getString("accountId","account1");

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myAccount = database.getReference("account");

        progressDialog.show();

        myAccount.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot data: snapshot.getChildren()) {
                    String _id = data.getKey();
                    if (_id != null && _id.equals(accountId)) {
                        String phoneNumber = data.child("userInfo").child("account_phone_number").getValue(String.class);
                        String email = data.child("userInfo").child("account_email").getValue(String.class);
                        String name = data.child("userInfo").child("account_name").getValue(String.class);
                        String image = data.child("userInfo").child("account_image").getValue(String.class);

                        if (phoneNumber != null) {
                            edtPhoneNumber.setText(phoneNumber);
                        }
                        if (email != null) {
                            edtEmail.setText(email);
                        }
                        if (name != null) {
                            edtName.setText(name);
                        }
                        if (image != null) {
                            imgAvatar.setImageBitmap(convertBase64toBitmap(image));
                        }
                    }
                }
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss();
            }
        });
    }

    private void saveDataToFirebase(String name, String phoneNumber, String email) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myUser = database.getReference("user");
        DatabaseReference myAccount = database.getReference("account");

        Map<String, Object> userData = new HashMap<>();
        userData.put("account_name", name);
        userData.put("account_phone_number", phoneNumber);
        userData.put("account_email", email);
        Bitmap bitmap = ((BitmapDrawable)imgAvatar.getDrawable()).getBitmap();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageData = baos.toByteArray();

        // Encode byte array to Base64 string
        String imageDataString = Base64.encodeToString(imageData, Base64.DEFAULT);

        userData.put("account_image", imageDataString);
        myAccount.child(accountId).child("userInfo").setValue(userData).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                hasChanged = true;
            }
        });

        // Save avatar image path to SharedPreferences
        SharedPreferences preferences = getSharedPreferences("avatar", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("avatar_path", currentPhotoPath); // currentPhotoPath is the path of the newly captured or selected image
        editor.apply();
    }

    private void showConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Do you want to continue without saving changes?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        AccountManagement2Activity.super.onBackPressed();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public void onBackPressed() {
        if (hasChanged) {
            showConfirmationDialog();
        } else {
            super.onBackPressed();  // Close the activity without showing a dialog
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        hasChanged = true;

        // Retrieve avatar image path from SharedPreferences
        SharedPreferences preferences = getSharedPreferences("avatar", MODE_PRIVATE);
        String avatarPath = preferences.getString("avatar_path", null);
        if (avatarPath != null) {
            Bitmap bitmap = BitmapFactory.decodeFile(avatarPath);
            imgAvatar.setImageBitmap(bitmap);
        }
    }

    private void showImagePickerDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose Image Source");
        builder.setItems(new CharSequence[]{"Camera", "Open in Gallery"}, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0:
                        dispatchTakePictureIntent();
                        break;
                    case 1:
                        dispatchPickImageIntent();
                        break;
                }
            }
        });
        builder.show();
    }



    private void dispatchTakePictureIntent() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    REQUEST_CAMERA_PERMISSION);
        } else {
            openCamera();
        }
    }

    private class GenericTextWatcher implements TextWatcher {
        private View view;

        private GenericTextWatcher(View view) {
            this.view = view;
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void afterTextChanged(Editable editable) {
            hasChanged = true;
        }
    }

    private void openCamera() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            } else {
                Toast.makeText(this, "Camera permission is required to take a picture.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void dispatchPickImageIntent() {
        Intent pickImageIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickImageIntent.setType("image/*");
        startActivityForResult(pickImageIntent, REQUEST_IMAGE_PICK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_IMAGE_CAPTURE && data != null) {
                Bundle extras = data.getExtras();
                if (extras != null) {
                    Bitmap imageBitmap = (Bitmap) extras.get("data");
                    imgAvatar.setImageBitmap(imageBitmap);
                    hasChanged = true;
                }
            } else if (requestCode == REQUEST_IMAGE_PICK && data != null) {
                Uri imageUri = data.getData();
                if (imageUri != null) {
                    imgAvatar.setImageURI(imageUri);
                    hasChanged = true;
                }
            }
        }
    }


    private void updateFlagImage(String countryCode) {
        switch (countryCode) {
            case "+1":
                imgFlag.setImageResource(R.drawable.flag_usa);
                break;
            case "+44":
                imgFlag.setImageResource(R.drawable.flag_uk);
                break;
            case "+61":
                imgFlag.setImageResource(R.drawable.flag_australia);
                break;
            case "+81":
                imgFlag.setImageResource(R.drawable.flag_japan);
                break;
            case "+84":
                imgFlag.setImageResource(R.drawable.img_flag);
                break;
            case "+86":
                imgFlag.setImageResource(R.drawable.flag_china);
                break;
            default:
                break;
        }
    }

    private boolean isNetworkConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (!isNetworkConnected()) {
            Toast.makeText(this, "Unsaved changes", Toast.LENGTH_SHORT).show();
        }
    }

    private Bitmap convertBase64toBitmap(String base64String) {
        try {
            // Decode the Base64 string into a byte array
            byte[] decodedBytes = Base64.decode(base64String, Base64.DEFAULT);

            // Convert the byte array into a Bitmap
            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);

            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Return null to indicate failure
        }
    }
}
