package com.vanhk.gbus;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.VoucherAdapter;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.Payment;
import com.vanhk.gbus.model.Voucher;

import java.util.ArrayList;

public class Payment1Activity extends AppCompatActivity implements VoucherAdapter.OnVoucherSelectedListener {
    ImageView imgPayment1Back;
    TextView txtPayment1ViewallVoucher;
    RecyclerView rvPayment1;
    TextView txtPayment2ViewallVoucher;
    Button btngPayment1Next;
    TextView txtPayment1Policy;
    TextView txtPayment1TermofUse;
    TextView txtgPayment1Price;
    TextView txtgPayment1PriceNotDiscount;
    Button btngPayment1Continue;
    LinearLayoutManager linearLayoutManager;
    String DTotalPrice, RTotalPrice;
    LinearLayout llSelectedPaymentMethod;
    ImageView imggPayment1PaymentLogoImg;
    private VoucherAdapter voucherAdapter;
    int discountPrice = 0;
    int selectedVoucherPosition = -1;
    ArrayList<Voucher> voucherArrayList = new ArrayList<>();
    Payment selectedPayment;

    ProgressDialog progressDialog; // Declare ProgressDialog variable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment1);

        progressDialog = new ProgressDialog(this); // Initialize the ProgressDialog

        addViews();
        initRecyclerView();
        loadData();

        imgPayment1Back.setOnClickListener(v -> onBackPressed());

        txtPayment1ViewallVoucher.setOnClickListener(v -> {
            Intent intent = new Intent(Payment1Activity.this, ChooseVoucherActivity.class);
            startActivity(intent);
        });

        txtPayment2ViewallVoucher.setOnClickListener(v -> {
            Intent intent = new Intent(Payment1Activity.this, ChoosePaymentMethodActivity.class);
            startActivity(intent);
        });

        btngPayment1Next.setOnClickListener(v -> {
            Intent intent = new Intent(Payment1Activity.this, Payment2_2Activity.class);
            startActivity(intent);
        });
        btngPayment1Continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.setMessage("Processing payment..."); // Set message for the ProgressDialog
                progressDialog.setCancelable(false); // Make it not cancelable
                progressDialog.show(); // Show the ProgressDialog

                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                if (Integer.parseInt(txtgPayment1PriceNotDiscount.getText().toString()) == Integer.parseInt(txtgPayment1Price.getText().toString())) {
                    editor.putBoolean("isVoucherSelected", false);
                } else {
                    editor.putBoolean("isVoucherSelected", true);
                }

                if (selectedPayment.getMethod().equals("Mastercard") || selectedPayment.getMethod().equals("VISA") || selectedPayment.getMethod().equals("Napas")) {
                    Intent intent = new Intent(getApplicationContext(), PayByCreditCard1Activity.class);
                    startActivity(intent);
                    return;
                }

                if (Integer.parseInt(txtgPayment1Price.getText().toString()) > 1800000) {
                    progressDialog.dismiss(); // Dismiss the ProgressDialog

                    Intent intent = new Intent(Payment1Activity.this, PaymentUnsucessful_1Activity.class);
                    startActivity(intent);
                } else {
                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference myRef = database.getReference("BookedTicket");

                    String transactionNumber = sharedPreferences.getString("TransactionNumber","");
                    if (!transactionNumber.equals("")) {
                        myRef.child(transactionNumber).child("status").setValue("Paid").addOnSuccessListener(unused -> {
                            progressDialog.dismiss(); // Dismiss the ProgressDialog

                            Intent intent = new Intent(Payment1Activity.this, SuccessPaymentActivity.class);
                            intent.putExtra("discountPrice", txtgPayment1Price.getText().toString());
                            startActivity(intent);
                        });
                        myRef.child(transactionNumber).child("discountPrice").setValue(txtgPayment1Price.getText().toString());
                    }
                }
            }
        });
    }

    private void initRecyclerView() {
        voucherAdapter = new VoucherAdapter(Payment1Activity.this, voucherArrayList, rvPayment1, this);

        linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        rvPayment1.setLayoutManager(linearLayoutManager);
        rvPayment1.setAdapter(voucherAdapter);
    }

    private void loadData() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Vouchers");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                voucherArrayList.clear(); // Clear existing data to avoid duplicates
                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    Voucher voucher = new Voucher();
                    voucher.setId(data.getKey());
                    voucher.setDescription(data.child("description").getValue(String.class));
                    voucher.setPercentage(data.child("percentage").getValue(String.class));
                    voucher.setCondition(data.child("condition").getValue(String.class));
                    voucher.setExpired(data.child("expired").getValue(String.class));

                    Long amount = data.child("amount").getValue(Long.class);
                    if (amount != null && amount > 0) { // Only add vouchers with amount > 0
                        Long conditionValueStr = data.child("condition_value").getValue(Long.class);
                        if (conditionValueStr != null) {
                            voucher.setConditionValue(conditionValueStr.intValue());
                        }

                        String imageBase64 = data.child("image").getValue(String.class);
                        if (imageBase64 != null) {
                            voucher.setImage(imageBase64);
                        }

                        voucherArrayList.add(voucher); // Add to the array list
                        voucherAdapter.add(voucher); // Add to adapter
                    }
                }
                if (selectedVoucherPosition != -1 && selectedVoucherPosition < voucherArrayList.size()) {
                    voucherAdapter.setSelectedPosition(selectedVoucherPosition);
                }
                voucherAdapter.notifyDataSetChanged(); // Notify the adapter to refresh the view
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e(TAG, "loadData:onCancelled", databaseError.toException());
            }
        });
    }


    private boolean checkVoucherCondition(Voucher voucher, String totalPrice) {
        int conditionValue = voucher.getConditionValue();
        int totalOrderValue = Integer.parseInt(totalPrice);

        // So sánh giá trị đơn hàng với condition_value của voucher
        return totalOrderValue <= conditionValue;
    }


    private void addViews() {
        imgPayment1Back = findViewById(R.id.imgPayment1Back);
        txtPayment1ViewallVoucher = findViewById(R.id.txtPayment1ViewallVoucher);
        rvPayment1 = findViewById(R.id.rvPayment1);
        txtPayment2ViewallVoucher = findViewById(R.id.txtPayment2ViewallVoucher);
        btngPayment1Next = findViewById(R.id.btngPayment1Next);
        txtPayment1Policy = findViewById(R.id.txtPayment1Policy);
        txtPayment1TermofUse = findViewById(R.id.txtPayment1TermofUse);
        txtgPayment1Price = findViewById(R.id.txtgPayment1Price);
        txtgPayment1PriceNotDiscount = findViewById(R.id.txtgPayment1PriceNotDiscount);
        btngPayment1Continue = findViewById(R.id.btngPayment1Continue);
        llSelectedPaymentMethod=findViewById(R.id.llSelectedPaymentMethod);
        imggPayment1PaymentLogoImg=findViewById(R.id.imggPayment1PaymentLogoImg);
        TextView textView = findViewById(R.id.textView);

        selectedPayment = MySharedPreferences.getObject(this,"PaymentMethod",Payment.class);
        if (selectedPayment != null) {
            Bitmap bitmap = convertBase64toBitmap(selectedPayment.getImage());
            imggPayment1PaymentLogoImg.setImageBitmap(bitmap);
            textView.setText(selectedPayment.getMethod());
        }

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        DTotalPrice = sharedPreferences.getString("DTotalPrice","0");
        RTotalPrice = sharedPreferences.getString("RTotalPrice","0");
        txtgPayment1PriceNotDiscount.setText(String.valueOf(Integer.parseInt(DTotalPrice)+Integer.parseInt(RTotalPrice)));
        txtgPayment1PriceNotDiscount.setVisibility(View.GONE);
        txtgPayment1Price.setText(String.valueOf(Integer.parseInt(DTotalPrice)+Integer.parseInt(RTotalPrice)));


        Intent getIntent = getIntent();
        String percentageStr = getIntent.getStringExtra("percentage");
        selectedVoucherPosition = getIntent.getIntExtra("position",-1);
        if (percentageStr != null) {
            int percentage = Integer.parseInt(percentageStr.replace("%", ""));
            txtgPayment1PriceNotDiscount.setVisibility(View.VISIBLE);
            discountPrice = ((Integer.parseInt(DTotalPrice) + Integer.parseInt(RTotalPrice))*(100-percentage))/100;
            txtgPayment1Price.setText(String.valueOf(discountPrice));
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, BookingPreview1Activity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onVoucherSelected(int position) {
        Voucher voucher = voucherAdapter.getItem(position);
        String percentageString = voucher.getPercentage(); // "70%"
        int percentage = Integer.parseInt(percentageString.replace("%", ""));
        txtgPayment1PriceNotDiscount.setVisibility(View.VISIBLE);
        discountPrice = ((Integer.parseInt(DTotalPrice) + Integer.parseInt(RTotalPrice))*(100-percentage))/100;
        txtgPayment1Price.setText(String.valueOf(discountPrice));

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString("voucherChecked", voucher.getId());
        editor.apply();
    }

    private Bitmap convertBase64toBitmap(String base64String) {
        try {
            // Remove the data URI prefix if present
            String pureBase64Encoded = base64String.split(",")[1];

            // Decode the Base64 string into a byte array
            byte[] decodedBytes = Base64.decode(pureBase64Encoded, Base64.DEFAULT);

            // Convert the byte array into a Bitmap
            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);

            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Return null to indicate failure
        }
    }
}
