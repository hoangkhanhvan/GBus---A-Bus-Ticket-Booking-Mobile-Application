package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.TripDetail4Adapter;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.Ticket;
import com.vanhk.gbus.model.TripDetail3;
import com.vanhk.gbus.model.TripDetail4;

import java.util.ArrayList;

public class TripDetails4Activity extends AppCompatActivity {
    TextView txtTripDetail4DepartLocation, txtTripDetail4ArrivalLocation, txtTripdetails4Tag, txtTripDetails4DepartDate,
            txtTripDetails4PickupDropoff, txtTripDetails4BusFeatures, txtTripDetails4Total;
    LinearLayout layoutTripDetails4Reviews;
    ListView lvTripDetail4;
    ImageView imgTripDetails4Close;
    Button btnTripDetail4Book;
    String TAG = "FIREBASE";
    TripDetail4Adapter tripDetail4Adapter;
    ArrayList<TripDetail4> tripDetail4List;

    // Declare ProgressDialog variable
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_details4);
        addViews();
        addEvents();

        // Initialize the progressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable
    }

    private void addEvents() {
        imgTripDetails4Close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TripDetails4Activity.this,ResultList1Activity.class);
                startActivity(intent);
            }
        });

        txtTripDetails4PickupDropoff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TripDetails4Activity.this, TripDetails1Activity.class);
                startActivity(intent);
            }
        });

        layoutTripDetails4Reviews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TripDetails4Activity.this,TripDetails3Activity.class);
                startActivity(intent);
            }
        });

        txtTripDetails4BusFeatures.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TripDetails4Activity.this, TripDetails5Activity.class);
                startActivity(intent);
            }
        });

        btnTripDetail4Book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show the ProgressDialog when "Book" button is clicked
                progressDialog.show();

                Ticket selectedTicket = MySharedPreferences.getObject(TripDetails4Activity.this,"SelectedTicket",Ticket.class);

                Intent getIntent = getIntent();
                String accountId = getIntent.getStringExtra("accountId");

                Intent intent = new Intent(TripDetails4Activity.this, ChooseSeat_Depart_1Activity.class);

                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("departureTicketId", selectedTicket.get_id());
                editor.apply();

                ArrayList<String> search = getIntent.getStringArrayListExtra("search");

                intent.putExtra("ticket",selectedTicket);
                intent.putStringArrayListExtra("search",search);
                MySharedPreferences.saveObject(TripDetails4Activity.this, "DTicket", selectedTicket);
                boolean isReturn = sharedPreferences.getBoolean("isReturn",false);
                if (isReturn) {
                    MySharedPreferences.saveObject(TripDetails4Activity.this, "RTicket", selectedTicket);

                } else {
                    MySharedPreferences.saveObject(TripDetails4Activity.this, "DTicket", selectedTicket);

                }

                startActivity(intent);

                // Dismiss the ProgressDialog after starting the new activity
                progressDialog.dismiss();
            }
        });
    }

    private void addViews() {
        txtTripDetail4DepartLocation=findViewById(R.id.txtTripDetail4DepartLocation);
        txtTripDetail4ArrivalLocation=findViewById(R.id.txtTripDetail4ArrivalLocation);
        txtTripdetails4Tag=findViewById(R.id.txtTripdetails4Tag);
        txtTripDetails4DepartDate=findViewById(R.id.txtTripDetails4DepartDate);
        txtTripDetails4PickupDropoff=findViewById(R.id.txtTripDetails4PickupDropoff);
        txtTripDetails4BusFeatures=findViewById(R.id.txtTripDetails4BusFeatures);
        txtTripDetails4Total=findViewById(R.id.txtTripDetails4Total);
        layoutTripDetails4Reviews=findViewById(R.id.layoutTripDetails4Reviews);
        imgTripDetails4Close=findViewById(R.id.imgTripDetails4Close);
        btnTripDetail4Book=findViewById(R.id.btnTripDetail4Book);
        lvTripDetail4=findViewById(R.id.lvTripDetail4);

        tripDetail4List=new ArrayList<>();
        tripDetail4Adapter=new TripDetail4Adapter(TripDetails4Activity.this,R.layout.lvtripdetails4utilities);
        lvTripDetail4.setAdapter(tripDetail4Adapter);

        loadData();
    }

    private void loadData() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Amenities");
        myRef.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot data : snapshot.getChildren()) {
                    String _id = data.child("_id").getValue(String.class);
                    String description = data.child("Description").getValue(String.class);
                    String title = data.child("Title").getValue(String.class);
                    if (description != null && title != null) {
                        String image = data.child("Image").getValue(String.class);

                        TripDetail4 tripDetail4 = new TripDetail4();
                        tripDetail4.setImage(convertBase64toBitmap(image));
                        tripDetail4.setTitle(title.toString());
                        tripDetail4.setDescription(description.toString());

                        tripDetail4Adapter.add(tripDetail4);
                    }
                }
            }

            private Bitmap convertBase64toBitmap(String base64String) {
                try {
                    String pureBase64Encoded = base64String.split(",")[1];
                    byte[] decodedBytes = Base64.decode(pureBase64Encoded, Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);

                    return bitmap;
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "loadPost:onCancelled", error.toException());
            }
        });
    }
}

