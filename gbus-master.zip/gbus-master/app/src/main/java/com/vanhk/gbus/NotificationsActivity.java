package com.vanhk.gbus;

import static android.text.format.DateUtils.isToday;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.Notification2Adapter;
import com.vanhk.gbus.adapter.NotificationAdapter;
import com.vanhk.gbus.model.Notification;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class NotificationsActivity extends AppCompatActivity {
    TextView txtCount, txtCount2;
    ListView lvNotificationsToday, lvNotificationsThisWeek;
    LinearLayout llNotificationNavigationSearch,llNotificationNavigationHistory
            ,llNotificationsNavigation,llNotificationNavigationAccount, llNoResultsLayout;

    String TAG = "FIREBASE";
    NotificationAdapter notificationAdapter;
    Notification2Adapter notification2Adapter;
    LinearLayout llToday, llWeek ;
    ProgressDialog progressDialog; // Declare ProgressDialog

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);
        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        addViews();
        addEvents();
        progressDialog.show(); // Show ProgressDialog when activity starts
    }

    private void addEvents() {
        llNotificationNavigationSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NotificationsActivity.this,HomepageActivity.class);
                startActivity(intent);
            }
        });
        llNotificationNavigationHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NotificationsActivity.this,UnpaidTicketActivity.class);
                startActivity(intent);
            }
        });
        llNotificationNavigationAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NotificationsActivity.this,AccountMangement1Activity.class);
                startActivity(intent);
            }
        });
    }


    private void addViews() {
        llNoResultsLayout = findViewById(R.id.llNoResultsLayout);
        llNoResultsLayout.setVisibility(View.GONE);

        txtCount=findViewById(R.id.txtCount);
        txtCount2=findViewById(R.id.txtCount2);
        lvNotificationsToday = findViewById(R.id.lvNotificationsToday);
        lvNotificationsThisWeek = findViewById(R.id.lvNotificationsThisWeek);
        llToday=findViewById(R.id.llToday);
        llWeek=findViewById(R.id.llWeek);
        notificationAdapter = new NotificationAdapter(NotificationsActivity.this, R.layout.notifications_list_items);
        notification2Adapter = new Notification2Adapter(NotificationsActivity.this, R.layout.notifications_list_items);
        llNotificationNavigationSearch=findViewById(R.id.llNotificationNavigationSearch);
        llNotificationNavigationHistory=findViewById(R.id.llNotificationNavigationHistory);
        llNotificationsNavigation=findViewById(R.id.llNotificationsNavigation);
        llNotificationNavigationAccount=findViewById(R.id.llNotificationNavigationAccount);
        lvNotificationsToday.setAdapter(notificationAdapter);
        lvNotificationsThisWeek.setAdapter(notification2Adapter);


        loadData();

    }
    private void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String accountId = sharedPreferences.getString("accountId","");

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Notification");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot accountData : snapshot.getChildren()) {
                    String key = accountData.getKey();
                    Log.d("Key",key);
                    Log.d("AccountId",accountId);
                    if (key != null && key.equals(accountId)) {
                        for (DataSnapshot data: accountData.getChildren()) {
                            String _id = data.child("_id").getValue(String.class);
                            assert _id != null;
                            String title = data.child("Title").getValue(String.class);
                            Long timestamp = data.child("Timestamp").getValue(Long.class);
                            Log.d("Data",_id + "\n" + title);

                            if (title != null && timestamp != null) {
                                String image = data.child("Image").getValue(String.class);
                                String description = data.child("Description").getValue(String.class);

                                Notification notification1 = new Notification();
                                notification1.setTitle(title.toString());
                                notification1.setImage(convertBase64toBitmap(image));
                                notification1.setDescription(description.toString());
                                notification1.setTimestamp(Long.parseLong(timestamp.toString()));

                                if (isTodayNotification(notification1.getTimestamp())) {
                                    notificationAdapter.add(notification1);
                                } else {
                                    notification2Adapter.add(notification1);
                                }
                                updateNotificationCount();

                            }

                        }
                        break;
                    }
                }
                if (notificationAdapter.getCount() == 0) {
                    llToday.setVisibility(View.GONE);
                    lvNotificationsToday.setVisibility(View.GONE);
                    llNoResultsLayout.setVisibility(View.VISIBLE);
                } else if (notification2Adapter.getCount() == 0) {
                    llWeek.setVisibility(View.GONE);
                    lvNotificationsThisWeek.setVisibility(View.GONE);
                }
                progressDialog.dismiss(); // Dismiss ProgressDialog when data is loaded
            }

            private void updateNotificationCount() {
                int todayCount = lvNotificationsToday.getCount();
                int thisWeekCount = lvNotificationsThisWeek.getCount();

                txtCount.setText(""+todayCount);
                txtCount2.setText(""+thisWeekCount);
            }

            private boolean isTodayNotification(long timestamp) {
                Calendar today = Calendar.getInstance();
                Calendar notificationTime = Calendar.getInstance();
                notificationTime.setTimeInMillis(timestamp);
                return today.get(Calendar.YEAR) == notificationTime.get(Calendar.YEAR) &&
                        today.get(Calendar.DAY_OF_YEAR) == notificationTime.get(Calendar.DAY_OF_YEAR);
            }

            private Bitmap convertBase64toBitmap(String image) {
                try {
                    // Remove the data URI prefix if present
                    String pureBase64Encoded = image.split(",")[1];


                    // Decode the Base64 string into a byte array
                    byte[] decodedBytes = Base64.decode(pureBase64Encoded, Base64.DEFAULT);


                    // Convert the byte array into a Bitmap
                    Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);


                    return bitmap;
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {


            }




        });

    }
}
