package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.AccountAdapter;

public class Login2Activity extends AppCompatActivity {
    EditText edtLogIn2;
    Button btnLogIn2, btnLogin2ForgotPassword;
    ImageButton btnLogIn2Img;
    AccountAdapter accountAdapter;
    final String PREF_NAME = "LoginData";
    String TAG = "FIREBASE";
    DatabaseReference myRef;
    private AlertDialog alertDialog;
    private ProgressDialog progressDialog; // Declare ProgressDialog

    String accountId = "";

    BroadcastReceiver internetReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Toast.makeText(context, "Internet changed", Toast.LENGTH_LONG).show();
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            if (networkInfo != null && networkInfo.isConnected()) {
                btnLogIn2.setEnabled(true);
                btnLogin2ForgotPassword.setEnabled(true);
            } else {
                btnLogIn2.setBackgroundColor(R.drawable.button_background_disable);
                btnLogIn2.setEnabled(false);
                btnLogin2ForgotPassword.setEnabled(false);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);

        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog
        progressDialog.setMessage("Logging in...");
        progressDialog.setCancelable(false);

        addViews();
        addEvents();
//        showLoginSuccessDialog();
    }

    private void addViews() {
        edtLogIn2 = findViewById(R.id.edtLogIn2);
        btnLogIn2 = findViewById(R.id.btnLogIn2);
        btnLogin2ForgotPassword = findViewById(R.id.btnLogin2ForgotPassword);
        btnLogIn2Img = findViewById(R.id.btnLogIn2Img);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("account");
    }

    private void addEvents() {

        btnLogin2ForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login2Activity.this,ForgotPassword_1Activity.class);
                startActivity(intent);
            }
        });
        btnLogIn2Img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login2Activity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        btnLogIn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show(); // Show ProgressDialog when login button is clicked

                if (edtLogIn2.getText().toString().trim().isEmpty()) {
                    progressDialog.dismiss(); // Dismiss ProgressDialog if input is empty
                    Toast.makeText(Login2Activity.this, "Please enter your Password", Toast.LENGTH_LONG).show();
                    edtLogIn2.setError("Password is required");
                    edtLogIn2.requestFocus();
                    return;
                } else {
                    final String enteredPassword = edtLogIn2.getText().toString().trim();
                    checkAccount2(enteredPassword);
                }
//            @Override
//            public void onClick(View v) {
//                String enteredPassWord = edtLogIn2.getText().toString().trim();
//                checkAccount2(enteredPassWord);
//            }


            }

//    private void checkAccount2(String enteredPassWord) {
//        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                boolean found = false;
//                for (DataSnapshot data : dataSnapshot.getChildren()) {
//                    String userPassWord = data.child("account_password").getValue(String.class);
//                    if (userPassWord != null && userPassWord.equals(enteredPassWord)) {
////                        // Username and password match, do something (e.g., login)
//                        found = true;
////                        Intent intent=new Intent(Login2Activity.this, HomepageActivity.class);
////                        startActivity(intent);
////
////                        break;
//                        showLoginSuccessDialog();
//                        break;
//                    }
//                }
//                if (!found) {
//                    // Username or password is incorrect
//                    Toast.makeText(Login2Activity.this, "Incorrect. Please try again", Toast.LENGTH_SHORT).show();
//                }
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                Log.w(TAG, "loadPost:onCancelled", databaseError.toException());
//            }
//        });
//    }

//    private void showLoginSuccessDialog() {
//        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//        builder.setTitle("Login Successful")
//                .setMessage("You have successfully logged in.")
//                .setPositiveButton("OK", null); // You can customize the button as per your need
//
//        alertDialog = builder.create();
//        alertDialog.show();
//
//        // Automatically dismiss the dialog after a delay
//        Handler handler = new Handler();
//        handler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                if (alertDialog != null && alertDialog.isShowing()) {
//                    alertDialog.dismiss();
//                    navigateToHomePage();
//                }
//            }
//        }, DISMISS_DELAY);
//    }

//            private void navigateToHomePage() {
//                Intent intent = new Intent(Login2Activity.this, HomepageActivity.class);
//                startActivity(intent);
//                finish();
//            }


            //            private void checkAccount2(String enteredPassword) {
//                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(DataSnapshot dataSnapshot) {
//                        boolean found = false;
//                        for (DataSnapshot data : dataSnapshot.getChildren()) {
//                            String userPasswordHash = data.child("account_password").getValue(String.class);
//                            // Assuming userPasswordHash contains a hashed version of the password
//
//                            // Validate password by comparing hashed passwords
//                            if (userPasswordHash != null && verifyPassword(enteredPassword, userPasswordHash)) {
//                                // Password matches, do something (e.g., login)
//                                found = true;
//                                showLoginSuccessDialog();
//                                break;
//                            }
//                        }
//                        if (!found) {
//                            // Password is incorrect
//                            Toast.makeText(Login2Activity.this, "Incorrect password. Please try again", Toast.LENGTH_SHORT).show();
//                        }
//                    }
//
//                    @Override
//                    public void onCancelled(DatabaseError databaseError) {
//                        Log.w(TAG, "loadPost:onCancelled", databaseError.toException());
//                    }
//                });
//            }
            private int wrongAttempts = 0; // Variable to track wrong login attempts

            private void checkAccount2(String enteredPassword) {
                if (enteredPassword.length() < 8) {
                    progressDialog.dismiss(); // Dismiss ProgressDialog if input is empty
                    Toast.makeText(Login2Activity.this, "Password must be at least 8 characters.", Toast.LENGTH_SHORT).show();
                    edtLogIn2.setError("At least 8 characters");
                    edtLogIn2.requestFocus();
                    return;
                }

                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        boolean found = false;
                        for (DataSnapshot data : dataSnapshot.getChildren()) {
                            String userPasswordHash = data.child("accountPassword").getValue(String.class);
                            // Assuming userPasswordHash contains a hashed version of the password

                            // Validate password by comparing hashed passwords
                            if (userPasswordHash != null && userPasswordHash.equals(enteredPassword)) {
                                // Password matches, do something (e.g., login)
                                found = true;
                                showLoginSuccessDialog();
                                accountId = data.getKey();
                                break;
                            }
                        }
                        if (!found) {
                            progressDialog.dismiss(); // Dismiss ProgressDialog if password is incorrect
                            // Password is incorrect
                            // Increment wrong attempts counter
                            wrongAttempts++;
                            // Display appropriate message based on wrong attempts
                            switch (wrongAttempts) {
                                case 1:
                                    Toast.makeText(Login2Activity.this, "Wrong attempt 1", Toast.LENGTH_SHORT).show();
                                    break;
                                case 2:
                                    Toast.makeText(Login2Activity.this, "Wrong attempt 2", Toast.LENGTH_SHORT).show();
                                    break;
                                case 3:
                                    Toast.makeText(Login2Activity.this, "Wrong attempt 3", Toast.LENGTH_SHORT).show();
                                    break;
                                case 4:
                                    Toast.makeText(Login2Activity.this, "Wrong attempt 4", Toast.LENGTH_SHORT).show();
                                    break;
                                case 5:
                                    Toast.makeText(Login2Activity.this, "Wrong attempt 5", Toast.LENGTH_SHORT).show();
                                    break;
                                case 6:
                                    // Redirect to Forgot Password activity after 5 wrong attempts
                                    Intent intent = new Intent(Login2Activity.this, ForgotPassword_1Activity.class);
                                    startActivity(intent);
                                    break;
                            }
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Log.w(TAG, "loadPost:onCancelled", databaseError.toException());
                    }
                });
            }


            private void showLoginSuccessDialog() {
                // Dismiss ProgressDialog
                progressDialog.dismiss();
                AlertDialog.Builder builder = new AlertDialog.Builder(Login2Activity.this);
                builder.setMessage("Login successful!");
                builder.setCancelable(false); // Prevent dialog from being dismissed by tapping outside

                builder.setIcon(R.drawable.img_done);

                // Create a dialog
                final AlertDialog dialog = builder.create();
                dialog.show();

                // Automatically dismiss the dialog after 2 seconds
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        dialog.dismiss();

                        // Automatically navigate to the homepage after dismissing the dialog
                        Intent intent = new Intent(Login2Activity.this, HomepageActivity.class);
                        // Get the SharedPreferences object
                        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();

                        editor.putString("accountId",accountId);
                        editor.apply();
                        Toast.makeText(Login2Activity.this, accountId, Toast.LENGTH_SHORT).show();
                        startActivity(intent);
                    }
                }, 2000); // 2000 milliseconds = 2 seconds
            }

//            private boolean verifyPassword(String enteredPassword, String userPasswordHash) {
//                if (enteredPassword.length() < 8) {
//                    Toast.makeText(Login2Activity.this, "Password must be at least 8 characters.", Toast.LENGTH_LONG).show();
//                    edtLogIn2.setError("At least 8 characters");
//                    edtLogIn2.requestFocus();
//                    return false; // Password does not meet minimum length requirement
//                }
//                return enteredPassword.equals(userPasswordHash);
//
//                // Implement password comparison using appropriate cryptographic methods
//                // For simplicity, let's assume a simple comparison for this example
//                 // Return true if passwords match
//            }
//        });
//    }
        });
    }
}