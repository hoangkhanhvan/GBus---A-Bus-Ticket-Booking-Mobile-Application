package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class PaymentGuidelineActivity extends AppCompatActivity {
    ImageView imgPaymentGuidelineBack;
    Button btnPaymentGuidelinePrivacyPolicy;
    Button btnPaymentGuidelineTermOfUse;
    Button btnPaymentGuidelineConfirm;

    ProgressDialog progressDialog; // Declare ProgressDialog variable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_guideline);
        addViews();

        progressDialog = new ProgressDialog(this); // Initialize the ProgressDialog

        imgPaymentGuidelineBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnPaymentGuidelineConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.setMessage("Confirming..."); // Set message for the ProgressDialog
                progressDialog.setCancelable(false); // Make it not cancelable
                progressDialog.show(); // Show the ProgressDialog

                // Your confirmation logic here...

                Intent intent = new Intent(PaymentGuidelineActivity.this, Payment1Activity.class);
                startActivity(intent);

                progressDialog.dismiss(); // Dismiss the ProgressDialog when the operation is complete
            }
        });
    }

    private void addViews() {
        imgPaymentGuidelineBack = findViewById(R.id.imgPaymentGuidelineBack);
        btnPaymentGuidelinePrivacyPolicy = findViewById(R.id.btnPaymentGuidelinePrivacyPolicy);
        btnPaymentGuidelineTermOfUse = findViewById(R.id.btnPaymentGuidelineTermOfUse);
        btnPaymentGuidelineConfirm = findViewById(R.id.btnPaymentGuidelineConfirm);
    }
}