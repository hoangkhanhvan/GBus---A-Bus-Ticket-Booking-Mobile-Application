package com.vanhk.gbus;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

public class Rating_3Activity extends AppCompatActivity {

    RatingBar ratingBar3;
    ImageButton btnRating3AddImg, btnRating3AddVideo;
    EditText edtRating3RatingDetails;
    TextView txtRating3NumofWord;
    Intent previousIntent=null;

    ImageView imgRating3Back, imageView;

    Button btnRating3Send;

    ProgressDialog progressDialog; // Declare ProgressDialog variable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating3);
        addViews();
        addEvents();

        getDataFromPreviousActivity();
        // Initialize the progressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable
    }



    private void addEvents() {
        imgRating3Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Rating_3Activity.this,PaidTicketActivity.class);
                startActivity(intent);
            }
        });
        //đặt trạng thái ban đầu
        btnRating3Send.setEnabled(false);

        // Xử lý sự kiện khi thay đổi trạng thái focus của EditText
        edtRating3RatingDetails.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(!edtRating3RatingDetails.getText().toString().isEmpty()) {
                    btnRating3Send.setEnabled(false);
                }
            }
        });
        // Xử lý sự kiện khi nội dung của EditText thay đổi
        edtRating3RatingDetails.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                // Kiểm tra nếu nội dung đã được nhập vào EditText
                if (!s.toString().isEmpty()) {
                    // Nếu đã nhập, enable button gửi
                    btnRating3Send.setEnabled(true);
                } else {
                    // Nếu không có nội dung, vô hiệu hóa button gửi
                    btnRating3Send.setEnabled(false);
                }
            }
        });
        //sau khi hoàn tất hiện dialog complete
        btnRating3Send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // hiện pop-up
                showRatingCompleteDialog();
                //chuyển hình và ảnh tải lên qua format Rating 4
            }

        });



        btnRating3AddImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //dialog chọn ảnh or chụp ảnh
                showImagePickerDialog();
            }
        });

        btnRating3AddVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processCaptureVideo();
            }
        });

        txtRating3NumofWord.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                // Đếm số ký tự
                int numOfChars = s.length();
                edtRating3RatingDetails.setText(numOfChars + "/200");
            }
        });
    }



    private void showImagePickerDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose photo");
        // Tạo các lựa chọn trong dialog

        // Tạo các lựa chọn trong dialog
        String[] options = {"Open camera", "Choose from your device"};
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0:
                        // Chọn chụp ảnh
                        processCaptureImage();
                        return;
                    case 1:
                        // Chọn ảnh từ album ảnh
                        processImageFromGallery();
                        return;
                }
            }
        });
        builder.show();

    }

    private void processImageFromGallery() {
        // Kiểm tra xem quyền truy cập vào bộ nhớ đã được cấp hay chưa
        if(ContextCompat.checkSelfPermission(
                getApplicationContext(),
                Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            // Nếu chưa được cấp quyền, yêu cầu quyền truy cập vào bộ nhớ
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    456);
        } else {
            // Nếu đã được cấp quyền, mở ứng dụng Gallery để chọn ảnh
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, 789);
        }
    }

    private void processCaptureImage() {
        if(ContextCompat.checkSelfPermission(
                getApplicationContext(),
                android.Manifest.permission.CAMERA)== PackageManager.PERMISSION_DENIED)
        {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.CAMERA},123);
        }
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, 456);
    }


    private void displayImageFromIntent(Intent intent) {
        // Nhận dữ liệu ảnh từ Intent
        Bitmap bitmap = intent.getParcelableExtra("IMAGE_DATA");

        // Hiển thị ảnh trong ImageView
        imageView.setImageBitmap(bitmap);
        imageView.setVisibility(View.VISIBLE);
    }

    // Thêm chức năng tải video từ album ảnh
    private void processVideoFromGallery() {
        // Kiểm tra xem quyền truy cập vào bộ nhớ đã được cấp hay chưa
        if(ContextCompat.checkSelfPermission(
                getApplicationContext(),
                Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            // Nếu chưa được cấp quyền, yêu cầu quyền truy cập vào bộ nhớ
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    789);
        } else {
            // Nếu đã được cấp quyền, mở ứng dụng Gallery để chọn video
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, 123);
        }
    }

    // Thêm chức năng quay video từ camera
    private void processCaptureVideo() {
        if(ContextCompat.checkSelfPermission(
                getApplicationContext(),
                Manifest.permission.CAMERA)== PackageManager.PERMISSION_DENIED)
        {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.CAMERA},456);
        }
        Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        startActivityForResult(intent, 789);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    @Nullable Intent data) {
        Rating_3Activity.super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 456 && resultCode == RESULT_OK) {
            // Xử lý khi chụp ảnh thành công
            if (data != null) {
                Bitmap bitmap = (Bitmap) data.getExtras().get("data");
                // Chuyển dữ liệu ảnh sang màn hình mới
                Intent intent = new Intent(this, Rating_4Activity.class);
                intent.putExtra("IMAGE_DATA", bitmap);
                startActivity(intent);
                // Hiển thị ảnh từ Intent trong ImageView
                displayImageFromIntent(data);
            }
        } else if (requestCode == 789 && resultCode == RESULT_OK) {
            // Xử lý khi quay video thành công
            if (data != null) {
                Uri videoUri = data.getData();
                // Chuyển dữ liệu video sang màn hình mới
                Intent intent = new Intent(this, Rating_4Activity.class);
                intent.putExtra("VIDEO_URI", videoUri.toString());
                startActivity(intent);
            }
        }

    }



    private void addViews() {
        ratingBar3 = findViewById(R.id.ratingBar3);
        btnRating3AddImg = findViewById(R.id.btnRating3AddImg);
        btnRating3AddVideo = findViewById(R.id.btnRating3AddVideo);
        btnRating3Send = findViewById(R.id.btnRating3Send);
        edtRating3RatingDetails = findViewById(R.id.edtRating3RatingDetails);
        txtRating3NumofWord = findViewById(R.id.txtRating3NumofWord);
        imgRating3Back=findViewById(R.id.imgRating3Back);

        imageView = findViewById(R.id.imageView9);
        imageView.setVisibility(View.GONE);
    }

    private void showRatingCompleteDialog() {
        // Show the progressDialog before displaying the dialog
        progressDialog.show();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        // Inflate layout từ file XML
        View dialogView = getLayoutInflater().inflate(R.layout.rating_complete_dialog, null);

        // Thiết lập layout cho dialog
        builder.setView(dialogView);

        // Tạo và hiển thị AlertDialog
        AlertDialog alertDialog = builder.create();
        alertDialog.show();

        // Dismiss the progressDialog after displaying the dialog
        progressDialog.dismiss();
    }

    private void getDataFromPreviousActivity() {
        previousIntent=getIntent();
    }
}