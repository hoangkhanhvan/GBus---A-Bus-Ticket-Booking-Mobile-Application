package com.vanhk.gbus.model;

public class UserHelperClass2 {
    String accountEmail;

    public UserHelperClass2(String accountEmail) {
        this.accountEmail = accountEmail;
    }

    public String getAccountEmail() {
        return accountEmail;
    }

    public void setAccountEmail(String accountEmail) {
        this.accountEmail = accountEmail;
    }
}
