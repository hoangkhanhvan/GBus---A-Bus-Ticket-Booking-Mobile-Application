package com.vanhk.gbus;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.PaidTicket;
import com.vanhk.gbus.model.UnPaidTicket;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Cancellation2Activity extends AppCompatActivity {
    ImageView imgCancellation2Back;
    TextView txtCancellation2DepartureTime, txtCancellation2TotalPayment, txtCancellation2Refund, txtCancellation2CancellationFee, txtCancellation2RefundableAmount;
    Button btnCancellation2Confirm, btnCancellation2TellUs;
    int refundPercentage, refundFee;

    ProgressDialog progressDialog; // ProgressDialog instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancellation2);
        addViews();
        addEvents();
    }

    private void addEvents() {
        imgCancellation2Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Cancellation2Activity.this, UnpaidTicketActivity.class);
                startActivity(intent);
            }
        });
        btnCancellation2Confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();
            }
        });
    }

    private void openDialog() {
        progressDialog.show(); // Show progressDialog when the button is clicked
        final Dialog dialog = new Dialog(Cancellation2Activity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_cancellation2);

        Window window = dialog.getWindow();
        if (window == null) {
            return;
        }

        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.copyFrom(window.getAttributes());
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        layoutParams.gravity = Gravity.BOTTOM;
        layoutParams.horizontalMargin = 0;

        window.setAttributes(layoutParams);

        dialog.setCancelable(true);

        Button btnConfirm = dialog.findViewById(R.id.btnCancellation2ConfirmDialog);
        Button btnBack = dialog.findViewById(R.id.btnCancellation2Back);

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                editor.putString("refundPercentage", String.valueOf(refundPercentage));
                editor.putString("refundFee", String.valueOf(refundFee));

                editor.apply();

                Intent intent = new Intent(Cancellation2Activity.this, Cancellation3Activity.class);
                startActivity(intent);
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Cancellation2Activity.this, UnpaidTicketActivity.class);
                startActivity(intent);
            }
        });

        dialog.show();
        progressDialog.dismiss(); // Dismiss progressDialog after the dialog is shown

    }

    private void addViews() {
        imgCancellation2Back = findViewById(R.id.imgCancellation2Back);
        txtCancellation2DepartureTime = findViewById(R.id.txtCancellation2DepartureTime);
        txtCancellation2TotalPayment = findViewById(R.id.txtCancellation2TotalPayment);
        txtCancellation2Refund = findViewById(R.id.txtCancellation2Refund);
        txtCancellation2CancellationFee = findViewById(R.id.txtCancellation2CancellationFee);
        txtCancellation2RefundableAmount = findViewById(R.id.txtCancellation2RefundableAmount);
        btnCancellation2Confirm = findViewById(R.id.btnCancellation2Confirm);
        btnCancellation2TellUs = findViewById(R.id.btnCancellation2TellUs);
        loadData();

        progressDialog = new ProgressDialog(this); // Initialize progressDialog
        progressDialog.setMessage("Processing..."); // Set message for progressDialog
        progressDialog.setCancelable(false); // Make progressDialog not cancellable

    }

    private void loadData() {
        PaidTicket paidTicket = MySharedPreferences.getObject(getApplicationContext(), "cancelingTicket", PaidTicket.class);
        if (paidTicket == null) {
            Log.e("Cancellation2Activity", "Failed to load paid ticket data");
            return; // Early exit if data is not available
        }

        // Format date and time safely
        String dateTime = formatDateTime(paidTicket.getDeparture().getTicket().getDate(), paidTicket.getDeparture().getTicket().getDTime());
        if (dateTime != null) {
            txtCancellation2DepartureTime.setText(dateTime);
        } else {
            txtCancellation2DepartureTime.setText("Invalid date/time"); // Default text if date/time format fails
        }

        // Calculate refund details
        refundPercentage = calculateRemainingTime(paidTicket.getDeparture().getTicket().getDate(), paidTicket.getDeparture().getTicket().getDTime());
        try {
            int totalPayment = Integer.parseInt(paidTicket.getTotalPayment());
            refundFee = (totalPayment * (100 - refundPercentage)) / 100;

            txtCancellation2TotalPayment.setText(String.valueOf(totalPayment)); // Convert to string to avoid resource ID error
            txtCancellation2Refund.setText(refundPercentage + "%");
            txtCancellation2CancellationFee.setText(String.valueOf(refundFee)); // Convert to string to avoid resource ID error
            txtCancellation2RefundableAmount.setText(String.valueOf(totalPayment - refundFee)); // Convert to string
        } catch (NumberFormatException e) {
            Log.e("Cancellation2Activity", "Error parsing payment values", e);
            // Set default error text or handle the error appropriately
        }
    }


    public static String formatDateTime(String date, String time) {
        try {
            SimpleDateFormat inputDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            Date parsedDate = inputDateFormat.parse(date + " " + time);

            SimpleDateFormat outputDateFormat = new SimpleDateFormat("MMM dd, yyyy 'at' hh:mma");
            return outputDateFormat.format(parsedDate);
        } catch (Exception e) {
            e.printStackTrace();
            return null; // or handle the error as needed
        }
    }

    public static int calculateRemainingTime(String date, String time) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            Date futureDate = inputFormat.parse(date + " " + time);
            Date currentDate = new Date();

            // Calculating the time difference in milliseconds
            long timeDifference = futureDate.getTime() - currentDate.getTime();

            // Convert milliseconds to hours
            long hours = timeDifference / (1000 * 60 * 60);

            if (hours > 24) {
                return 100;
            } else if (hours > 12) {
                return 50;
            } else if (hours > 6) {
                return 30;
            } else {
                return 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return -1; // Return -1 or handle the error as needed
        }
    }


//    private void loadData() {
//        FirebaseDatabase database = FirebaseDatabase.getInstance();
//        DatabaseReference myRef = database.getReference();
//        myRef.child("BookedTicket").child("-NwASRIkAJewELKUkMSg").addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if (snapshot.exists()) {
//                    String dateStr = snapshot.child("dropOffPoint").child("dateStr").getValue(String.class);
//                    String time = snapshot.child("dropOffPoint").child("time").getValue(String.class);
//
//                    // Parse time to determine whether it's before or after 12:00
//                    String timeOfDay = "";
//                    String[] timeParts = time.split(":");
//                    int hour = Integer.parseInt(timeParts[0]);
//                    if (hour < 12) {
//                        timeOfDay = "AM";
//                    } else {
//                        timeOfDay = "PM";
//                        // Convert hour to PM format
//                        if (hour > 12) {
//                            hour -= 12;
//                            timeParts[0] = String.valueOf(hour);
//                        }
//                    }
//                    // Concatenate dateStr, time, and timeOfDay
//                    String formattedDateTime = dateStr + " at " + timeParts[0] + ":" + timeParts[1] + " " + timeOfDay;
//                    txtCancellation2DepartureTime.setText(formattedDateTime);
//                }
//            }
//
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//
//        });
//
//        DatabaseReference myRef1 = database.getReference();
//        myRef1.child("BookedTicket").child("-NwASRIkAJewELKUkMSg").addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if (snapshot.exists()) {
//                    long totalPriceDeparture = snapshot.child("departure").child("totalPrice").getValue(Long.class);
//                    long totalPriceReturn = snapshot.child("return").child("totalPrice").getValue(Long.class);
//                    long totalPayment = totalPriceDeparture + totalPriceReturn;
//                    String formattedTotalPayment = String.format(Locale.getDefault(), "VND",totalPayment);
//                    txtCancellation2TotalPayment.setText(formattedTotalPayment);
//                }
//            }
//
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//
//        });
//        myRef1.child("BookedTicket").child("-NwASRIkAJewELKUkMSg").addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if (snapshot.exists()) {
//                    String bookedTime = snapshot.child("bookedTime").getValue(String.class);
//                    SimpleDateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss 'GMT'Z yyyy");
//                    try {
//                        Date date = dateFormat.parse(bookedTime);
//
//                        // Format the date and time
//                        SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
//                        SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm");
//
//                        // Extract formatted date and time strings
//                        String DDate = dateFormatter.format(date);
//                        String DTime = timeFormatter.format(date);
//
//                        // Now you have DTime and DDate extracted from bookedTime
//
//                        // Assuming calculateRefund(DTime, DDate) returns the refund percentage
//                        int refundPercentage = calculateRefund(bookedTime, DTime);
//                        txtCancellation2Refund.setText(refundPercentage);
//
//                        // Parse the booked time to compare with DTime
//                        String[] bookedTimeParts = DTime.split(":");
//                        int bookedHour = Integer.parseInt(bookedTimeParts[0]);
//
//                        // Assuming DTime is in the format "HH:mm"
//                        String[] DTimeParts = DTime.split(":");
//                        int DHour = Integer.parseInt(DTimeParts[0]);
//
//                        // Compare bookedHour with DHour to decide the refund percentage
//                        if (bookedHour >= DHour) {
//                            // If booked hour is greater than or equal to departure hour, full refund
//                            refundPercentage = 100;
//                        }
//
//                        // Calculate total price, cancellation fee, and refundable amount
//                        long totalPriceDeparture1 = snapshot.child("departure").child("totalPrice").getValue(Long.class);
//                        long totalPriceReturn1 = snapshot.child("return").child("totalPrice").getValue(Long.class);
//                        int totalPay = (int) (totalPriceDeparture1 + totalPriceReturn1);
//                        int cancellationFee = totalPay * (100 - refundPercentage) / 100;
//                        String cancelFee = "- " + cancellationFee;
//                        txtCancellation2CancellationFee.setText(cancelFee);
//                        int refundableAmount = totalPay * refundPercentage / 100;
//                        txtCancellation2RefundableAmount.setText(refundableAmount);
//
//                    } catch (ParseException e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//
//        });
//
//}
//
//    private int calculateRefund(String bookedTime, String DTime) {
//        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm");
//
//        try {
//            Date bookedDate = format.parse(bookedTime);
//            Date departureDate = format.parse(DTime);
//
//            // Calculate time difference in hours
//            long timeDifferenceMillis = departureDate.getTime() - bookedDate.getTime();
//            long timeDifferenceHours = timeDifferenceMillis / (60 * 60 * 1000);
//
//            // Apply refund rules
//            if (timeDifferenceHours >= 24) {
//                return 100;
//            } else if (timeDifferenceHours >= 12) {
//                return 50;
//            } else if (timeDifferenceHours >= 6) {
//                return 30;
//            } else {
//                return 0;
//            }
//        } catch (ParseException e) {
//            e.printStackTrace();
//            return 0; // Default to 0 refund percentage in case of parsing error
//        }
//    }

}