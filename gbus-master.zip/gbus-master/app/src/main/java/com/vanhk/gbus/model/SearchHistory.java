package com.vanhk.gbus.model;

public class SearchHistory {
    private String searchId;
    private String searchDepartureLocation;
    private String searchArrivalLocation;
    private String searchDepartureDate;
    private String searchReturnDate;

    public SearchHistory(String searchId, String searchDepartureLocation, String searchArrivalLocation, String searchDepartureDate, String searchReturnDate) {
        this.searchId = searchId;
        this.searchDepartureLocation = searchDepartureLocation;
        this.searchArrivalLocation = searchArrivalLocation;
        this.searchDepartureDate = searchDepartureDate;
        this.searchReturnDate = searchReturnDate;
    }

    public SearchHistory() {
    }

    public String getSearchId() {
        return searchId;
    }

    public void setSearchId(String searchId) {
        this.searchId = searchId;
    }

    public String getSearchDepartureLocation() {
        return searchDepartureLocation;
    }

    public void setSearchDepartureLocation(String searchDepartureLocation) {
        this.searchDepartureLocation = searchDepartureLocation;
    }

    public String getSearchArrivalLocation() {
        return searchArrivalLocation;
    }

    public void setSearchArrivalLocation(String searchArrivalLocation) {
        this.searchArrivalLocation = searchArrivalLocation;
    }

    public String getSearchDepartureDate() {
        return searchDepartureDate;
    }

    public void setSearchDepartureDate(String searchDepartureDate) {
        this.searchDepartureDate = searchDepartureDate;
    }

    public String getSearchReturnDate() {
        return searchReturnDate;
    }

    public void setSearchReturnDate(String searchReturnDate) {
        this.searchReturnDate = searchReturnDate;
    }
}
