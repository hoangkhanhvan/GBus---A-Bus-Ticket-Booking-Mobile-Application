package com.vanhk.gbus.model;

import android.graphics.Bitmap;

public class TripDetail4 {
    private String Description;
    private String Title;
    private String _id;
    private Bitmap Image;

    public TripDetail4() {
    }

    public TripDetail4(String description, String title, String _id, Bitmap image) {
        Description = description;
        Title = title;
        this._id = _id;
        Image = image;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public Bitmap getImage() {
        return Image;
    }

    public void setImage(Bitmap image) {
        Image = image;
    }
}
