package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.model.Account;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.PassengerInfo;
import com.vanhk.gbus.model.Ticket;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class PassengerInformationActivity extends AppCompatActivity {

    EditText edtPassengerInformationName, edtPassengerInformationPhoneNumber, edtPassengerInformationEmail;
    ImageView imgPassengerInformationFlag, imgPassengerInformationBack;
    Spinner spinnerPassengerInformationPhoneCode;
    TextView txtPassengerInformationPrice, txtSubTotalTicket;
    Button btnPassengerInformationContinue;
    DatabaseReference myRef;
    DatabaseReference userRef;
    FirebaseAuth auth;
    FirebaseDatabase database;
    String TAG = "FIREBASE";
    String accountId;
    ArrayList<String> search;

    ProgressDialog progressDialog; // Declare ProgressDialog

    BroadcastReceiver internetReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Toast.makeText(context, "Internet changed", Toast.LENGTH_LONG).show();
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            if (networkInfo != null && networkInfo.isConnected()) {
                btnPassengerInformationContinue.setEnabled(true);
            } else {
                btnPassengerInformationContinue.setBackgroundColor(R.drawable.button_background_disable);
                btnPassengerInformationContinue.setEnabled(false);
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passenger_information);
        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        addViews();
        addEvents();

        loadAccountData();

        calculateSubtotal();

        spinnerPassengerInformationPhoneCode.setSelection(4); // +84
    }



    private void calculateSubtotal() {
//        tính subtotal price + number of tickets
    }

    private void loadAccountData() {
        progressDialog.show();
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String accountId = sharedPreferences.getString("accountId","");
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("account").child(accountId).child("userInfo");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                edtPassengerInformationPhoneNumber.setText(snapshot.child("account_phone_number").getValue(String.class));
                edtPassengerInformationEmail.setText(snapshot.child("account_email").getValue(String.class));
                edtPassengerInformationName.setText(snapshot.child("account_name").getValue(String.class));
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    private boolean isValidPhoneNumber(String userNameOrPhoneNumber) {
        String phonePattern = "^\\d{10}$";
        return userNameOrPhoneNumber.matches(phonePattern);
    }

    private boolean isValidEmail(String enteredUserName) {
        String emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        return enteredUserName.matches(emailPattern);
    }

    private void addEvents() {
        imgPassengerInformationBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnPassengerInformationContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show(); // Show ProgressDialog when continue button is clicked
                //Kiểm tra dữ liệu đủ chưa
                String name = edtPassengerInformationName.getText().toString().trim();
                String phoneNumber = edtPassengerInformationPhoneNumber.getText().toString().trim();
                String email = edtPassengerInformationEmail.getText().toString().trim();
                if (email.isEmpty() || !isValidEmail(email)) {
                    progressDialog.dismiss();
                    return;
                }
                if (!isValidPhoneNumber(phoneNumber)) {
                    progressDialog.dismiss();
                    return;
                }

                // Kiểm tra xem các trường thông tin đã được nhập đầy đủ hay không
                if (name.isEmpty() || phoneNumber.isEmpty() || email.isEmpty()) {
                    // Hiển thị thông báo lỗi nếu các trường thông tin chưa được nhập đầy đủ
                    Toast.makeText(PassengerInformationActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss(); // Dismiss ProgressDialog if fields are not filled
                    return;
                } else {
                    // Lưu dữ liệu vào Firebase
//                    updateAccountData(phoneNumber, email);
//                    updateUserData(name);

                    PassengerInfo passengerInfo = new PassengerInfo();
                    passengerInfo.setName(edtPassengerInformationName.getText().toString());
                    passengerInfo.setEmail(edtPassengerInformationEmail.getText().toString());
                    passengerInfo.setPhoneNumber(edtPassengerInformationPhoneNumber.getText().toString());

                    MySharedPreferences.saveObject(PassengerInformationActivity.this,"PassengerInfo",passengerInfo);

                    Intent intent = new Intent(PassengerInformationActivity.this, BookingPreview1Activity.class);
                    //Start BookingPreview
                    startActivity(intent);


                    // Hiển thị toast message thông báo lưu thành công
                    Toast.makeText(PassengerInformationActivity.this, "Personal Profile saved successfully", Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss(); // Dismiss ProgressDialog after saving successfully
                }

                Intent intent = new Intent(PassengerInformationActivity.this, BookingPreview1Activity.class);

                intent.putStringArrayListExtra("search",search);
                startActivity(intent);
                progressDialog.dismiss(); // Dismiss ProgressDialog when starting new activity
            }
        });

        edtPassengerInformationEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String emailInput = s.toString();
                if (!isValidEmail(emailInput)){
                    edtPassengerInformationEmail.setError("Invalid Email");
                }
            }
        });
        // Sự kiện sau khi thay đổi văn bản trong edtPhoneNumber
        edtPassengerInformationPhoneNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String newPhoneNumber = s.toString();
                if (!isValidPhoneNumber(newPhoneNumber)){
                    edtPassengerInformationPhoneNumber.setError("Invalid Phone Number");
                }
            }
        });

        // Tạo mảng chứa danh sách country code
        String[] phoneCodes = {"+1", "+44", "+61", "+81", "+84", "+86"};

        // Tạo ArrayAdapter để hiển thị danh sách country code
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, phoneCodes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Set adapter cho Spinner
        spinnerPassengerInformationPhoneCode.setAdapter(adapter);
        spinnerPassengerInformationPhoneCode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // Xử lý khi người dùng chọn một country code
                updateFlagImage(parentView.getItemAtPosition(position).toString());
                spinnerPassengerInformationPhoneCode.setSelection(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Không có country code nào được chọn
            }
        });
    }

    //    private void updateUserData(String name) {
//        userRef = FirebaseDatabase.getInstance().getReference().child("users").child("user_id");
//        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if(snapshot.exists()){
//                    Account account = snapshot.getValue(Account.class);
//                    if(account != null) {
//                        String currentName = account.getAccountName();
//                        if(!name.equals(currentName)){
//                            Map<String, Object> userData = new HashMap<>();
//                            userData.put("account_name", name);
//
//                            userRef.child("user_id").setValue(userData);
//                        }
//                    }
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//                Log.w(TAG, "updateUserData:onCancelled", error.toException());
//            }
//        });
//    }
//
//    private void updateAccountData(String newPhoneNumber, String newEmail) {
//        myRef = FirebaseDatabase.getInstance().getReference().child("account").child("account1");
//        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if(snapshot.exists()){
//                    Account account = snapshot.getValue(Account.class);
//                    if(account != null) {
//                        String currentEmail = account.getAccountUserName();
//                        String currentPhoneNumber = account.getAccountPhoneNumber();
//
//                        if (!newPhoneNumber.equals(currentPhoneNumber) || !newEmail.equals(currentEmail)) {
//                            // Tạo HashMap để cập nhật dữ liệu
//                            Map<String, Object> updateData = new HashMap<>();
//                            updateData.put("accountPhoneNumber", newPhoneNumber);
//                            updateData.put("accountUserName", newEmail);
//
//                            // cập nhật dữ liệu vào Firebase
//                            myRef.updateChildren(updateData).addOnSuccessListener(new OnSuccessListener<Void>() {
//                                @Override
//                                public void onSuccess(Void unused) {
//                                    Toast.makeText(getApplicationContext(), "Updated account successfully", Toast.LENGTH_SHORT).show();
//                                }
//                            }).addOnFailureListener(new OnFailureListener() {
//                                @Override
//                                public void onFailure(@NonNull Exception e) {
//                                    Toast.makeText(getApplicationContext(), "Data update failed", Toast.LENGTH_SHORT).show();
//                                }
//                            });
//                        }
//                    }
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//                Log.w(TAG, "updateAccountData:onCancelled", error.toException());
//            }
//        });
//    }
//
//    // cập nhật hình ảnh cờ tương ứng với country code được chọn
    private void updateFlagImage(String countryCode) {
        switch (countryCode) {
            case "+1":
                imgPassengerInformationFlag.setImageResource(R.drawable.flag_usa);
                break;
            case "+44":
                imgPassengerInformationFlag.setImageResource(R.drawable.flag_uk);
                break;
            case "+61":
                imgPassengerInformationFlag.setImageResource(R.drawable.flag_australia);
                break;
            case "+81":
                imgPassengerInformationFlag.setImageResource(R.drawable.flag_japan);
                break;
            case "+84":
                imgPassengerInformationFlag.setImageResource(R.drawable.img_flag);
                break;
            case "+86":
                imgPassengerInformationFlag.setImageResource(R.drawable.flag_china);
                break;
            default:
                // Do nothing or set a default image
                break;
        }
    }

    private void addViews() {
        edtPassengerInformationName = findViewById(R.id.edtPassengerInformationName);
        edtPassengerInformationPhoneNumber = findViewById(R.id.edtPassengerInformationPhoneNumber);
        edtPassengerInformationEmail = findViewById(R.id.edtPassengerInformationEmail);
        imgPassengerInformationFlag = findViewById(R.id.imgPassengerInformationFlag);
        spinnerPassengerInformationPhoneCode = findViewById(R.id.spinnerPassengerInformationPhoneCode);
        txtPassengerInformationPrice = findViewById(R.id.txtPassengerInformationPrice);
        btnPassengerInformationContinue = findViewById(R.id.btnPassengerInformationContinue);
        txtSubTotalTicket = findViewById(R.id.txtSubTotalTicket);

        imgPassengerInformationBack = findViewById(R.id.imgPassengerInformationBack);


        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        accountId = sharedPreferences.getString("accountId","account1");
        String DTotalPrice = sharedPreferences.getString("DTotalPrice","0");
        String RTotalPrice = sharedPreferences.getString("RTotalPrice","0");

        Ticket DTicket = MySharedPreferences.getObject(this, "DTicket",Ticket.class);
        Ticket RTicket = MySharedPreferences.getObject(this, "RTicket",Ticket.class);

        boolean isReturn = sharedPreferences.getBoolean("isReturn",false);

        DTicket = MySharedPreferences.getObject(this,"DTicket", Ticket.class);

        Set<String> DSeat = sharedPreferences.getStringSet("DSeat",new HashSet<>());
        Set<String> RSeat = sharedPreferences.getStringSet("DSeat",new HashSet<>());

        txtPassengerInformationPrice.setText(String.valueOf(Integer.parseInt(DTotalPrice)+Integer.parseInt(RTotalPrice)));
        if (isReturn) {
            String totalSeat = String.valueOf(DSeat.size()+RSeat.size());
            txtSubTotalTicket.setText("Subtotal ("+totalSeat+" tickets)");
        } else {
            String totalSeat = String.valueOf(DSeat.size());
            txtSubTotalTicket.setText("Subtotal ("+totalSeat+" tickets)");
        }

        // Initialize Firebase components
        database = FirebaseDatabase.getInstance();
        userRef = database.getReference("user");
        myRef = database.getReference("account");
        auth = FirebaseAuth.getInstance();

        Intent getIntent = getIntent();
        search = getIntent.getStringArrayListExtra("search");

        String DLocation = sharedPreferences.getString("DLocation","");
        String ALocation = sharedPreferences.getString("ALocation","");
        String DDate = sharedPreferences.getString("DDate","");
        String RDate = sharedPreferences.getString("RDate","");

        TextView txtPassengerInformationDepartLocation = findViewById(R.id.txtPassengerInformationDepartLocation);
        TextView txtPassengerInformationArrivalLocation = findViewById(R.id.txtPassengerInformationArrivalLocation);

        txtPassengerInformationDepartLocation.setText(DLocation);
        txtPassengerInformationArrivalLocation.setText(ALocation);
    }
}
