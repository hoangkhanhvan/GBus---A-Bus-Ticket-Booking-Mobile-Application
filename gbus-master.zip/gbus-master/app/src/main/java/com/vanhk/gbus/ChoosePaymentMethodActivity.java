package com.vanhk.gbus;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.PaymentAdapter;
import com.vanhk.gbus.adapter.VoucherAdapter;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.Payment;
import com.vanhk.gbus.model.Voucher;

import java.util.ArrayList;

public class ChoosePaymentMethodActivity extends AppCompatActivity {
    ImageButton btnChoosePaymentMethod1Back;
    RecyclerView rvChoosePaymentMethod1;
    Button btnChoosePaymentMethod1Confirm;

    private String selectedRouteId;
    private PaymentAdapter paymentAdapter;

    ProgressDialog progressDialog; // ProgressDialog instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_payment_method);

        // Initialize ProgressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading Payment Methods...");
        progressDialog.setCancelable(false);

        // Add logging to trace the flow
        Log.d(TAG, "onCreate: Initializing views");

        addViews();

        Log.d(TAG, "onCreate: Views initialized");

        // Initialize RecyclerView and set adapter
        paymentAdapter = new PaymentAdapter(new ArrayList<>());
        rvChoosePaymentMethod1.setLayoutManager(new LinearLayoutManager(this));
        rvChoosePaymentMethod1.setAdapter(paymentAdapter);
        addViews();

        //back previous screen
        btnChoosePaymentMethod1Back.setOnClickListener(v -> onBackPressed());

        // Navigate to Payment2_2Activity


        loadData();
    }

    private void addViews() {
        btnChoosePaymentMethod1Back = findViewById(R.id.btnChoosePaymentMethod1Back);
        rvChoosePaymentMethod1 = findViewById(R.id.rvChoosePaymentMethod1);
        btnChoosePaymentMethod1Confirm = findViewById(R.id.btnChoosePaymentMethod1Confirm);

        btnChoosePaymentMethod1Confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectPaymentMethod();
            }
        });
    }

    private void selectPaymentMethod() {
        int selectedPosition = paymentAdapter.getSelectedPosition();
        if (selectedPosition != RecyclerView.NO_POSITION) {
            Payment payment = paymentAdapter.paymentArrayList.get(selectedPosition);
            MySharedPreferences.saveObject(this,"PaymentMethod", payment);
            Payment savedPayment = MySharedPreferences.getObject(this,"PaymentMethod", Payment.class);
            Toast.makeText(this, payment.toString(), Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(this, Payment1Activity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Please select a payment method", Toast.LENGTH_SHORT).show();
        }
    }



    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, Payment1Activity.class);
        startActivity(intent);
        finish();
    }
    private void loadData() {
        progressDialog.show();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("payment_method");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    Payment payment = new Payment();
                    payment.setMethod(data.child("method").getValue(String.class));

                    // Assuming image is stored as a base64 string
                    String imageBase64 = data.child("image").getValue(String.class);
                    if (imageBase64 != null) {
                        payment.setImage(imageBase64);
                    }
                    paymentAdapter.add(payment);
                }
                progressDialog.dismiss(); // Dismiss progressDialog after data loading is complete
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss(); // Dismiss progressDialog if data loading is cancelled
                Log.e(TAG, "loadData:onCancelled", databaseError.toException());
            }
        });
    }
}