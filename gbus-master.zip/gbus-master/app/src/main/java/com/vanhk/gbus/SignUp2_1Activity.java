package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;

import com.chaos.view.PinView;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class SignUp2_1Activity extends AppCompatActivity {
    TextView txtSignUp21PhoneNumber;
    PinView pinOTPSignUp21;
    TextView txtSignUp1CountDown;
    TextView txtSignUp21Resend;
    Toolbar toolbarBack;
    FirebaseAuth auth;

    private CountDownTimer countDownTimer;
    private ProgressDialog progressDialog; // Declare ProgressDialog variable

    private String accountPhoneNumber;
    private String ms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up21);
        addViews();
        addEvents();

        // Initialize the progressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Verifying OTP..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable
    }

    private void addEvents() {
        toolbarBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        txtSignUp21Resend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show the ProgressDialog when resend button is clicked
                progressDialog.show();
                countdown();
                PhoneAuthOptions options =
                        PhoneAuthOptions.newBuilder(auth)
                                .setPhoneNumber(accountPhoneNumber)
                                .setTimeout(60L, TimeUnit.SECONDS)
                                .setActivity(SignUp2_1Activity.this)
                                // If no activity is passed, reCAPTCHA verification can not be used.
                                .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                                    @Override
                                    public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                                        String code = phoneAuthCredential.getSmsCode();
                                        if (code != null) {
                                            pinOTPSignUp21.setText(code);
                                            verifyCode(code);
                                        }
                                        Intent intent = new Intent(SignUp2_1Activity.this, SignUp3Activity.class);
                                        intent.putExtra("mobile", accountPhoneNumber);
                                        intent.putExtra("s", ms);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void onVerificationFailed(@NonNull FirebaseException e) {
                                        progressDialog.dismiss(); // Dismiss the ProgressDialog
                                        Toast.makeText(SignUp2_1Activity.this, "Verification Failed", Toast.LENGTH_LONG).show();
                                    }

                                    @Override
                                    public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                        super.onCodeSent(s, forceResendingToken);
                                        progressDialog.dismiss(); // Dismiss the ProgressDialog
                                        ms = s;
                                    }
                                })
                                .build();
                PhoneAuthProvider.verifyPhoneNumber(options);

            }
        });

        //txtSignUp21PhoneNumber.setText(String.format(
        //"%s", getIntent().getStringExtra("mobile")
        //));
        accountPhoneNumber = getIntent().getStringExtra("mobile");
        ms = getIntent().getStringExtra("s");
    }

    private void countdown() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        countDownTimer = new CountDownTimer(60000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                txtSignUp1CountDown.setText((millisUntilFinished / 1000) + "s");
            }

            @Override
            public void onFinish() {
                pinOTPSignUp21.setVisibility(View.VISIBLE);
            }
        }.start();
    }

    private void verifyCode(String code) {
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(ms, code);
        code = pinOTPSignUp21.getText().toString();
        if (!code.isEmpty()) {
            verifyCode(code);
        }
    }

    private void addViews() {
        txtSignUp21PhoneNumber = findViewById(R.id.txtSignUp21PhoneNumber);
        txtSignUp1CountDown = findViewById(R.id.txtSignUp1CountDown);
        txtSignUp21Resend = findViewById(R.id.txtSignUp21Resend);
        pinOTPSignUp21 = findViewById(R.id.pinOTPSignUp21);
        toolbarBack = findViewById(R.id.toolbarBack);
        auth = FirebaseAuth.getInstance();

    }
}