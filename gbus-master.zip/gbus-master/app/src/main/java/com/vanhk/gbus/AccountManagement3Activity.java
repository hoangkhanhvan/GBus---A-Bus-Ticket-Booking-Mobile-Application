package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AccountManagement3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_management3);
    }
}