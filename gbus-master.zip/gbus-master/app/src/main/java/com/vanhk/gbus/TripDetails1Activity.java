package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.PointAdapter;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.Point;
import com.vanhk.gbus.model.Ticket;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class TripDetails1Activity extends AppCompatActivity {
    TextView txtTripDetails1DepartLocation,txtTripDetails1ArrivalLocation
            ,txtTripdetails1Tag,txtTripDetails1DepartDate;
    ImageView imgTripDetails1Close;
    TextView txtTripDetails1PickUpDropOff,txtTripDetails1Amenities,txtTripDetails1BusFeature, txtTripDetails1PickUp;
    LinearLayout llTripDetailsReviews,llTripDetails1PickUp,llTripDetails1DropOff;
    ListView lvTripDetails1Location;
    Button btnTripDetails1Book;
    PointAdapter pointAdapter;
    String TAG = "FIREBASE";
    Ticket selectedTicket;

    ArrayList<Point> pickUpPoints, dropOffPoints;

    // Declare ProgressDialog variable
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_details1);
        addViews();
        addEvents();

        // Initialize the progressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable
    }

    private void addEvents() {
        txtTripDetails1BusFeature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TripDetails1Activity.this,TripDetails5Activity.class);
                startActivity(intent);
            }
        });
        txtTripDetails1Amenities.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TripDetails1Activity.this,TripDetails4Activity.class);
                startActivity(intent);
            }
        });
        llTripDetailsReviews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TripDetails1Activity.this,TripDetails3Activity.class);
                startActivity(intent);
            }
        });
        imgTripDetails1Close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TripDetails1Activity.this,ResultList1Activity.class);
                startActivity(intent);
            }
        });
        btnTripDetails1Book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show the ProgressDialog when "Book" button is clicked
                progressDialog.show();

                Intent getIntent = getIntent();
                String accountId = getIntent.getStringExtra("accountId");

                Intent intent = new Intent(TripDetails1Activity.this, ChooseSeat_Depart_1Activity.class);

                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("departureTicketId", selectedTicket.get_id());
                editor.apply();

                ArrayList<String> search = getIntent.getStringArrayListExtra("search");

                intent.putExtra("ticket",selectedTicket);
                intent.putStringArrayListExtra("search",search);
                MySharedPreferences.saveObject(TripDetails1Activity.this, "DTicket", selectedTicket);
                boolean isReturn = sharedPreferences.getBoolean("isReturn",false);
                if (isReturn) {
                    MySharedPreferences.saveObject(TripDetails1Activity.this, "RTicket", selectedTicket);

                } else {
                    MySharedPreferences.saveObject(TripDetails1Activity.this, "DTicket", selectedTicket);

                }

                startActivity(intent);
                // Dismiss the ProgressDialog after starting the new activity
                progressDialog.dismiss();
            }
        });
        llTripDetails1DropOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TripDetails1Activity.this,TripDetails2Activity.class);
                startActivity(intent);
            }
        });
        imgTripDetails1Close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TripDetails1Activity.this,ResultList1Activity.class);
                startActivity(intent);
            }
        });
    }

    private void addViews() {
        txtTripDetails1DepartLocation=findViewById(R.id.txtTripDetails1DepartLocation);
        txtTripDetails1ArrivalLocation=findViewById(R.id.txtTripDetails1ArrivalLocation);
        txtTripdetails1Tag=findViewById(R.id.txtTripDetails1Tag);
        txtTripDetails1DepartDate=findViewById(R.id.txtTripDetails1DepartDate);
        imgTripDetails1Close=findViewById(R.id.imgTripDetails1Close);
        txtTripDetails1PickUpDropOff=findViewById(R.id.txtTripDetails1PickupDropOff);
        txtTripDetails1Amenities=findViewById(R.id.txtTripDetails1Amenities);
        txtTripDetails1BusFeature=findViewById(R.id.txtTripDetails1BusFeatures);
        llTripDetailsReviews=findViewById(R.id.llTripDetails1Reviews);
        llTripDetails1PickUp=findViewById(R.id.llTripDetails1PickUp);
        llTripDetails1DropOff=findViewById(R.id.llTripDetails1DropOff);
        txtTripDetails1PickUp=findViewById(R.id.txtTripDetails1PickUp);



        btnTripDetails1Book=findViewById(R.id.btnTripDetails1Book);

        lvTripDetails1Location=findViewById(R.id.lvTripDetails1Location);
        pointAdapter = new PointAdapter(TripDetails1Activity.this,R.layout.lvtripdetails1pickuplocation);
        lvTripDetails1Location.setAdapter(pointAdapter);

        loadData();

    }

    private void loadData() {
        selectedTicket = MySharedPreferences.getObject(TripDetails1Activity.this,"SelectedTicket",Ticket.class);

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String RouteId = sharedPreferences.getString("RouteId","");

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("RouteWithPoints");
        ArrayList<Point> count = new ArrayList<>();
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot data: dataSnapshot.getChildren()) {

                    String _id = data.child("_id").getValue(String.class);
                    if (_id.equals(RouteId)) {
                        for (DataSnapshot points: data.child("PickUpPoints").getChildren()) {
                            Point point = new Point();
                            Long time = points.child("Time").getValue(Long.class);
                            if (time != null) {
                                point.setPoint(points.child("Point").getValue(String.class));
                                point.setAddress(points.child("Address").getValue(String.class));
                                point.setShuttleBus(points.child("ShuttleBus").getValue(Boolean.class));
                                String timeStr = calculateTime(selectedTicket.getDTime(),time.intValue());
                                point.setTime(timeStr);
                                String dateStr = calculateDate(selectedTicket.getDate(),selectedTicket.getDTime(),time.intValue());
                                point.setDate(dateStr);
                                pointAdapter.add(point);
                                count.add(point);
                            }
                            txtTripDetails1PickUp.setText("("+lvTripDetails1Location.getAdapter().getCount()+")");
                        }
                    }

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e(TAG, "loadPost:onCancelled", databaseError.toException());
            }
        });

    }

    public static String calculateDate(String dateString, String timeString, int minutesToAdd) {
        try {
            // Parse the input date and time strings
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(dateFormat.parse(dateString + " " + timeString));

            // Add the minutes
            calendar.add(Calendar.MINUTE, minutesToAdd);

            // Get the updated date
            SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd/MM");
            return outputDateFormat.format(calendar.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return null; // Return null if parsing fails
        }
    }


    public static String calculateTime(String timeString, int minutesToAdd) {
        // Split the time string into hours and minutes
        String[] parts = timeString.split(":");
        int hours = Integer.parseInt(parts[0]);
        int minutes = Integer.parseInt(parts[1]);

        // Convert time to minutes
        int totalMinutes = hours * 60 + minutes;

        // Add the minutes
        totalMinutes += minutesToAdd;

        // Adjust if the total minutes is negative
        if (totalMinutes < 0) {
            totalMinutes += 24 * 60; // Add 24 hours worth of minutes
        }

        // Calculate the new hours and minutes
        int newHours = totalMinutes / 60;
        int newMinutes = totalMinutes % 60;

        // Format the new time
        String newTimeString = String.format("%02d:%02d", newHours, newMinutes);
        return newTimeString;
    }
}