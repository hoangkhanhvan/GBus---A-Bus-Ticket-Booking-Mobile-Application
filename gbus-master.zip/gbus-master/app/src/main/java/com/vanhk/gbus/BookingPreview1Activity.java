package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.model.Booked;
import com.vanhk.gbus.model.BookedTicket;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.PassengerInfo;
import com.vanhk.gbus.model.Point2;
import com.vanhk.gbus.model.Ticket;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class BookingPreview1Activity extends AppCompatActivity {
    TextView txtBookingPreview1BusNameDepart, txtBookingPreview1DescriptionDepart, txtBookingPreview1SeatNumberDepart,
            txtBookingPreview11, txtBookingPreview13, txtBookingPreview15, txtBookingPreview17,
            txtBookingPreview12, txtBookingPreview14, txtBookingPreview7, txtBookingPreview19, txtBookingPreview1PassengerNumber;

    TextView txtBookingPreview1BusNameReturn, txtBookingPreview1DescriptionReturn, BookingPreview1ReturnNumber,
            textView78, textView79, txtBookingPreview21, txtBookingPreview23,
            textView80, textView81, textView82, txtBookingPreview25, textView73;

    TextView txtBookingPreview27, txtBookingPreview29, textView85, txtBookingPreview1Price, txtBookingPreview1EditPassengerInfo,
            txtBookingPreview1Depart1, txtBookingPreview1Depart2, txtBookingPreview1Return1, txtBookingPreview1Return2;
    ImageView imgBookingPreview1ImgDepart, imgBookingPreview1ImgReturn;
    Button btnBookingPreview1Book;

    Ticket DTicket, RTicket;
    PassengerInfo passengerInfo;
    Set<String> DSeat, RSeat;
    Point2 DPickUpPoint, DDropOffPoint, RPickUpPoint, RDropOffPoint;
    String DTotalPrice, RTotalPrice;
    LinearLayout llReturnTicket;
    boolean isReturn;
    ArrayList<String> search;
    ImageView imgBookingPreview1Back;

    private ProgressDialog progressDialog;
    private static final String CHANNEL_ID = "BOOKING";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_preview1);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Processing...");
        progressDialog.setCancelable(false);

        addViews();
        addEvents();
    }

    @Override
    protected void onResume() {
        super.onResume();
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Processing...");
        progressDialog.setCancelable(false);

        addViews();
        addEvents();
    }

    private void addEvents() {
        txtBookingPreview1EditPassengerInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), PassengerInformationActivity.class);
                startActivity(intent);
                finish();
            }
        });
        txtBookingPreview1Depart1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), EditPickupPoint_Depart1Activity.class);
                intent.putExtra("Type","PickUpPoints");
                intent.putExtra("Route", DTicket.getRoute());
                intent.putExtra("Ticket",DTicket);
                intent.putExtra("TicketType", "Depart");
                Toast.makeText(BookingPreview1Activity.this, DTicket.getRoute(), Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });
        txtBookingPreview1Depart2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), EditPickupPoint_Depart1Activity.class);
                intent.putExtra("Type","DropOffPoints");
                intent.putExtra("Route", DTicket.getRoute());
                intent.putExtra("Ticket",DTicket);
                Toast.makeText(BookingPreview1Activity.this, DTicket.getRoute(), Toast.LENGTH_SHORT).show();

                intent.putExtra("TicketType", "Depart");
                startActivity(intent);
            }
        });
        txtBookingPreview1Return1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), EditPickupPoint_Depart1Activity.class);
                intent.putExtra("Type","PickUpPoints");
                intent.putExtra("Route", RTicket.getRoute());
                intent.putExtra("Ticket",RTicket);
                intent.putExtra("TicketType", "Return");
                startActivity(intent);
            }
        });
        txtBookingPreview1Return2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), EditPickupPoint_Depart1Activity.class);
                intent.putExtra("Type","DropOffPoints");
                intent.putExtra("Route", RTicket.getRoute());
                intent.putExtra("Ticket",RTicket);
                intent.putExtra("TicketType", "Return");
                startActivity(intent);
            }
        });
        imgBookingPreview1Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();

            }
        });
        btnBookingPreview1Book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processSaveTicket();
            }
        });
    }

    private void showNotification() {
        // Create an explicit intent for the activity you want to open when the notification is clicked

        // Create a notification builder
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_payment_2_2_gbus_logo)
                .setContentTitle("Booking success")
                .setContentText("Your Seat is hold in 15 minutes, please make payment!")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // Check if device is running Android Oreo or higher
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Create the notification channel
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, "Channel Name", NotificationManager.IMPORTANCE_HIGH);
            notificationChannel.enableVibration(true);
            notificationManager.createNotificationChannel(notificationChannel);
        }

        // Notify the system to display the notification
        notificationManager.notify(0, builder.build());
    }


    private void saveNotification(String DLocation, String ALocation, String accountId) {
        long negatedTimestamp = -1 * new Date().getTime();
        String ticketKey = Long.toString(negatedTimestamp);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Notification");

        Map<String, Object> userData = new HashMap<>();
        userData.put("Description", "Your ticket from " +DLocation+ " to "+ALocation+" has been held by the system. Please make payment to confirm the ticket.");
        userData.put("Image","data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAE1SURBVHgB7Za9agJBEMf/e1hESGGOFPkqlCRFCKkSrAJpErAKpEmRJs/gG+gb+BQWNoKVYCVYiZ2Ihcid4FchaiGoIJ67W3qz5y3cFYI/GLib3dnZmd2dXWb1nP+tgxyAGILFNhgyrGs7Fv+JIxzmRoiDC2IGQub4HURUDfXGGH6JRiN4eb7076BcsblY0CH1FeeScOnJFE1nK0oN0zyTQtusSb3WGqQ+E0i+XumY0Cm6vTknO+cLbah4uKcLARnBx/sdmc/k27WUfURfVWTKXQQ4PnVeekDUIldrtdZHsdSBDj/fjzLyfcgUDYYLSi1T8ff7BB0bjxS5qTdG0IV0YF6o9jp9PqSN4nyQayBotiZYLjfwg1epUDoIitN9cNgB4xczQoKJlwV/sqTFBwJGTJyPnd0BIcJSBzUR3fwAAAAASUVORK5CYII=");
        userData.put("Timestamp", new Date().getTime());
        userData.put("Title", "Your ticket is held");
        userData.put("_id", accountId+new Date().getTime());

        DatabaseReference newNotificationRef = myRef.child(accountId).child(ticketKey);
        newNotificationRef.setValue(userData);
    }


    private void processSaveTicket() {
        progressDialog.show();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("BookedTicket");

        // Using negative timestamp to ensure the new entry is at the top when ordered by key
        long negatedTimestamp = -1 * new Date().getTime();
        String ticketKey = Long.toString(negatedTimestamp);

        Booked DepartureTicket = new Booked();
        Booked ReturnTicket = new Booked();
        BookedTicket bookedTicket = new BookedTicket();

        DepartureTicket.setTicket(DTicket);
        DepartureTicket.setSeat(new ArrayList<>(DSeat));
        DepartureTicket.setTotalPrice(Integer.parseInt(DTotalPrice));
        DepartureTicket.setPickUpPoint(DPickUpPoint);
        DepartureTicket.setDropOffPoint(DDropOffPoint);
        DepartureTicket.setBus(DTicket.getBus());

        updateSeat(DSeat, DTicket.get_id());

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        String DLocation = sharedPreferences.getString("DLocation", "");
        String ALocation = sharedPreferences.getString("ALocation", "");
        String accountId = sharedPreferences.getString("accountId", "");

        if (isReturn) {
            ReturnTicket.setTicket(RTicket);
            ReturnTicket.setSeat(new ArrayList<>(RSeat));
            ReturnTicket.setTotalPrice(Integer.parseInt(RTotalPrice));

            DepartureTicket.setDLocation(ALocation);
            DepartureTicket.setALocation(DLocation);

            ReturnTicket.setDLocation(DLocation);
            ReturnTicket.setALocation(ALocation);
            updateSeat(RSeat, RTicket.get_id());
        } else {
            ReturnTicket.setTicket(new Ticket());
            ReturnTicket.setSeat(new ArrayList<>());
            ReturnTicket.setTotalPrice(0);
            DepartureTicket.setDLocation(DLocation);
            DepartureTicket.setALocation(ALocation);
        }

        ReturnTicket.setPickUpPoint(RPickUpPoint);
        ReturnTicket.setDropOffPoint(RDropOffPoint);
        ReturnTicket.setBus("");

        bookedTicket.setAccountId(accountId);
        bookedTicket.setBookedTime(String.valueOf(new Date()));
        bookedTicket.setDeparture(DepartureTicket);
        bookedTicket.setReturn(ReturnTicket);
        bookedTicket.setStatus("Unpaid");
        bookedTicket.setPassenger(passengerInfo);

        DatabaseReference newTicketRef = myRef.child(ticketKey);
        newTicketRef.setValue(bookedTicket).addOnSuccessListener(unused -> {
            editor.putString("TransactionNumber", ticketKey);
            editor.apply();
            newTicketRef.child("TransactionNumber").setValue(ticketKey).addOnSuccessListener(aVoid -> {
                editor.putString("BookedTicketId", ticketKey);
                editor.apply();
                showNotification();
                saveNotification(DLocation, ALocation, bookedTicket.getAccountId());
                progressDialog.dismiss();
                Toast.makeText(BookingPreview1Activity.this, "Your Ticket is created", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, Payment1Activity.class);
                startActivity(intent);
            });
            if (!isReturn) {
                newTicketRef.child("return").removeValue();
            }
        });
    }

    private void updateSeat(Set<String> seat, String _id) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference ticketsRef = database.getReference("Tickets");

        Toast.makeText(this, _id, Toast.LENGTH_SHORT).show();

        // Listen for the specific ticket data once
        ticketsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // Iterate over all tickets to find the right one
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String id = snapshot.child("_id").getValue(String.class);
                    if (id != null && id.equals(_id)) {
                        // Found the correct ticket, now update the seats
                        DatabaseReference seatRef = snapshot.child("Seat").getRef();
                        for (String s : seat) {
                            seatRef.push().setValue(s); // Add new seats
                        }
                        return; // Exit after updating the correct ticket
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("Firebase", "Error updating seats", error.toException());
            }
        });
    }



    private void addViews() {
        txtBookingPreview1EditPassengerInfo=findViewById(R.id.txtBookingPreview1EditPassengerInfo);

        txtBookingPreview1Depart1=findViewById(R.id.txtBookingPreview1Depart1);
        txtBookingPreview1Depart2=findViewById(R.id.txtBookingPreview1Depart2);
        txtBookingPreview1Return1=findViewById(R.id.txtBookingPreview1Return1);
        txtBookingPreview1Return2=findViewById(R.id.txtBookingPreview1Return2);

        btnBookingPreview1Book=findViewById(R.id.btnBookingPreview1Book);
        imgBookingPreview1Back=findViewById(R.id.imgBookingPreview1Back);

        //Departure Ticket
        txtBookingPreview1BusNameDepart=findViewById(R.id.txtBookingPreview1BusNameDepart);
        txtBookingPreview1DescriptionDepart=findViewById(R.id.txtBookingPreview1DescriptionDepart);
        imgBookingPreview1ImgDepart=findViewById(R.id.imgBookingPreview1ImgDepart);
        txtBookingPreview1SeatNumberDepart=findViewById(R.id.txtBookingPreview1SeatNumberDepart);
        txtBookingPreview11=findViewById(R.id.txtBookingPreview11);
        txtBookingPreview13=findViewById(R.id.txtBookingPreview13);
        txtBookingPreview15=findViewById(R.id.txtBookingPreview15);
        txtBookingPreview17=findViewById(R.id.txtBookingPreview17);
        txtBookingPreview12=findViewById(R.id.txtBookingPreview12);
        txtBookingPreview14=findViewById(R.id.txtBookingPreview14);
        txtBookingPreview7=findViewById(R.id.txtBookingPreview7);
        txtBookingPreview19=findViewById(R.id.txtBookingPreview19);
        txtBookingPreview1PassengerNumber=findViewById(R.id.txtBookingPreview1PassengerNumber);

        //Return Ticket
        txtBookingPreview1BusNameReturn=findViewById(R.id.txtBookingPreview1BusNameReturn);
        txtBookingPreview1DescriptionReturn=findViewById(R.id.txtBookingPreview1DescriptionReturn);
        BookingPreview1ReturnNumber=findViewById(R.id.BookingPreview1ReturnNumber);
        imgBookingPreview1ImgReturn=findViewById(R.id.imgBookingPreview1ImgReturn);
        textView73=findViewById(R.id.textView73);
        textView78=findViewById(R.id.textView78);
        textView79=findViewById(R.id.textView79);
        txtBookingPreview21=findViewById(R.id.txtBookingPreview21);
        txtBookingPreview23=findViewById(R.id.txtBookingPreview23);
        textView80=findViewById(R.id.textView80);
        textView81=findViewById(R.id.textView81);
        textView82=findViewById(R.id.textView82);
        txtBookingPreview25=findViewById(R.id.txtBookingPreview25);

        //Passenger Info
        txtBookingPreview27=findViewById(R.id.txtBookingPreview27);
        txtBookingPreview29=findViewById(R.id.txtBookingPreview29);
        textView85=findViewById(R.id.textView85);

        //Control
        txtBookingPreview1Price=findViewById(R.id.txtBookingPreview1Price);
        TextView txtSubTotalTicket=findViewById(R.id.txtSubTotalTicket);

        llReturnTicket=findViewById(R.id.llReturnTicket);

        TextView txtBookingPreview1BusName = findViewById(R.id.txtBookingPreview1BusName);
        TextView txtBookingPreview1DepartLocation = findViewById(R.id.txtBookingPreview1DepartLocation);
        TextView txtBookingPreview1ArrivalLocation = findViewById(R.id.txtBookingPreview1ArrivalLocation);
        TextView txtBookingPreview1TagDepartTrip = findViewById(R.id.txtBookingPreview1TagDepartTrip);
        TextView txtBookingPreview1Date = findViewById(R.id.txtBookingPreview1Date);
        TextView textView84 = findViewById(R.id.textView84);
        TextView txtShuttleAddress2 = findViewById(R.id.txtShuttleAddress2);
        TextView txtShuttleAddress3 = findViewById(R.id.txtShuttleAddress3);
        TextView txtShuttleAddress = findViewById(R.id.txtShuttleAddress);

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String BusDes = sharedPreferences.getString("BusDes","Limousine");
        isReturn = sharedPreferences.getBoolean("isReturn",false);

        DTicket = MySharedPreferences.getObject(this,"DTicket", Ticket.class);

        DSeat = sharedPreferences.getStringSet("DSeat",new HashSet<>());

        DPickUpPoint = MySharedPreferences.getObject(this,"DPickUpPoint",Point2.class);
        DDropOffPoint = MySharedPreferences.getObject(this,"DDropOffPoint",Point2.class);

        assert DTicket != null;
        txtBookingPreview1BusNameDepart.setText(DTicket.getBus());
        txtBookingPreview1DescriptionDepart.setText(BusDes);
        imgBookingPreview1ImgDepart.setImageBitmap(convertBase64toBitmap(DTicket.getImage()));
        txtBookingPreview1PassengerNumber.setText(String.valueOf(DTicket.getSeat().size()));
        if (!DSeat.isEmpty()) {
            txtBookingPreview1SeatNumberDepart.setText(DSeat.toString());
            String totalSeat = String.valueOf(DSeat.size());
            txtSubTotalTicket.setText("Subtotal ("+totalSeat+" tickets)");
        } else {
            txtBookingPreview1SeatNumberDepart.setText("No seats selected"); // or any other appropriate message
        }

        assert DPickUpPoint != null;
        txtBookingPreview11.setText(DPickUpPoint.getTime());
        txtBookingPreview13.setText(DPickUpPoint.getDateStr());
        txtBookingPreview15.setText(DPickUpPoint.getPoint());
        txtBookingPreview17.setText(DPickUpPoint.getAddress());
        if (DPickUpPoint.getShuttleBusAddress() != null && DPickUpPoint.getShuttleBusAddress() != "") {
            textView84.setText(DPickUpPoint.getShuttleBusAddress());
        } else {
            textView84.setVisibility(View.GONE);
        }
        assert DDropOffPoint != null;
        txtBookingPreview12.setText(DDropOffPoint.getTime());
        txtBookingPreview14.setText(DDropOffPoint.getDateStr());
        txtBookingPreview7.setText(DDropOffPoint.getPoint());
        txtBookingPreview19.setText(DDropOffPoint.getAddress());
        if (DDropOffPoint.getShuttleBusAddress() != null && DDropOffPoint.getShuttleBusAddress() != "") {
            txtShuttleAddress2.setText(DDropOffPoint.getShuttleBusAddress());
        } else {
            txtShuttleAddress2.setVisibility(View.GONE);
        }

        if (isReturn) {
            RTicket = MySharedPreferences.getObject(this,"RTicket", Ticket.class);
            RPickUpPoint = MySharedPreferences.getObject(this,"RPickUpPoint",Point2.class);
            RDropOffPoint = MySharedPreferences.getObject(this,"RDropOffPoint",Point2.class);

            if (RPickUpPoint.getShuttleBusAddress() != null && RPickUpPoint.getShuttleBusAddress() != "") {
                txtShuttleAddress3.setText(RPickUpPoint.getShuttleBusAddress());
            } else {
                txtShuttleAddress3.setVisibility(View.GONE);
            }

            if (RDropOffPoint.getShuttleBusAddress() != null && DPickUpPoint.getShuttleBusAddress() != "") {
                txtShuttleAddress.setText(RDropOffPoint.getShuttleBusAddress());
            } else {
                txtShuttleAddress.setVisibility(View.GONE);
            }

            RSeat = sharedPreferences.getStringSet("RSeat",new HashSet<>());
            BookingPreview1ReturnNumber.setText(RSeat.toString());

            txtBookingPreview1BusNameReturn.setText(RTicket.getBus());
            txtBookingPreview1DescriptionReturn.setText(BusDes);
            if (!DSeat.isEmpty()) {
                txtBookingPreview1SeatNumberDepart.setText(RSeat.toString());
                String totalSeat = String.valueOf(DSeat.size()+RSeat.size());
                txtSubTotalTicket.setText("Subtotal ("+totalSeat+" tickets)");
            } else {
                txtBookingPreview1SeatNumberDepart.setText("No seats selected"); // or any other appropriate message
            }
            imgBookingPreview1ImgReturn.setImageBitmap(convertBase64toBitmap(RTicket.getImage()));
            textView73.setText(String.valueOf(RSeat.size()));

            textView78.setText(RPickUpPoint.getTime());
            textView79.setText(RPickUpPoint.getDateStr());
            txtBookingPreview21.setText(RPickUpPoint.getPoint());
            txtBookingPreview23.setText(RPickUpPoint.getAddress());

            textView80.setText(RDropOffPoint.getTime());
            textView81.setText(RDropOffPoint.getDateStr());
            textView82.setText(RDropOffPoint.getPoint());
            txtBookingPreview25.setText(RDropOffPoint.getAddress());
            txtBookingPreview1TagDepartTrip.setText("Round Trip");

        } else {
            txtBookingPreview1TagDepartTrip.setText("One Way Trip");
            llReturnTicket.setVisibility(View.GONE);
        }

        passengerInfo = MySharedPreferences.getObject(this,"PassengerInfo",PassengerInfo.class);
        assert passengerInfo != null;
        txtBookingPreview27.setText(passengerInfo.getName());
        txtBookingPreview29.setText(passengerInfo.getEmail());
        textView85.setText(passengerInfo.getPhoneNumber());

        DTotalPrice = sharedPreferences.getString("DTotalPrice","0");
        RTotalPrice = sharedPreferences.getString("RTotalPrice","0");
        txtBookingPreview1Price.setText(String.valueOf(Integer.parseInt(DTotalPrice)+Integer.parseInt(RTotalPrice)));

        Intent getIntent = getIntent();
        search = getIntent.getStringArrayListExtra("search");

        String DLocation = sharedPreferences.getString("DLocation","");
        String ALocation = sharedPreferences.getString("ALocation","");
        String DDate = sharedPreferences.getString("DDate","");
        String RDate = sharedPreferences.getString("RDate","");



        txtBookingPreview1BusName.setText(DTicket.getBus());
        txtBookingPreview1DepartLocation.setText(DLocation);
        txtBookingPreview1ArrivalLocation.setText(ALocation);

        txtBookingPreview1Date.setText(DDate);
    }

    private Bitmap convertBase64toBitmap(String base64String) {
        try {
            // Remove the data URI prefix if present
            String pureBase64Encoded = base64String.split(",")[1];

            // Decode the Base64 string into a byte array
            byte[] decodedBytes = Base64.decode(pureBase64Encoded, Base64.DEFAULT);

            // Convert the byte array into a Bitmap
            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);

            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Return null to indicate failure
        }
    }


}
