package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.chaos.view.PinView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class SignUp2_2Activity extends AppCompatActivity {

    TextView txtSignUp22Email;
    PinView pinVerificationSignUp22;
    TextView txtSignUp22Resend;
    FirebaseAuth auth;
    String email, OTP;
    FirebaseDatabase database;
    DatabaseReference reference;
    Toolbar toolbarBack;

    // Declare ProgressDialog variable
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up22);
        addViews();
        addEvents();

        // Initialize the progressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Verifying OTP..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable
    }

    private void addViews() {
        txtSignUp22Resend = findViewById(R.id.txtSignUp22Resend);
        txtSignUp22Email = findViewById(R.id.txtSignUp22Email);
        pinVerificationSignUp22 = findViewById(R.id.pvForgotPassword22VerifyCode);
        toolbarBack=findViewById(R.id.toolbarBack);
        auth = FirebaseAuth.getInstance();

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        email = sharedPreferences.getString("Email", "");
        Toast.makeText(this, email, Toast.LENGTH_SHORT).show();
        pinVerificationSignUp22.requestFocus();
        txtSignUp22Email.setText(email);
    }

    private void addEvents() {
        txtSignUp22Resend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show the ProgressDialog when resend button is clicked
                progressDialog.show();

                pinVerificationSignUp22.setText("");
                sendEmail(email);

                // Dismiss the ProgressDialog when the task is complete
                progressDialog.dismiss();
            }
        });

        toolbarBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SignUp1Activity.class);
                startActivity(intent);
            }
        });

        pinVerificationSignUp22.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                // Check if the event is KeyDown and the length of the entered text is 4
                if (event.getAction() == KeyEvent.ACTION_DOWN && pinVerificationSignUp22.getText().length() == 4) {
                    // If the length is 4, verify the OTP
                    verifyOTP(pinVerificationSignUp22.getText().toString());
                    return true; // Consume the event
                }
                return false; // Let other listeners handle the event
            }
        });
        pinVerificationSignUp22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pinVerificationSignUp22.requestFocus();
            }
        });

    }

    private void verifyOTP(String enteredOTP) {
        // Show the ProgressDialog while verifying OTP
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String OTP = sharedPreferences.getString("OTP","");
        progressDialog.show();

        // Check if the entered OTP matches the OTP stored in SharedPreferences
        if (enteredOTP.equals(OTP)) {
            Intent intent = new Intent(SignUp2_2Activity.this, SignUp3Activity.class);
            startActivity(intent);
        } else {
            pinVerificationSignUp22.setText("");
            sendEmail(email);
            Toast.makeText(this, "OTP code is incorrect, please resend!", Toast.LENGTH_SHORT).show();
        }

        // Dismiss the ProgressDialog after OTP verification is complete
        progressDialog.dismiss();
    }

    private void sendEmail(String email) {
        try {

            String OTP = generateOTP();


            String stringSenderEmail = "gbusbookingapp@gmail.com";
            String stringPasswordSenderEmail = "zfrn jxxy bqfy trtu";

            String stringHost = "smtp.gmail.com";

            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("OTP", OTP);
            editor.putString("Email", email);
            editor.apply();

            Properties properties = System.getProperties();

            properties.put("mail.smtp.host", stringHost);
            properties.put("mail.smtp.port", "465");
            properties.put("mail.smtp.ssl.enable", "true");
            properties.put("mail.smtp.auth", "true");

            javax.mail.Session session = Session.getInstance(properties, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(stringSenderEmail, stringPasswordSenderEmail);
                }
            });

            MimeMessage mimeMessage = new MimeMessage(session);
            mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(email));

            mimeMessage.setSubject("OTP Code Verification");
            mimeMessage.setText("Hello,\n\nYour OTP (One-Time Password) verification code is: " + OTP + "\n\nPlease use this code to verify your identity.\n\nIf you did not request this OTP, please ignore this email.\n\nThank you,\nGBus");

            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Transport.send(mimeMessage);
                    } catch (MessagingException e) {
                        e.printStackTrace();
                    }
                }
            });
            thread.start();

        } catch (AddressException e) {
            e.printStackTrace();
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    public static String generateOTP() {
        // Define the length of the OTP
        int otpLength = 4;

        // Generate random digits for the OTP
        Random random = new Random();
        StringBuilder otp = new StringBuilder();

        for (int i = 0; i < otpLength; i++) {
            otp.append(random.nextInt(10)); // Generates a random digit (0-9)
        }

        return otp.toString();
    }
}