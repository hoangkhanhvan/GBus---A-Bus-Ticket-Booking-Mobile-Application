package com.vanhk.gbus.model;

import android.graphics.Bitmap;

import java.util.ArrayList;

public class TripDetail5 {
    private Bitmap Avatar;
    private String Hours;
    private String License;
    private String Name;
    private String PhoneNumber;
    private ArrayList<String> Rating;
    private String TravelTrip;
    private String _id;

    public TripDetail5(Bitmap avatar, String hours, String license, String name, String phoneNumber, ArrayList<String> rating, String travelTrip, String _id) {
        Avatar = avatar;
        Hours = hours;
        License = license;
        Name = name;
        PhoneNumber = phoneNumber;
        Rating = rating;
        TravelTrip = travelTrip;
        this._id = _id;
    }

    public TripDetail5() {
    }

    public Bitmap getAvatar() {
        return Avatar;
    }

    public void setAvatar(Bitmap avatar) {
        Avatar = avatar;
    }

    public String getHours() {
        return Hours;
    }

    public void setHours(String hours) {
        Hours = hours;
    }

    public String getLicense() {
        return License;
    }

    public void setLicense(String license) {
        License = license;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public ArrayList<String> getRating() {
        return Rating;
    }

    public void setRating(ArrayList<String> rating) {
        Rating = rating;
    }

    public String getTravelTrip() {
        return TravelTrip;
    }

    public void setTravelTrip(String travelTrip) {
        TravelTrip = travelTrip;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }
}
