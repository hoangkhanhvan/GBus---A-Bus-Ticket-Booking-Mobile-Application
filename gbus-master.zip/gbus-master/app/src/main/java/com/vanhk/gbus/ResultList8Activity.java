package com.vanhk.gbus;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ResultList8Activity extends AppCompatActivity {

    ImageView imgResultList8Back;

    TextView txtResultList8DepartLocationTitle
            ,txtResultList8ArrivalLocationTitle,txtResultList8TripTypeTitle
            ,txtResultList8DepartTimeTitle,txtResultList8All
            ,txtResultList8Latest,txtResultList8Ealiest,txtResultList8Fastest
            ,txtResultList8Cheapest;

    ProgressDialog progressDialog; // Declare ProgressDialog variable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_result_list8);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        addViews();

        // Initialize the progressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable
    }

    private void addViews() {
        imgResultList8Back=findViewById(R.id.imgResultList8Back);
        txtResultList8DepartLocationTitle=findViewById(R.id.txtResultList8DepartLocationTitle);
        txtResultList8ArrivalLocationTitle=findViewById(R.id.txtResultList8ArrivalLocationTitle);
        txtResultList8TripTypeTitle = findViewById(R.id.txtResultList8TripTypeTitle);
        txtResultList8DepartTimeTitle = findViewById(R.id.txtResultList8DepartTimeTitle);
        txtResultList8All = findViewById(R.id.txtResultList8All);
        txtResultList8Latest = findViewById(R.id.txtResultList8Latest);
        txtResultList8Ealiest = findViewById(R.id.txtResultList8Ealiest);
        txtResultList8Fastest = findViewById(R.id.txtResultList8Fastest);
        txtResultList8Cheapest = findViewById(R.id.txtResultList8Cheapest);
    }
}
