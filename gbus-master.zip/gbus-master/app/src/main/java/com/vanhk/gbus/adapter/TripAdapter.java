package com.vanhk.gbus.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.vanhk.gbus.R;
import com.vanhk.gbus.model.Trip;

public class TripAdapter extends ArrayAdapter<Trip> {
    Activity context;
    int resource;
    public TripAdapter(@NonNull Activity context, int resource) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
    }
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View trip_item=inflater.inflate(resource,null);

        TextView txtResultList1DepartTimeItem=trip_item.findViewById(R.id.txtResultList1DepartTimeTitle);
        TextView txtResultList1ArrivalTimeItem=trip_item.findViewById(R.id.txtResultList1ArrivalTimeItem);
        TextView txtResultList1PickUpStartItem=trip_item.findViewById(R.id.txtResultList1PickUpStartItem);
        TextView txtResultList1DropOffEndItem=trip_item.findViewById(R.id.txtResultList1DropOffEndItem);
        TextView txtResultList1BusNameItem=trip_item.findViewById(R.id.txtResultList1BusNameItem);
        TextView txtResultList1BusPriceItem=trip_item.findViewById(R.id.txtResultList1BusPriceItem);
        TextView txtResultList1SeatNumberItem=trip_item.findViewById(R.id.txtResultList1SeatNumberItem);
        TextView txtResultList1TagItem=trip_item.findViewById(R.id.txtResultList1TagItem);
        Trip trip=getItem(position);
        assert trip != null;
        txtResultList1DepartTimeItem.setText(trip.getTripDepartTime());
        txtResultList1ArrivalTimeItem.setText(trip.getTripArrivalTime());
        txtResultList1PickUpStartItem.setText(trip.getTripPickUpStart());
        txtResultList1DropOffEndItem.setText(trip.getTripDropOffEnd());
        txtResultList1BusNameItem.setText(trip.getTripBusType());
        txtResultList1BusPriceItem.setText(trip.getTripPrice());
        txtResultList1SeatNumberItem.setText(trip.getTripSeatNumber());
        txtResultList1TagItem.setText(trip.getTripDiscount());

//        TextView txtTripDepartLocation=trip_item.findViewById(R.id.txtHomepageDepart);
////        TextView txtTripArrivalLocation=trip_item.findViewById(R.id.txtHomepageSelectArrival);
////        TextView txtTripDepartTime=trip_item.findViewById(R.id.txtHomepageSelectDepartDate);
//
//
//        Trip trip=getItem(position);
//        txtTripDepartLocation.setText(trip.getTripDepartLocation());
////        txtTripArrivalLocation.setText(trip.getTripArrivalLocation());
////        txtTripDepartTime.setText(trip.getTripDepartTime());

        return trip_item;
    }

    public void add(String s) {
    }
}

