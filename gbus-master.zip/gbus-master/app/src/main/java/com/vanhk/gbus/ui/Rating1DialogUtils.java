package com.vanhk.gbus.ui;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.RatingBar;

import com.vanhk.gbus.R;
import com.vanhk.gbus.Rating_3Activity;

public class Rating1DialogUtils {
    public static void showRatingDialog(Context context) {
        Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.rating1_dialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setGravity(Gravity.CENTER);

        RatingBar ratingBar = dialog.findViewById(R.id.ratingBar1DialogStar);
        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                //lưu giá trị rating vào 1 biến và chuyển sang activity sau
                float userRating = rating;
                Intent intent = new Intent(context, Rating_3Activity.class);
                intent.putExtra("USER_RATING",userRating);
                context.startActivity(intent);
                dialog.dismiss(); //đóng dialog sau khi rate
            }
        });

        dialog.show();

        }
}
