package com.vanhk.gbus.model;

public class Bus {
    private int tripDepartTime;
    private int tripArrivalTime;
    private String tripPickUpStart;
    private String tripDropOffEnd;
    private String tripBusType;
    private int tripBusPrice;
    private int tripSeatNumber;
    private int tripDiscount;

    public Bus(int tripDepartTime, int tripArrivalTime, String tripPickUpStart, String tripDropOffEnd, String tripBusType, int tripBusPrice, int tripSeatNumber, int tripDiscount) {
        this.tripDepartTime = tripDepartTime;
        this.tripArrivalTime = tripArrivalTime;
        this.tripPickUpStart = tripPickUpStart;
        this.tripDropOffEnd = tripDropOffEnd;
        this.tripBusType = tripBusType;
        this.tripBusPrice = tripBusPrice;
        this.tripSeatNumber = tripSeatNumber;
        this.tripDiscount = tripDiscount;
    }

    public Bus() {
    }

    public int getTripDepartTime() {
        return tripDepartTime;
    }

    public void setTripDepartTime(int tripDepartTime) {
        this.tripDepartTime = tripDepartTime;
    }

    public int getTripArrivalTime() {
        return tripArrivalTime;
    }

    public void setTripArrivalTime(int tripArrivalTime) {
        this.tripArrivalTime = tripArrivalTime;
    }

    public String getTripPickUpStart() {
        return tripPickUpStart;
    }

    public void setTripPickUpStart(String tripPickUpStart) {
        this.tripPickUpStart = tripPickUpStart;
    }

    public String getTripDropOffEnd() {
        return tripDropOffEnd;
    }

    public void setTripDropOffEnd(String tripDropOffEnd) {
        this.tripDropOffEnd = tripDropOffEnd;
    }

    public String getTripBusType() {
        return tripBusType;
    }

    public void setTripBusType(String tripBusType) {
        this.tripBusType = tripBusType;
    }

    public int getTripBusPrice() {
        return tripBusPrice;
    }

    public void setTripBusPrice(int tripBusPrice) {
        this.tripBusPrice = tripBusPrice;
    }

    public int getTripSeatNumber() {
        return tripSeatNumber;
    }

    public void setTripSeatNumber(int tripSeatNumber) {
        this.tripSeatNumber = tripSeatNumber;
    }

    public int getTripDiscount() {
        return this.tripDiscount;
    }

    public void setTripDiscount(int tripDiscount) {
        this.tripDiscount = tripDiscount;
    }
}