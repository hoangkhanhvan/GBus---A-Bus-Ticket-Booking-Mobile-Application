package com.vanhk.gbus.adapter;

import android.app.Activity;
import android.app.Dialog;
import android.content.ContentValues;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.vanhk.gbus.R;
import com.vanhk.gbus.model.Point2;

import java.util.ArrayList;

public class EditPoint extends ArrayAdapter<Point2> {
    private Activity context;
    private int resource;
    private ArrayList<Point2> point2ArrayList;
    private int selectedPosition = -1; // Variable to store the selected position

    public EditPoint(@NonNull Activity context, int resource, ArrayList<Point2> points) {
        super(context, resource, points);
        this.context = context;
        this.resource = resource;
        this.point2ArrayList = points;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = context.getLayoutInflater().inflate(resource, parent, false);

        RadioButton radioBtn = view.findViewById(R.id.radEditPickupPointDepart1ShuttleBusEdit);
        TextView pointTextView = view.findViewById(R.id.txtEditPickupPointDepart1ShuttleBusEditTitle);
        TextView addressTextView = view.findViewById(R.id.txtEditPickupPointDepart1ShuttleBusEditLocation);
        LinearLayout shuttleBusLayout = view.findViewById(R.id.llShuttleBus);
        TextView shuttleBusTextView = view.findViewById(R.id.txtEditPickupPointDepart1ShuttleBusEditShuttleBusAddress);
        TextView editTextView = view.findViewById(R.id.txtEditPickupPointDepart1ShuttleBusEditShuttleBusEdit);
        TextView shuttleBusTagTextView = view.findViewById(R.id.txtEditPickupPointDepart1ShuttleBusEditTag);

        Point2 point = getItem(position);

        if (point != null) {
            pointTextView.setText(point.getPoint());
            addressTextView.setText(point.getAddress());

            // Set the checked state of the radio button based on the selected position
            radioBtn.setChecked(position == selectedPosition);

            if (point.isShuttleBus()) {
                shuttleBusTagTextView.setVisibility(View.VISIBLE);
            } else {
                shuttleBusTagTextView.setVisibility(View.GONE);
            }
            String address = point.getShuttleBusAddress();
            if (address != null) {
                shuttleBusLayout.setVisibility(View.VISIBLE);
                shuttleBusTextView.setText(address);
            } else {
                shuttleBusLayout.setVisibility(View.GONE);
            }
        }

        // Set a click listener for the radio button
        radioBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedPosition = position; // Update the selected position
                notifyDataSetChanged(); // Notify the adapter that data has changed
                if (point.isShuttleBus()) {
                    openDialog(shuttleBusLayout, shuttleBusTextView);
                }
            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedPosition = position; // Update the selected position
                notifyDataSetChanged(); // Notify the adapter that data has changed
                if (point.isShuttleBus()) {
                    openDialog(shuttleBusLayout, shuttleBusTextView);
                }
            }
        });

        editTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog(shuttleBusLayout, shuttleBusTextView);
            }
        });

        return view;
    }

    private void openDialog(LinearLayout shuttleLayout, TextView shuttleBusTextView) {
        Point2 selectedPoint = point2ArrayList.get(selectedPosition);

        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.activity_dropoff_return3);

        Window window = dialog.getWindow();

        if (window == null) {
            return;
        }

        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        WindowManager.LayoutParams windowAttribute = window.getAttributes();
        windowAttribute.gravity = Gravity.CENTER;
        window.setAttributes(windowAttribute);

        dialog.setCancelable(true);

        EditText edtDropOffReturn3 = dialog.findViewById(R.id.edtDropOffReturn3);
        Button btnDropOffReturn3Confirm = dialog.findViewById(R.id.btnDropOffReturn3Confirm);

        btnDropOffReturn3Confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedPoint != null) {
                    String address = edtDropOffReturn3.getText().toString();
                    selectedPoint.setShuttleBusAddress(address);
                    notifyDataSetChanged();
                    dialog.dismiss();
                }
            }
        });

        dialog.show();
    }

    public Point2 getSelectedPoint() {
        if (selectedPosition != -1 && selectedPosition < point2ArrayList.size()) {
            return point2ArrayList.get(selectedPosition);
        }
        return null;
    }
}
