package com.vanhk.gbus.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.vanhk.gbus.R;
import com.vanhk.gbus.model.Bus;

public class BusAdapter extends ArrayAdapter<Bus> {
    Activity context;
    int resource;
    public BusAdapter(@NonNull Activity context, int resource) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
    }
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View account_item=inflater.inflate(resource,null);

        TextView txtResultList1DepartTime=account_item.findViewById(R.id.txtResultList1ArrivalTimeItem);
        TextView txtResultList1ArrivalTime=account_item.findViewById(R.id.txtResultList1ArrivalTimeItem);
//        TextView txtResultList1Duration=account_item.findViewById(R.id.txtResultList1Duration);
        TextView txtResultList1PickUpStart=account_item.findViewById(R.id.txtResultList1PickUpStartItem);
        TextView txtResultList1DropOffEnd=account_item.findViewById(R.id.txtResultList1DropOffEndItem);
        TextView txtResultList1BusName=account_item.findViewById(R.id.txtResultList1BusNameItem);
        TextView txtResultList1BusPrice=account_item.findViewById(R.id.txtResultList1BusPriceItem);
        TextView txtResultList1SeatNumber=account_item.findViewById(R.id.txtResultList1SeatNumberItem);
        TextView txtResultList1Discount=account_item.findViewById(R.id.txtResultList1TagItem);

        Bus bus=getItem(position);
        txtResultList1DepartTime.setText(bus.getTripDepartTime());
        txtResultList1ArrivalTime.setText(bus.getTripArrivalTime());
        txtResultList1Discount.setText(bus.getTripDiscount()+"%");
        txtResultList1PickUpStart.setText(bus.getTripPickUpStart());
        txtResultList1DropOffEnd.setText(bus.getTripDropOffEnd());
        txtResultList1BusName.setText(bus.getTripBusType());
        txtResultList1BusPrice.setText(bus.getTripBusPrice()+"VND");
        txtResultList1SeatNumber.setText(bus.getTripSeatNumber());

        return account_item;
    }
}