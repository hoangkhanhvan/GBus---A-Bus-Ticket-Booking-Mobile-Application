package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class PayByEWallet_2Activity extends AppCompatActivity {
    TextView txtDescription;
    TextView txtEstimate;
    TextView txtTotal;
    ProgressDialog progressDialog; // Declare ProgressDialog variable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_by_ewallet2);
        addViews();
    }

    private void addViews() {
        txtDescription = findViewById(R.id.txtDescription);
        txtEstimate = findViewById(R.id.txtEstimate);
        txtTotal = findViewById(R.id.txtTotal);
    }

    private void showProgressDialog() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading..."); // Set the message for the ProgressDialog
        progressDialog.setCancelable(false); // Prevent user from canceling the ProgressDialog
        progressDialog.show(); // Show the ProgressDialog
    }

    private void dismissProgressDialog() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss(); // Dismiss the ProgressDialog if it's showing
        }
    }

    // Override onResume to ensure progressDialog is dismissed when the activity is destroyed
    @Override
    protected void onResume() {
        super.onResume();
        dismissProgressDialog();
    }
}
