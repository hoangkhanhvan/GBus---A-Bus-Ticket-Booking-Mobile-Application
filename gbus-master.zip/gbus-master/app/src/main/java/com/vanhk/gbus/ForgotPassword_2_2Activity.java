package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;

import com.chaos.view.PinView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class ForgotPassword_2_2Activity extends AppCompatActivity {

    Toolbar toolbarBack;
    TextView txtForgotPassword22Email, txtForgotPassword22CountDown;
    Button btnForgotPassword22Resend;
    DatabaseReference myRef;
    private CountDownTimer countDownTimer;
    ProgressDialog progressDialog; // Declare ProgressDialog
    PinView pvForgotPassword22VerifyCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password22);
        addViews();
        addEvents();
        sendEmail();
        startCountdown();

        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog
    }

    private void addEvents() {
        toolbarBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btnForgotPassword22Resend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pvForgotPassword22VerifyCode.setText("");

                sendEmail();

                startCountdown();
            }
        });
        pvForgotPassword22VerifyCode.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                // Check if the event is KeyDown and the length of the entered text is 4
                if (event.getAction() == KeyEvent.ACTION_DOWN && pvForgotPassword22VerifyCode.getText().length() == 4) {
                    // If the length is 4, verify the OTP
                    verifyOTP(pvForgotPassword22VerifyCode.getText().toString());
                    return true; // Consume the event
                }
                return false; // Let other listeners handle the event
            }
        });
    }
    private void verifyOTP(String enteredOTP) {
        // Show the ProgressDialog while verifying OTP
        progressDialog.show();
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String OTP = sharedPreferences.getString("OTP","");

        // Check if the entered OTP matches the OTP stored in SharedPreferences
        if (enteredOTP.equals(OTP)) {
            Intent intent = new Intent(ForgotPassword_2_2Activity.this, ForgotPassword_3Activity.class);
            startActivity(intent);
        } else {
            pvForgotPassword22VerifyCode.setText("");
            sendEmail();
            Toast.makeText(this, "OTP code is incorrect, please resend!", Toast.LENGTH_SHORT).show();
        }

        // Dismiss the ProgressDialog after OTP verification is complete
        progressDialog.dismiss();
    }

    private void sendEmail() {
        try {
            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            String OTP = generateOTP();

            String stringSenderEmail = "gbusbookingapp@gmail.com";
            String stringReceiverEmail = sharedPreferences.getString("Email","");
            Toast.makeText(this, stringReceiverEmail, Toast.LENGTH_SHORT).show();
            String stringPasswordSenderEmail = "zfrn jxxy bqfy trtu";

            String stringHost = "smtp.gmail.com";

            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("OTP", OTP);
            editor.putString("Email", stringReceiverEmail);
            editor.apply();

            Properties properties = System.getProperties();

            properties.put("mail.smtp.host", stringHost);
            properties.put("mail.smtp.port", "465");
            properties.put("mail.smtp.ssl.enable", "true");
            properties.put("mail.smtp.auth", "true");

            javax.mail.Session session = Session.getInstance(properties, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(stringSenderEmail, stringPasswordSenderEmail);
                }
            });

            MimeMessage mimeMessage = new MimeMessage(session);
            mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(stringReceiverEmail));

            mimeMessage.setSubject("OTP Code Verification");
            mimeMessage.setText("Hello,\n\nYour OTP (One-Time Password) verification code is: " + OTP + "\n\nPlease use this code to verify your identity.\n\nIf you did not request this OTP, please ignore this email.\n\nThank you,\nGBus");

            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Transport.send(mimeMessage);
                    } catch (MessagingException e) {
                        e.printStackTrace();
                    }
                }
            });
            thread.start();

        } catch (AddressException e) {
            e.printStackTrace();
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    public static String generateOTP() {
        // Define the length of the OTP
        int otpLength = 4;

        // Generate random digits for the OTP
        Random random = new Random();
        StringBuilder otp = new StringBuilder();

        for (int i = 0; i < otpLength; i++) {
            otp.append(random.nextInt(10)); // Generates a random digit (0-9)
        }

        return otp.toString();
    }

    private void addViews() {
        txtForgotPassword22Email = findViewById(R.id.txtForgotPassword22Email);
        txtForgotPassword22CountDown = findViewById(R.id.txtForgotPassword22CountDown);
        btnForgotPassword22Resend = findViewById(R.id.btnForgotPassword22Resend);
        toolbarBack = findViewById(R.id.toolbarBack);
        pvForgotPassword22VerifyCode=findViewById(R.id.pvForgotPassword22VerifyCode);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("user");

        //Lấy email từ intent lên textview
        String account_email = getIntent().getStringExtra("emailOrPhone");
        txtForgotPassword22Email.setText(account_email);

        sendOTP();

    }

    private void sendOTP() {
        String emailOrPhone = getIntent().getStringExtra("emailOrPhone");
        myRef.orderByChild("account_email").equalTo(emailOrPhone).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                progressDialog.dismiss(); // Dismiss ProgressDialog
                if (snapshot.exists()) {
                    Toast.makeText(ForgotPassword_2_2Activity.this, "OTP sent successfully", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(ForgotPassword_2_2Activity.this, "Email or phone number not found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss(); // Dismiss ProgressDialog in case of error
                Toast.makeText(ForgotPassword_2_2Activity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void startCountdown() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        countDownTimer = new CountDownTimer(60000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                // Cập nhật đồng hồ đếm ngược
                txtForgotPassword22CountDown.setText((millisUntilFinished / 1000) + "s");
            }

            @Override
            public void onFinish() {
                // Hiển thị lại nút Resend khi đếm ngược kết thúc
                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("OTP","");
                txtForgotPassword22CountDown.setVisibility(View.VISIBLE);
            }
        }.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Hủy đếm ngược khi màn hình bị hủy
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }
}
