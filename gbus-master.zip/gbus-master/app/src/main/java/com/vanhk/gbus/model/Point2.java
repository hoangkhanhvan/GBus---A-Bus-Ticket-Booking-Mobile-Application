package com.vanhk.gbus.model;

import java.io.Serializable;

public class Point2 implements Serializable {
    private String point;
    private String address;
    private boolean checked;
    private boolean shuttleBus;
    private String shuttleBusAddress;
    private String time;
    private String dateStr;

    public String getDateStr() {
        return dateStr;
    }

    public void setDateStr(String dateStr) {
        this.dateStr = dateStr;
    }

    public Point2(String point, String address, boolean checked, boolean shuttleBus, String shuttleBusAddress, String time, String dateStr) {
        this.point = point;
        this.address = address;
        this.checked = checked;
        this.shuttleBus = shuttleBus;
        this.shuttleBusAddress = shuttleBusAddress;
        this.time = time;
        this.dateStr = dateStr;
    }

    // Empty constructor
    public Point2() {
    }

    // Getters and setters
    public String getPoint() {
        return point;
    }

    public void setPoint(String point) {
        this.point = point;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public boolean isShuttleBus() {
        return shuttleBus;
    }

    public void setShuttleBus(boolean shuttleBus) {
        this.shuttleBus = shuttleBus;
    }

    public String getShuttleBusAddress() {
        return shuttleBusAddress;
    }

    public void setShuttleBusAddress(String shuttleBusAddress) {
        this.shuttleBusAddress = shuttleBusAddress;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
