package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.PaidTicket;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public class Cancellation3Activity extends AppCompatActivity {
    ImageView imgCancellation3Back;
    RadioButton radCancellation3Incorrect, radCancellation3Wrong, radCancellation3No, radCancellation3Lack, radCancellation3Busy, radCancellation3Other;
    Button btnCancellation3Confirm, btnCancellation3TellUs;
    ArrayAdapter<String> cancelAdapter;
    String TAG = "FIREBASE";
    ProgressDialog progressDialog; // ProgressDialog instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancellation3);
        addViews();
        addEvents();

        progressDialog = new ProgressDialog(this); // Initialize progressDialog
        progressDialog.setMessage("Processing..."); // Set message for progressDialog
        progressDialog.setCancelable(false); // Make progressDialog not cancellable
    }

    @Override
    protected void onResume() {
        super.onResume();
        progressDialog.dismiss();
    }

    private void updateSeat(String ticketId, List<String> seatsToRemove) {
        DatabaseReference ticketsRef = FirebaseDatabase.getInstance().getReference().child("Tickets");

        // Listen to the entire Tickets node
        ticketsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // Iterate over all tickets
                for (DataSnapshot ticketSnapshot : dataSnapshot.getChildren()) {
                    String _id = ticketSnapshot.child("_id").getValue(String.class);
                    // Check if the _id of the ticket matches the ticketId
                    if (ticketId.equals(_id)) {
                        // Process the Seat node of the matching ticket
                        processSeatRemoval(ticketSnapshot.child("Seat"), seatsToRemove);
                        break; // Stop the loop after processing the matching ticket
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w("Firebase", "Failed to read tickets for seat update.", databaseError.toException());
            }
        });
    }
    private void processSeatRemoval(DataSnapshot seatSnapshot, List<String> seatsToRemove) {
        // Iterate over each seat in the Seat node
        for (DataSnapshot singleSeatSnapshot : seatSnapshot.getChildren()) {
            String seat = singleSeatSnapshot.getValue(String.class);
            // Check if the current seat is in the list to remove
            if (seatsToRemove.contains(seat)) {
                singleSeatSnapshot.getRef().removeValue(); // Remove the matching seat
            }
        }
    }

    private void addEvents() {
        btnCancellation3Confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                progressDialog.show(); // Show progressDialog when the button is clicked

                long cancelTime = System.currentTimeMillis();

                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference("CancelReason");

                String _id = myRef.getKey();
                String reason = "";

                if (radCancellation3Wrong.isChecked()) {
                    reason = radCancellation3Wrong.getText().toString();
                } else if (radCancellation3Other.isChecked()) {
                    reason = radCancellation3Other.getText().toString();
                } else if (radCancellation3Busy.isChecked()) {
                    reason = radCancellation3Busy.getText().toString();
                } else if (radCancellation3Lack.isChecked()) {
                    reason = radCancellation3Lack.getText().toString();
                } else if (radCancellation3No.isChecked()) {
                    reason = radCancellation3No.getText().toString();
                } else if (radCancellation3Incorrect.isChecked()) {
                    reason = radCancellation3Incorrect.getText().toString();
                }

                PaidTicket paidTicket = MySharedPreferences.getObject(getApplicationContext(),"cancelingTicket",PaidTicket.class);
                String id = paidTicket.get_id();

                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                String refundPercentage = sharedPreferences.getString("refundPercentage", "0");
                String refundFee = sharedPreferences.getString("refundFee", "0");

                DatabaseReference myBookedTicket = database.getReference("BookedTicket");
                Map<String, Object> cancellationData = new HashMap<>();
                cancellationData.put("refundPercentage", refundPercentage);
                cancellationData.put("refundFee", refundFee);
                cancellationData.put("reason", reason);
                cancellationData.put("timeOfCancel", getCurrentDateTime());

                myBookedTicket.child(id).child("status").setValue("Cancel");

                updateSeat(paidTicket.getDeparture().getTicket().get_id(), paidTicket.getDeparture().getSeat());
                if (paidTicket.getReturn() != null) {
                    updateSeat(paidTicket.getReturn().getTicket().get_id(), paidTicket.getReturn().getSeat());
                }

                myBookedTicket.child(id).child("Cancellation").setValue(cancellationData).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Intent intent = new Intent(getApplicationContext(), Cancellation5Activity.class);
                        startActivity(intent);
                    }
                });
            }
        });
    }

    public static String getCurrentDateTime() {
        // Create a SimpleDateFormat instance with the desired format
        SimpleDateFormat formatter = new SimpleDateFormat("MMM dd, yyyy 'at' hh:mma");
        // Get current date and time
        Date date = new Date();
        // Return the formatted date string
        return formatter.format(date);
    }

//    private void addEvents() {
//        btnCancellation3Confirm.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                long cancelTime = System.currentTimeMillis();
//
//
//                FirebaseDatabase database = FirebaseDatabase.getInstance();
//                DatabaseReference myRef = database.getReference("CancelReason");
//
//                String _id = "Nw5PnPhkPKzlw8Wgxf8";
//                String reason = "";
//
//                if (radCancellation3Wrong.isChecked()) {
//                    reason = radCancellation3Wrong.getText().toString();
//                } else if (radCancellation3Other.isChecked()) {
//                    reason = radCancellation3Other.getText().toString();
//                } else if (radCancellation3Busy.isChecked()) {
//                    reason = radCancellation3Busy.getText().toString();
//                } else if (radCancellation3Lack.isChecked()) {
//                    reason = radCancellation3Lack.getText().toString();
//                } else if (radCancellation3No.isChecked()) {
//                    reason = radCancellation3No.getText().toString();
//                } else if (radCancellation3Incorrect.isChecked()) {
//                    reason = radCancellation3Incorrect.getText().toString();
//                }
//
//                DatabaseReference myBookedTicket = database.getReference("BookedTicket");
//                String finalReason = reason;
//                myBookedTicket.child("bookedTime").addListenerForSingleValueEvent(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(@NonNull DataSnapshot snapshot) {
//                        if (snapshot.exists()) {
//                            long bookedTime = snapshot.getValue(Long.class);
//
////                            // Calculate the cancel time by finding the difference between cancel time and the time when the ticket was booked
////                            long cancelDuration = cancelTime - bookedTime;
//
//                            // Save ticket information along with cancel time into Firebase
//                            myBookedTicket.child("reason").setValue(finalReason);
//                            myBookedTicket.child("cancelTime").setValue(cancelTime);
////                            myBookedTicket.child("cancelDuration").setValue(cancelDuration);
//
//                            // Proceed to the next activity
//                            Intent intent = new Intent(Cancellation3Activity.this, Cancellation5Activity.class);
//                            intent.putExtra("_id", _id);
//                            startActivity(intent);
//                        } else {
//                            // Handle case where bookedTime is not found
//                        }
//                    }
//
//
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError error) {
//                        // Handle database error
//                    }}
//            }



//                myBookedTicket.child(_id).child("reason").setValue(reason);
//                myBookedTicket.child(_id).child("cancelTime").setValue(cancelTime);
//                Intent intent = new Intent(Cancellation3Activity.this, Cancellation5Activity.class);
////                intent.putExtra("_id", _id); // Assuming you want to pass ticket id to the next activity
//                startActivity(intent);

//                try {
//                    FirebaseDatabase database = FirebaseDatabase.getInstance();
//                    DatabaseReference myRef = database.getReference("CancelReason");
//                    ArrayList<CancelReason> cancelReasons = new ArrayList<>();
//                    String cancelId = myRef.push().getKey();
//                    String cancelIncorrect = radCancellation3Incorrect.getText().toString();
//                    String cancelWrong = radCancellation3Wrong.getText().toString();
//                    String cancelNo = radCancellation3No.getText().toString();
//                    String cancelLack = radCancellation3Lack.getText().toString();
//                    String cancelBusy = radCancellation3Busy.getText().toString();
//                    String cancelOther = radCancellation3Other.getText().toString();
//
//                    if (cancelId != null) {
//                        myRef.child("CR01").child("Description").setValue(cancelIncorrect);
//                        myRef.child("CR02").child("Description").setValue(cancelWrong);
//                        myRef.child("CR03").child("Description").setValue(cancelNo);
//                        myRef.child("CR04").child("Description").setValue(cancelLack);
//                        myRef.child("CR05").child("Description").setValue(cancelBusy);
//                        myRef.child("CR06").child("Description").setValue(cancelOther);
//                        Intent intent = new Intent(Cancellation3Activity.this, Cancellation5Activity.class);
//                        intent.putExtra("Incorrect route booked", cancelIncorrect);
//                        intent.putExtra("Wrong time/date selected", cancelWrong);
//                        intent.putExtra("No pick-up or transfer option available", cancelNo);
//                        intent.putExtra("Lack of necessary amenities", cancelLack);
//                        intent.putExtra("Busy schedule", cancelBusy);
//                        intent.putExtra("Other", cancelOther);
//
//                        startActivity(intent);
//                        showSuccessDialog();
//                    } else {
//                        Toast.makeText(Cancellation3Activity.this, "No reason", Toast.LENGTH_SHORT).show();
//                    }
//                } catch (Exception ex) {
//                    Toast.makeText(Cancellation3Activity.this, "Error: " + ex.toString(), Toast.LENGTH_LONG).show();
//                }

    private void processUpdate() {

    }

    private void showSuccessDialog() {
        final Dialog dialog = new Dialog(Cancellation3Activity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_cancellation6_item);

        Window window = dialog.getWindow();
        if (window == null) {
            return;
        }

        WindowManager.LayoutParams windowAttribute = window.getAttributes();
        windowAttribute.gravity = Gravity.CENTER;
        window.setAttributes(windowAttribute);

        dialog.setCancelable(true);

        Button btnBackToHomepage = dialog.findViewById(R.id.btnCancellation6DialogBook);

        btnBackToHomepage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Cancellation3Activity.this, HomepageActivity.class);
                startActivity(intent);
            }
        });
        dialog.show();
    }


    private void addViews() {
        imgCancellation3Back = findViewById(R.id.imgCancellation3Back);
        radCancellation3Incorrect = findViewById(R.id.radCancellation3Incorrect);
        radCancellation3Wrong = findViewById(R.id.radCancellation3Wrong);
        radCancellation3No = findViewById(R.id.radCancellation3No);
        radCancellation3Lack = findViewById(R.id.radCancellation3Lack);
        radCancellation3Busy = findViewById(R.id.radCancellation3Busy);
        radCancellation3Other = findViewById(R.id.radCancellation3Other);
        btnCancellation3Confirm = findViewById(R.id.btnCancellation3Confirm);
        btnCancellation3TellUs = findViewById(R.id.btnCancellation3TellUs);
        cancelAdapter = new ArrayAdapter<>(Cancellation3Activity.this, R.layout.activity_cancellation5);

    }
}