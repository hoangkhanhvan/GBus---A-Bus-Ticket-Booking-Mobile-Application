package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.model.OnGoingTicket;
//Thiếu load data ticket
public class ViewInvoice_OngoingActivity extends AppCompatActivity {
    ImageView imgViewInvoiceOngoingBack;
    TextView txtViewInvoiceOngoingCountDown,txtViewInvoiceOngoingEmailSent
            ,txtViewInvoiceOngoingTag,txtViewInvoiceOngoingName
            ,txtViewInvoiceOngoingPhoneNumber,txtViewInvoiceOngoingEmail
            ,txtViewInvoiceOngoingLicensePlate,txtViewInvoiceOngoingPhoneDriver1
            ,txtViewInvoiceOngoingPhoneDriver2,txtViewInvoiceOngoingTimestamp
            ,txtViewInvoiceOngoingTransactionNo,txtViewInvoiceOngoingTrip
            ,txtViewInvoiceOngoingState,txtViewInvoiceOngoingBusType
            ,txtViewInvoiceOngoingQuantity,txtViewInvoiceOngoingSeatDepart
            ,txtViewInvoiceOngoingSeatReturn;
    TextView txtViewInvoiceOngoingDepartPickupLocation,txtViewInvoiceOngoingDepartPickupDescription
            ,txtViewInvoiceOngoingDepartPickupExpectedTime,txtViewInvoiceOngoingDepartDropoffLocation
            ,txtViewInvoiceOngoingDepartDropoffDescription,txtViewInvoiceOngoingDepartDropoffExptectedTime;
    TextView txtViewInvoiceOngoingReturnDepartPickupLocation,txtViewInvoiceOngoingReturnDepartPickupDescription
            ,txtViewInvoiceOngoingReturnDepartPickupExpectedTime,txtViewInvoiceOngoingReturnDropoffLocation
            ,txtViewInvoiceOngoingReturnDropoffDescription,txtViewInvoiceOngoingReturnDropoffExpectedTime;
    TextView txtViewInvoiceOngoingTicketTotal,txtViewInvoiceOngoingSubtotal
            ,txtViewInvoiceOngoingDiscount,txtViewInvoiceOngoingTotal;
    Button btnViewInvoiceOngoingHomepage,btnViewInvoiceOngoingTellUs;
    ImageButton imageCallButton1, imageCallButton2;
    OnGoingTicket onGoingTicket;

    private DatabaseReference mDatabase;
    private String driverPhoneNumber;
    private String driverPhoneNumber1;
    private String driverPhoneNumber2;
    String bookedTicketId = "";


    // Declare ProgressDialog variable
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_invoice_ongoing);
        addViews();
        addEvents();
        // Initialize Firebase Realtime Database
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Call method to load data
        loadDataFromRealtimeDatabase();

        // Initialize the ProgressDialog

    }

    private void loadDataFromRealtimeDatabase() {
        // Show the ProgressDialog
        progressDialog.show();
        // Assuming you have a path to the OnGoingTicket node in your database
        String ongoingTicketId = mDatabase.getKey();

        // Reference to the OnGoingTicket node
        DatabaseReference ticketRef = mDatabase.child("BookedTicket").child(ongoingTicketId);

        // Add a ValueEventListener to listen for changes
        ticketRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Convert the snapshot to OnGoingTicket object
                    OnGoingTicket onGoingTicket = dataSnapshot.getValue(OnGoingTicket.class);

                    // Update UI with ticket data
                    if (onGoingTicket != null) {
                        String onGoingCategory = onGoingTicket.getOngoingCategory();
                        String onGoingEmail = onGoingTicket.getOngoingEmail();
                        String onGoingName = onGoingTicket.getOngoingName();
                        String onGoingPhoneNumber = onGoingTicket.getOngoingPhoneNumber();
                        String onGoingLicensePlate = onGoingTicket.getOngoingLicenseNumber();
                        String driverId = onGoingTicket.getOngoingDriverId();
                        String onGoingPaymentTime = String.valueOf(onGoingTicket.getOngoingPaymentTime());
                        String onGoingTransactionNumber = onGoingTicket.getOngoingTransactionNumber();
                        String onGoingDepartureTrip = onGoingTicket.getOngoingDepartureTrip();
                        String onGoingReturnTrip = onGoingTicket.getOngoingReturnTrip();
                        String onGoingState = onGoingTicket.getOngoingState();


                        if (onGoingDepartureTrip != null && onGoingReturnTrip != null) {
                            String[] departureTripParts = onGoingDepartureTrip.split("-");
                            String[] returnTripParts = onGoingReturnTrip.split("-");

                            if (departureTripParts.length == 2 && returnTripParts.length == 2) {
                                String departureLocation = departureTripParts[0].trim();
                                String returnLocation = returnTripParts[1].trim();

                                String trip = departureLocation + " - " + returnLocation;

                                // Set the trip string to the TextView
                                txtViewInvoiceOngoingTrip.setText(trip);
                            } else {
                                // Handle invalid trip formats
                            }
                        } else {
                            // Handle null values for departure or return trip
                        }


                        DatabaseReference driverRef1 = mDatabase.child("departure").child("driver").child("0");
                        driverRef1.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    String driverName1 = dataSnapshot.child("driverName").getValue(String.class);

                                     driverPhoneNumber1 = dataSnapshot.child("driverPhoneNumber").getValue(String.class);

                                    //Save driverphonenumber
                                    driverPhoneNumber = driverPhoneNumber1;

                                    Log.d("driverName", driverName1);
                                    Log.d("driverPhoneNumber", driverPhoneNumber1);

                                    // Update UI with driver's name and phone number
                                    // For example:
                                    txtViewInvoiceOngoingPhoneDriver1.setText(driverPhoneNumber1);
                                    // Similarly, update other views with driverPhoneNumber if needed
                                } else {
                                    // Driver node does not exist
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                // Handle errors
                            }
                        });

                        DatabaseReference driverRef2 = mDatabase.child("departure").child("driver").child("1");
                        driverRef2.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    String driverName2 = dataSnapshot.child("driverName").getValue(String.class);

                                    driverPhoneNumber2 = dataSnapshot.child("driverPhoneNumber").getValue(String.class);

                                    //Save driverphonenumber
                                    driverPhoneNumber = driverPhoneNumber2;

                                    Log.d("driverName", driverName2);
                                    Log.d("driverPhoneNumber", driverPhoneNumber2);

                                    // Update UI with driver's name and phone number
                                    // For example:
                                    txtViewInvoiceOngoingPhoneDriver2.setText(driverPhoneNumber2);
                                    // Similarly, update other views with driverPhoneNumber if needed
                                } else {
                                    // Driver node does not exist
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                // Handle errors
                            }
                        });

                        DatabaseReference busType = mDatabase.child("ticket").child("_id").child("66115b2b29cada4e5f00eb3c");
                        busType.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    String busTypeName = dataSnapshot.child("bus").getValue(String.class);

                                    Log.d("bus", busTypeName);

                                    // Update UI with driver's name and phone number
                                    // For example:
                                    txtViewInvoiceOngoingBusType.setText(busTypeName);
                                    // Similarly, update other views with driverPhoneNumber if needed
                                } else {
                                    // Driver node does not exist
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                // Handle errors
                            }
                        });

                        DatabaseReference seatNumber1 = mDatabase.child("departure").child("seat").child(mDatabase.getKey());
                        seatNumber1.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    String seatLocation1 = dataSnapshot.child("seat").child(String.valueOf(0)).getValue(String.class);
                                    String seatLocation2 = dataSnapshot.child("seat").child(String.valueOf(1)).getValue(String.class);
                                    if (seatLocation1 !=null && seatLocation2==null){
                                        String aSeat = seatLocation1 + seatLocation2 + " (Departure Trip)";

                                        Log.d("seat", seatLocation1);
                                        Log.d("seat",seatLocation2);

                                        txtViewInvoiceOngoingSeatDepart.setText(aSeat);
                                    }



                                    // Update UI with driver's name and phone number
                                    // For example:


                                    // Similarly, update other views with driverPhoneNumber if needed
                                } else {
                                    // Driver node does not exist
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                // Handle errors
                            }
                        });

                        DatabaseReference seatNumber2 = mDatabase.child("return").child("seat").child(mDatabase.getKey());
                        seatNumber2.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    String seatLocation3 = dataSnapshot.child("seat").child(String.valueOf(0)).getValue(String.class);
                                    String seatLocation4 = dataSnapshot.child("seat").child(String.valueOf(1)).getValue(String.class);
                                    if (seatLocation3 !=null && seatLocation4==null){
                                        String dSeat = seatLocation3 + seatLocation4 + " (Return Trip)";

                                        Log.d("seat", seatLocation3);
                                        Log.d("seat",seatLocation4);

                                        txtViewInvoiceOngoingSeatReturn.setText(dSeat);
                                    }



                                    // Update UI with driver's name and phone number
                                    // For example:


                                    // Similarly, update other views with driverPhoneNumber if needed
                                } else {
                                    // Driver node does not exist
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                // Handle errors
                            }
                        });

                        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("BookedTicket");

                        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    StringBuilder dataText = new StringBuilder();

                                    // Retrieve departure pick-up point
                                    DataSnapshot departurePickUpPoint = dataSnapshot.child("departure").child("pickUpPoint");
                                    String departurePickUpPointText = departurePickUpPoint.child("point").getValue(String.class);
                                    String departurePickUpPointAddress = departurePickUpPoint.child("address").getValue(String.class);

                                    // Retrieve departure drop-off point
                                    DataSnapshot departureDropOffPoint = dataSnapshot.child("departure").child("dropOffPoint");
                                    String departureDropOffPointText = departureDropOffPoint.child("point").getValue(String.class);
                                    String departureDropOffPointAddress = departureDropOffPoint.child("address").getValue(String.class);

                                    // Retrieve return pick-up point
                                    DataSnapshot returnPickUpPoint = dataSnapshot.child("return").child("pickUpPoint");
                                    String returnPickUpPointText = returnPickUpPoint.child("point").getValue(String.class);
                                    String returnPickUpPointAddress = returnPickUpPoint.child("address").getValue(String.class);

                                    // Retrieve return drop-off point
                                    DataSnapshot returnDropOffPoint = dataSnapshot.child("return").child("dropOffPoint");
                                    String returnDropOffPointText = returnDropOffPoint.child("point").getValue(String.class);
                                    String returnDropOffPointAddress = returnDropOffPoint.child("address").getValue(String.class);

                                    // Set the formatted data to the text view
                                    txtViewInvoiceOngoingDepartPickupLocation.setText(departurePickUpPointText.toString());
                                    txtViewInvoiceOngoingDepartPickupDescription.setText(departurePickUpPointAddress.toString());
                                    txtViewInvoiceOngoingDepartDropoffLocation.setText(departureDropOffPointText.toString());
                                    txtViewInvoiceOngoingDepartDropoffDescription.setText(departureDropOffPointAddress.toString());


                                } else {
                                    // Handle if the dataSnapshot doesn't exist
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                // Handle errors
                            }
                        });

                        // Initialize a variable to count the total seats
                        final int[] totalSeats = {0};

// Retrieve seat data from the departure trip
                        DatabaseReference departureSeatRef = mDatabase.child("departure").child("seat").child(mDatabase.getKey());
                        departureSeatRef.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    // Add the number of seats from departure trip to the total count
                                    totalSeats[0] += (int) dataSnapshot.getChildrenCount();

                                    // Retrieve seat data from the return trip
                                    DatabaseReference returnSeatRef = mDatabase.child("return").child("seat").child(mDatabase.getKey());
                                    returnSeatRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                        int totalSeats1 = 0;
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            if (dataSnapshot.exists()) {
                                                // Add the number of seats from return trip to the total count
                                                totalSeats1 += (int) dataSnapshot.getChildrenCount();

                                                // Update the total seat count in the text view
                                                txtViewInvoiceOngoingTicketTotal.setText(String.valueOf(totalSeats[0]));
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {
                                            // Handle errors
                                        }
                                    });
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                // Handle errors
                            }
                        });
                        // Reference to total1 node
                        DatabaseReference total1Ref = mDatabase.child("departure").child("totalPrice");
                        DatabaseReference total2Ref = mDatabase.child("return").child("totalPrice");
                        DatabaseReference voucherRef = mDatabase.child("voucher").child("_id");

                        final int[] total1 = {0};
                        final int[] total2 = {0};

// Add a ValueEventListener for total1
                        total1Ref.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    // Retrieve total1 from the dataSnapshot
                                    total1[0] = dataSnapshot.getValue(Integer.class);
                                    // Once total1 is retrieved, proceed to retrieve total2
                                    retrieveTotal2();
                                } else {
                                    // Handle the case where total1 node does not exist
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                // Handle errors
                            }

                            private void retrieveTotal2() {
                                total2Ref.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        if (dataSnapshot.exists()) {
                                            // Retrieve total2 from the dataSnapshot
                                            total2[0] = dataSnapshot.getValue(Integer.class);
                                            // Now you have both total1 and total2, you can calculate the sum
                                            int sum = total1[0] + total2[0];
                                            String sumString = String.valueOf(sum);
                                            txtViewInvoiceOngoingSubtotal.setText(sumString);

                                            // After retrieving the total sum, calculate the discount
                                            calculateAndSetDiscount(sum);
                                        } else {
                                            // Handle the case where total2 node does not exist
                                        }
                                        // Dismiss the ProgressDialog when data loading is complete
                                        progressDialog.dismiss();
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                        // Handle errors
                                        // Dismiss the ProgressDialog if loading is canceled or fails
                                        progressDialog.dismiss();
                                    }
                                });
                            }
                        });

// Add a ValueEventListener to retrieve voucher discount data
                        voucherRef.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    // Retrieve voucher rate from the dataSnapshot
                                    String voucherRate = dataSnapshot.child("voucherRate").getValue(String.class);

                                    // Now you can use the voucher rate as needed
                                    Log.d("Voucher Rate", voucherRate);
                                    // Calculate and set the discount amount
                                    int sum = 0;
                                    calculateAndSetDiscount(sum);
                                } else {
                                    // Voucher node does not exist
                                    Log.d("Voucher", "Voucher not found");
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                // Handle errors
                            }
                        });






                        Log.d("category", onGoingCategory);
                        Log.d("email",onGoingEmail);
                        Log.d("name",onGoingName);
                        Log.d("phoneNumber",onGoingPhoneNumber);
                        Log.d("licensePlate",onGoingLicensePlate);
                        Log.d("driverPhoneNumber", String.valueOf(txtViewInvoiceOngoingPhoneDriver1));
                        Log.d("driverPhoneNumber", String.valueOf(txtViewInvoiceOngoingPhoneDriver2));
                        Log.d("paymentTime",onGoingPaymentTime);
                        Log.d("TransactionNumber",onGoingTransactionNumber);
                        Log.d("aLocation",onGoingDepartureTrip);
                        Log.d("dLocation",onGoingReturnTrip);
                        Log.d("state",onGoingState);


                        updateUI(onGoingTicket);
                    }

                } else {
                    // Node does not exist
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle errors
            }
        });
    }

    private void calculateAndSetDiscount(int sum) {
        // Calculate discount based on voucher rate
        double voucherRate = 0.2; // Assuming voucher rate is 20%
        double discountAmount = sum * voucherRate;

        // Set the discount amount to the UI
        txtViewInvoiceOngoingDiscount.setText("- " + String.valueOf(discountAmount));
    }
    // Convert txtViewInvoiceOngoingSubtotal and txtViewInvoiceOngoingDiscount to doubles
    double subtotal = Double.parseDouble(txtViewInvoiceOngoingSubtotal.getText().toString());
    double discount = Double.parseDouble(txtViewInvoiceOngoingDiscount.getText().toString());

    // Calculate the total price
    double totalPrice = subtotal - discount;
//    txtTotalPrice.setText(String.valueOf(totalPrice));




    private void updateUI(OnGoingTicket ticket) {
        // Update UI with ticket data
        // For example:
        txtViewInvoiceOngoingTag.setText(onGoingTicket.getOngoingCategory());
        txtViewInvoiceOngoingEmailSent.setText(onGoingTicket.getOngoingEmail());
        txtViewInvoiceOngoingName.setText(onGoingTicket.getOngoingName());
        txtViewInvoiceOngoingEmail.setText(onGoingTicket.getOngoingEmail());
        txtViewInvoiceOngoingPhoneNumber.setText(onGoingTicket.getOngoingPhoneNumber());
        txtViewInvoiceOngoingLicensePlate.setText(onGoingTicket.getOngoingLicenseNumber());
        txtViewInvoiceOngoingPhoneDriver1.setText(onGoingTicket.getOngoingDriverPhoneNumber1());
        txtViewInvoiceOngoingPhoneDriver2.setText(onGoingTicket.getOngoingDriverPhoneNumber2());
        txtViewInvoiceOngoingTimestamp.setText(onGoingTicket.getOngoingPaymentTime());
        txtViewInvoiceOngoingTransactionNo.setText(onGoingTicket.getOngoingTransactionNumber());
        txtViewInvoiceOngoingState.setText(onGoingTicket.getOngoingState());



    }

    private void addEvents() {
        imgViewInvoiceOngoingBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ViewInvoice_OngoingActivity.this,PaidTicketActivity.class);
                startActivity(intent);
            }
        });
        btnViewInvoiceOngoingHomepage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ViewInvoice_OngoingActivity.this,HomepageActivity.class);
                startActivity(intent);
            }
        });
        
        //Click on Image Call
        imageCallButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (driverPhoneNumber1 != null) {
                    showCallConfirmationDialog(driverPhoneNumber1);
                } else {
                    // Show a toast message indicating that the driver's phone number is not available
                    Toast.makeText(ViewInvoice_OngoingActivity.this, "Driver's phone number not available", Toast.LENGTH_SHORT).show();
                }
            }
        });
        imageCallButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (driverPhoneNumber2 != null) {
                    showCallConfirmationDialog(driverPhoneNumber2);
                } else {
                    // Handle case where driver phone number is not available
                    Toast.makeText(ViewInvoice_OngoingActivity.this, "Driver's phone number not available", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void showCallConfirmationDialog(final String driverPhoneNumber) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Call Driver?");
        builder.setMessage("Do you want to make a direct call to driver?");
        // YES Button
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                makeDirectCall(driverPhoneNumber);
            }
        });
        // NO Button
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        // Create an AlertDialog
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);

        // Show Dialog
        dialog.show();
    }


    private void makeDirectCall(String driverPhoneNumber) {
        Intent intent = new Intent(Intent.ACTION_CALL);
        Uri uri = Uri.parse("tel:" + driverPhoneNumber);
        intent.setData(uri);
        startActivity(intent);
    }

    private void addViews() {
        imgViewInvoiceOngoingBack=findViewById(R.id.imgViewInvoiceOngoingBack);
        txtViewInvoiceOngoingCountDown=findViewById(R.id.txtViewInvoiceOngoingCountDown);
        txtViewInvoiceOngoingEmailSent=findViewById(R.id.txtViewInvoiceOngoingEmailSent);
        txtViewInvoiceOngoingTag=findViewById(R.id.txtViewInvoiceOngoingTag);
        txtViewInvoiceOngoingName=findViewById(R.id.txtViewInvoiceOngoingName);
        txtViewInvoiceOngoingPhoneNumber=findViewById(R.id.txtViewInvoiceOngoingPhoneNumber);
        txtViewInvoiceOngoingEmail=findViewById(R.id.txtViewInvoiceOngoingEmail);
        txtViewInvoiceOngoingLicensePlate=findViewById(R.id.txtViewInvoiceOngoingLicensePlate);
        txtViewInvoiceOngoingPhoneDriver1=findViewById(R.id.txtViewInvoiceOngoingPhoneDriver1);
        txtViewInvoiceOngoingPhoneDriver2=findViewById(R.id.txtViewInvoiceOngoingPhoneDriver2);
        txtViewInvoiceOngoingTimestamp=findViewById(R.id.txtViewInvoiceOngoingTimestamp);
        txtViewInvoiceOngoingTransactionNo=findViewById(R.id.txtViewInvoiceOngoingTransactionNo);
        txtViewInvoiceOngoingTrip=findViewById(R.id.txtViewInvoiceOngoingTrip);
        txtViewInvoiceOngoingState=findViewById(R.id.txtViewInvoiceOngoingState);
        txtViewInvoiceOngoingBusType=findViewById(R.id.txtViewInvoiceOngoingBusType);
        txtViewInvoiceOngoingQuantity=findViewById(R.id.txtViewInvoiceOngoingQuantity);
        txtViewInvoiceOngoingSeatDepart=findViewById(R.id.txtViewInvoiceOngoingSeatDepart);
        txtViewInvoiceOngoingSeatReturn=findViewById(R.id.txtViewInvoiceOngoingSeatReturn);
        txtViewInvoiceOngoingDepartPickupLocation=findViewById(R.id.txtViewInvoiceOngoingDepartPickupLocation);
        txtViewInvoiceOngoingDepartPickupDescription=findViewById(R.id.txtViewInvoiceOngoingDepartPickupDescription);
        txtViewInvoiceOngoingDepartPickupExpectedTime=findViewById(R.id.txtViewInvoiceOngoingDepartPickupExpectedTime);
        txtViewInvoiceOngoingDepartDropoffLocation=findViewById(R.id.txtViewInvoiceOngoingDepartDropoffLocation);
        txtViewInvoiceOngoingDepartDropoffDescription=findViewById(R.id.txtViewInvoiceOngoingDepartDropoffDescription);
        txtViewInvoiceOngoingDepartDropoffExptectedTime=findViewById(R.id.txtViewInvoiceOngoingDepartDropoffExptectedTime);
        txtViewInvoiceOngoingReturnDepartPickupLocation=findViewById(R.id.txtViewInvoiceOngoingReturnDepartPickupLocation);
        txtViewInvoiceOngoingReturnDepartPickupDescription=findViewById(R.id.txtViewInvoiceOngoingReturnDepartPickupDescription);
        txtViewInvoiceOngoingReturnDepartPickupExpectedTime=findViewById(R.id.txtViewInvoiceOngoingReturnDepartPickupExpectedTime);
        txtViewInvoiceOngoingReturnDropoffLocation=findViewById(R.id.txtViewInvoiceOngoingReturnDropoffLocation);
        txtViewInvoiceOngoingReturnDropoffDescription=findViewById(R.id.txtViewInvoiceOngoingReturnDropoffDescription);
        txtViewInvoiceOngoingReturnDropoffExpectedTime=findViewById(R.id.txtViewInvoiceOngoingReturnDropoffExpectedTime);
        txtViewInvoiceOngoingTicketTotal=findViewById(R.id.txtViewInvoiceOngoingTicketTotal);
        txtViewInvoiceOngoingSubtotal=findViewById(R.id.txtViewInvoiceOngoingSubtotal);
        txtViewInvoiceOngoingDiscount=findViewById(R.id.txtViewInvoiceOngoingDiscount);
        txtViewInvoiceOngoingTotal=findViewById(R.id.txtViewInvoiceOngoingTotal);
        btnViewInvoiceOngoingHomepage=findViewById(R.id.btnViewInvoiceOngoingHomepage);
        btnViewInvoiceOngoingTellUs=findViewById(R.id.btnViewInvoiceOngoingTellUs);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        bookedTicketId = sharedPreferences.getString("BookedTicketId", "");

        imageCallButton1 = findViewById(R.id.imageCallButton1);
        imageCallButton2 = findViewById(R.id.imageCallButton2);

    }
}