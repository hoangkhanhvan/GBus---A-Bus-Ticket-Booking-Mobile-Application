package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.CompleteTicketAdapter;
import com.vanhk.gbus.adapter.PaidTicketAdapter;
import com.vanhk.gbus.adapter.UnPaidAdapter;
import com.vanhk.gbus.model.Booked;
import com.vanhk.gbus.model.PaidTicket;
import com.vanhk.gbus.model.UnPaidTicket;

import java.util.ArrayList;

public class PaidTicketActivity extends AppCompatActivity implements PaidTicketAdapter.OnPaidTicketClickListener, PaidTicketAdapter.OnCancelClickListener{
    ImageView imgPaidTicketBack;
    TextView txtPaidTicketUnpaid,txtPaidTicketPaid,txtPaidTicketCancelled,txtPaidTicketDate;
    ListView lvPaidTicketList;
    PaidTicketAdapter paidTicketAdapter;
    CompleteTicketAdapter completeTicketAdapter;
    String TAG = "FIREBASE";

    ArrayList<PaidTicket> PaidTickets = new ArrayList<>();
    ArrayList<PaidTicket> OngoingTickets = new ArrayList<>();

    ProgressDialog progressDialog; // Declare ProgressDialog

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paid_ticket);
        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog
        progressDialog.setMessage("Loading tickets ...");
        progressDialog.setCancelable(false);
        addViews();
        addEvents();
    }

    private void addEvents() {
        imgPaidTicketBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HomepageActivity.class);
                startActivity(intent);
                finish();
            }
        });
        txtPaidTicketUnpaid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show(); // Show ProgressDialog when navigating to Unpaid Ticket Activity
                Intent intent = new Intent(PaidTicketActivity.this,UnpaidTicketActivity.class);
                startActivity(intent);
            }
        });
        txtPaidTicketCancelled.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show(); // Show ProgressDialog when navigating to Cancellation Activity
                Intent intent = new Intent(PaidTicketActivity.this,CancellationActivity.class);
                startActivity(intent);
            }
        });
    }

    private void addViews() {
        imgPaidTicketBack=findViewById(R.id.imgPaidTicketBack);
        txtPaidTicketUnpaid=findViewById(R.id.txtPaidTicketUnpaid);
        txtPaidTicketPaid=findViewById(R.id.txtPaidTicketPaid);
        txtPaidTicketCancelled=findViewById(R.id.txtPaidTicketCancelled);
        lvPaidTicketList=findViewById(R.id.lvPaidTicketList);
        paidTicketAdapter = new PaidTicketAdapter(PaidTicketActivity.this, R.layout.lv_paid_ticket_upcoming, PaidTickets);
        completeTicketAdapter = new CompleteTicketAdapter(PaidTicketActivity.this,R.layout.lv_paid_ticket_complete,PaidTickets);

//        paidTicketAdapter.setonPaidTicketClickListener((PaidTicketAdapter.onPaidTicketClickListener) this);
//        paidTicketAdapter.setonCancelClickListener((PaidTicketAdapter.onCancelClickListener) this);
        lvPaidTicketList.setAdapter(paidTicketAdapter);

        loadData();

    }
    private void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String accountId = sharedPreferences.getString("accountId","account1");

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myUnPaidTicket = database.getReference("BookedTicket");
        myUnPaidTicket.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot data : snapshot.getChildren()) {
                    String status = data.child("status").getValue(String.class);
                    String ticketAccountId = data.child("accountId").getValue(String.class);
                    Toast.makeText(PaidTicketActivity.this, accountId+"-"+ticketAccountId, Toast.LENGTH_SHORT).show();
                    if (accountId.equals(ticketAccountId) && status != null && status.equals("Paid")) {
                        String transactionNumber = data.child("TransactionNumber").getValue(String.class);
                        String bookedTime = data.child("bookedTime").getValue(String.class);
                        String totalPayment = data.child("discountPrice").getValue(String.class);
                        Booked departureTicket = data.child("departure").getValue(Booked.class);
                        Booked returnTicket = data.child("return").getValue(Booked.class);

                        PaidTicket newPaidTicket = new PaidTicket();
                        newPaidTicket.set_id(transactionNumber);
                        newPaidTicket.setTransactionNumber(transactionNumber);
                        newPaidTicket.setAccountId(ticketAccountId);
                        newPaidTicket.setDeparture(departureTicket);
                        newPaidTicket.setReturn(returnTicket);
                        newPaidTicket.setBookedTime(bookedTime);
                        newPaidTicket.setTotalPayment(totalPayment);

                        paidTicketAdapter.add(newPaidTicket);
                        PaidTickets.add(newPaidTicket);
                    }
                }
                progressDialog.dismiss(); // Dismiss ProgressDialog after loading data

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss(); // Dismiss ProgressDialog if loading is canceled

            }
        });
        DatabaseReference myRef = database.getReference("Tickets");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot data : snapshot.getChildren()) {
                    String ticketId = data.getKey();
                    assert ticketId != null;
                    // Now you can use the routeId string as needed
                    if (ticketId.equals("661173fd29cada4e5f00eb45")) {
                        String timeDepart = data.child("DTime").getValue(String.class);
                        String dateDepart = data.child("Date").getValue(String.class);
                        String busDepart = data.child("Bus").getValue(String.class);
                        // Now you have routeDepart and routeReturn for the specified routeId
                        // You can use these values as needed
                        Log.d("TimeDepart", timeDepart);
                        Log.d("DateDepart", dateDepart);
                        Log.d("BusDepart", busDepart);
                    }
                    // You can add similar conditions for other routeIds as needed
                    else if (ticketId.equals("661173fd29cada4e5f00eb46")) {
                        String timeDepartSecond = data.child("DTime").getValue(String.class);
                        String dateDepartSecond = data.child("Date").getValue(String.class);
                        String busDepartSecond = data.child("Bus").getValue(String.class);
                        // Now you have routeDepart and routeReturn for the second specified routeId
                        // You can use these values as needed
                        Log.d("TimeDepartSecond", timeDepartSecond);
                        Log.d("DateDepart", dateDepartSecond);
                        Log.d("BusDepartSecond", busDepartSecond);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle error

            }
        });
        myRef = database.getReference("RouteWithPoints");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot data : snapshot.getChildren()) {
                    String routeId = data.getKey();
                    assert routeId != null;
                    // Now you can use the routeId string as needed
                    if (routeId.equals("66100befbf18bf63fb4898de")) {
                        String routeDepart = data.child("ALocation").getValue(String.class);
                        String routeReturn = data.child("DLocation").getValue(String.class);
                        // Now you have routeDepart and routeReturn for the specified routeId
                        // You can use these values as needed
                        Log.d("RouteDepart", routeDepart);
                        Log.d("RouteReturn", routeReturn);
                    }
                    // You can add similar conditions for other routeIds as needed
                    else if (routeId.equals("66100f8abf18bf63fb4898e0")) {
                        String routeDepart = data.child("ALocation").getValue(String.class);
                        String routeReturn = data.child("DLocation").getValue(String.class);
                        // Now you have routeDepart and routeReturn for the second specified routeId
                        // You can use these values as needed
                        Log.d("RouteDepartSecond", routeDepart);
                        Log.d("RouteReturnSecond", routeReturn);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle error

            }
        });
    }

    public void onCancelClick(int position) {
        PaidTicket paidTicket = paidTicketAdapter.getItem(position);
        Intent getIntent = getIntent();
        String accountId = getIntent().getStringExtra("accountId");
        Intent intent = new Intent(PaidTicketActivity.this,Cancellation1Activity.class);
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("bookedTicketId",paidTicket.get_id());
        editor.apply();

        intent.putExtra("BookedTicket", (CharSequence) paidTicket);

        startActivity(intent);
    }
    public void onPaidTicketClick(int position) {
        PaidTicket paidTicket = paidTicketAdapter.getItem(position);
        Intent getIntent = getIntent();
        String accountId = getIntent().getStringExtra("accountId");
        Intent intent = new Intent(PaidTicketActivity.this, ViewInvoice_UpcomingActivity.class);
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("bookedTicketId",paidTicket.get_id());
        editor.apply();

        intent.putExtra("BookedTicket", (CharSequence) paidTicket);

        startActivity(intent);
    }
}