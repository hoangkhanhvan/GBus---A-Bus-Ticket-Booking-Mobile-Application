package com.vanhk.gbus.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.vanhk.gbus.R;
import com.vanhk.gbus.model.TripDetail5;

public class TripDetail5Adapter extends ArrayAdapter<TripDetail5> {
    Activity context;
    int resource;
    public TripDetail5Adapter(@NonNull Activity context, int resource) {
        super(context, resource);
        this.context=context;
        this.resource=resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = this.context.getLayoutInflater();
        View tripdetail5 = inflater.inflate(this.resource,null);

        ImageView imgTripDetails5EmployeeInfo = tripdetail5.findViewById(R.id.imgTripDetails5EmployeeInfo);
        TextView txtTripDetails5EmployeeInfoName = tripdetail5.findViewById(R.id.txtTripDetails5EmployeeInfoName);
        TextView txtTripDetails5License = tripdetail5.findViewById(R.id.txtTripDetails5License);
        TextView tripDetails5TravelTrips = tripdetail5.findViewById(R.id.tripDetails5TravelTrips);
        TextView txtTripDetails5Hours = tripdetail5.findViewById(R.id.txtTripDetails5Hours);
        TextView txtTripDetails5EmployeeInfoRatingStar = tripdetail5.findViewById(R.id.txtTripDetails5EmployeeInfoRatingStar);
        TextView txtTripDetails5EmployeeInfoPhoneNumber = tripdetail5.findViewById(R.id.txtTripDetails5EmployeeInfoPhoneNumber);

        TripDetail5 tripDetail5 = getItem(position);
        imgTripDetails5EmployeeInfo.setImageBitmap(tripDetail5.getAvatar());
        txtTripDetails5EmployeeInfoName.setText(tripDetail5.getName());
        txtTripDetails5License.setText(tripDetail5.getLicense());
        tripDetails5TravelTrips.setText(tripDetail5.getTravelTrip());
        txtTripDetails5Hours.setText(tripDetail5.getHours());
        txtTripDetails5EmployeeInfoRatingStar.setText((CharSequence) tripDetail5.getRating());
        txtTripDetails5EmployeeInfoPhoneNumber.setText(tripDetail5.getPhoneNumber());

        return tripdetail5;
    }


}
