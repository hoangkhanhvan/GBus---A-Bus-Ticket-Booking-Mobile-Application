package com.vanhk.gbus;

import static android.content.ContentValues.TAG;
import static com.vanhk.gbus.TripDetails1Activity.calculateDate;
import static com.vanhk.gbus.TripDetails1Activity.calculateTime;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.Point2;
import com.vanhk.gbus.adapter.EditPoint;
import com.vanhk.gbus.model.Ticket;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class PickupDeparture1Activity extends AppCompatActivity {

    // Declare variables for the views
    TextView txtPickupDeparture1Pickup;
    TextView txtPickup;
    TextView txtDropoff;
    TextView txtTotal;
    EditPoint editPointAdapter;
    ListView lvPickupDeparture1;
    String accountId;
    Ticket selectedTicket;
    int TotalPrice;
    ArrayList<String> search;
    ProgressDialog progressDialog; // Declare ProgressDialog variable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pickup_departure1);
        // Initialize views
        addViews();

        // Initialize the progressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable

        // Show the ProgressDialog
        progressDialog.show();

        // Load data from Firebase
        loadData();

        // Get total price from Intent and display it
        int totalPrice = getIntent().getIntExtra("totalPrice", 0);
        TextView txtTotalPrice = findViewById(R.id.txtPickupDeparture1Total);
        txtTotalPrice.setText(String.format("%,d VND", totalPrice));

        // Set OnClickListener for back button
        ImageView imgPickupDepartureBack = findViewById(R.id.imgPickupDepartureBack);
        imgPickupDepartureBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Set OnClickListener for "Continue" button
        Button btnContinue = findViewById(R.id.btnPickupDeparture1Book);
        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Proceed to the next screen
                Point2 selectedPoint = editPointAdapter.getSelectedPoint();

                if (selectedPoint == null) {
                    return;
                }

                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                boolean isReturn = sharedPreferences.getBoolean("isReturn",false);
                if (isReturn) {
                    MySharedPreferences.saveObject(PickupDeparture1Activity.this, "RPickUpPoint", selectedPoint);
                    Toast.makeText(PickupDeparture1Activity.this, "Return", Toast.LENGTH_SHORT).show();
                } else {
                    MySharedPreferences.saveObject(PickupDeparture1Activity.this, "DPickUpPoint", selectedPoint);
                }

                

                Intent intent = new Intent(PickupDeparture1Activity.this,DropoffDeparture1Activity.class);
                intent.putExtra("totalPrice", totalPrice);
                intent.putExtra("ticket", selectedTicket);
                intent.putStringArrayListExtra("search",search);
                startActivity(intent);
            }
        });

    }

    private void loadData() {

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("RouteWithPoints");
        ArrayList<Point2> count = new ArrayList<>();
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot data: dataSnapshot.getChildren()) {
                    String _id = data.child("_id").getValue(String.class);
                    assert _id != null;
                    if (_id.equals(selectedTicket.getRoute())) {
                        for (DataSnapshot points: data.child("PickUpPoints").getChildren()) {
                            Point2 point = new Point2();
                            Long time = points.child("Time").getValue(Long.class);
                            if (time != null) {
                                point.setPoint(points.child("Point").getValue(String.class));
                                point.setAddress(points.child("Address").getValue(String.class));
                                point.setShuttleBus(points.child("ShuttleBus").getValue(Boolean.class));
                                String timeStr = calculateTime(selectedTicket.getDTime(),time.intValue());
                                point.setTime(timeStr);
                                String dateStr = calculateDate(selectedTicket.getDate(),selectedTicket.getDTime(),time.intValue());
                                point.setDateStr(dateStr);
                                editPointAdapter.add(point);
                                count.add(point);
                            }
                        }
                    }
                }
                // Dismiss the ProgressDialog when the data loading is complete
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e(TAG, "loadPost:onCancelled", databaseError.toException());
            }
        });
    }

    private void addViews() {
        txtPickup = findViewById(R.id.txtPickupDeparture1Pickup);
        txtDropoff = findViewById(R.id.txtPickupDeparture1Dropoff);
        lvPickupDeparture1 = findViewById(R.id.lvPickupDeparture1);
        txtTotal = findViewById(R.id.txtPickupDeparture1Total);

        Intent getIntent = getIntent();
        selectedTicket = (Ticket) getIntent.getSerializableExtra("ticket");

        TextView textView64 = findViewById(R.id.textView64);
        TextView textView26 = findViewById(R.id.txtTripDetail5DepartLocation);
        TextView textView29 = findViewById(R.id.txtTripDetail5ArrivalLocation);
        TextView textView27 = findViewById(R.id.textView27);
        TextView textView28 = findViewById(R.id.textView28);

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String DLocation = sharedPreferences.getString("DLocation","");
        String ALocation = sharedPreferences.getString("ALocation","");
        String DDate = sharedPreferences.getString("DDate","");
        String RDate = sharedPreferences.getString("RDate","");

        textView64.setText(selectedTicket.getBus());
        textView26.setText(DLocation);
        textView29.setText(ALocation);
        if (RDate.equals("Select Return Date")) {
            textView27.setText("One Way Trip");
        } else {
            textView27.setText("Round Trip");
        }
        textView28.setText(DDate);

        editPointAdapter = new EditPoint(PickupDeparture1Activity.this, R.layout.lv_editpickuppoint_depart1_shuttlebus_edt, new ArrayList<>());
        lvPickupDeparture1.setAdapter(editPointAdapter);
    }

    // Utility methods for calculating date and time
    public static String calculateDate(String dateString, String timeString, int minutesToAdd) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(dateFormat.parse(dateString + " " + timeString));
            calendar.add(Calendar.MINUTE, minutesToAdd);
            SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd/MM");
            return outputDateFormat.format(calendar.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String calculateTime(String timeString, int minutesToAdd) {
        // Split the time string into hours and minutes
        String[] parts = timeString.split(":");
        int hours = Integer.parseInt(parts[0]);
        int minutes = Integer.parseInt(parts[1]);

        // Convert time to minutes
        int totalMinutes = hours * 60 + minutes;

        // Add the minutes
        totalMinutes += minutesToAdd;

        // Adjust if the total minutes is negative
        if (totalMinutes < 0) {
            totalMinutes += 24 * 60; // Add 24 hours worth of minutes
        }

        // Calculate the new hours and minutes
        int newHours = totalMinutes / 60;
        int newMinutes = totalMinutes % 60;

        // Format the new time
        String newTimeString = String.format("%02d:%02d", newHours, newMinutes);
        return newTimeString;
    }

}
