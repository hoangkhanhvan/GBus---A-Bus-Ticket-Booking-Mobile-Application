package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.model.CancelTicket;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.PaidTicket;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;

//loadData từ tripDepart chưa đc
public class Cancellation5Activity extends AppCompatActivity {
    ProgressDialog progressDialog; // ProgressDialog instance
    ImageView imgCancellation5Back;
    TextView txtCancellation5Reason, txtCancellation5TransactionNo, txtCancellation5CancelTime, txtCancellation5CancelFee, txtCancellation5RefundAmount, txtCancellation5CancelTotalPayment, txtCancellation5DepartTitle, txtCancellationDepartPickUpTime, txtCancellation5DepartPickUpDate, txtCancellation5DepartPickUpPoint, txtCancellation5DepartPickUpLocation, txtCancellation5DepartDropOffTime, txtCancellation5DepartDropOffPoint, txtCancellation5DepartDropOffLocation, txtCancellation5DepartDropOffDate, txtCancellation5ReturnTitle, txtCancellation5ReturnDescription, txtCancellation5ReturnSeatNo, txtCancellation5ReturnPickUpTime, txtCancellation5ReturnPickUpDate, txtCancellation5ReturnPickUpPoint, txtCancellation5ReturnPickUpLocation, txtCancellation5ReturnDropOffTime, txtCancellation5ReturnDropOffDate, txtCancellation5ReturnDropOffPoint, txtCancellation5ReturnDropOffLocation, txtCancellation5ReturnDropOffShuttleBus;
    Button btnCancellation5Book, btnCancellation5TellUs;
    TextView txtCancellation5DepartSeatNo;
    String TAG = "FIREBASE";
    ArrayList<CancelTicket> cancelTickets = new ArrayList<>();
    LinearLayout llReturn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancellation5);
        addViews();
        addEvents();

        progressDialog = new ProgressDialog(this); // Initialize progressDialog
        progressDialog.setMessage("Loading Data..."); // Set message for progressDialog
        progressDialog.setCancelable(false); // Make progressDialog not cancellable
        progressDialog.show(); // Show progressDialog when activity starts

    }

    private void addEvents() {
        imgCancellation5Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), PaidTicketActivity.class);
                startActivity(intent);
                finish();
            }
        });
        btnCancellation5Book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PaidTicket paidTicket = MySharedPreferences.getObject(getApplicationContext(),"cancelingTicket",PaidTicket.class);
                Intent intent = new Intent(getApplicationContext(), ResultList1Activity.class);

                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean("isReturnDone",false);
                if (paidTicket.getReturn() != null) {
                    editor.putString("RDate", paidTicket.getReturn().getTicket().getDate());
                } else {
                    editor.putString("RDate", "Select Return Date");
                }

                editor.putString("DLocation",paidTicket.getDeparture().getDLocation());
                editor.putString("ALocation",paidTicket.getDeparture().getALocation());
                editor.putString("DDate",paidTicket.getDeparture().getTicket().getDate());

                editor.apply();
                startActivity(intent);
            }
        });
    }

    private void addViews() {
        imgCancellation5Back = findViewById(R.id.imgCancellation5Back);
        txtCancellation5Reason = findViewById(R.id.txtCancellation5Reason);
        txtCancellation5TransactionNo = findViewById(R.id.txtCancellation5TransactionNo);
        txtCancellation5CancelTime = findViewById(R.id.txtCancellation5CancelTime);
        txtCancellation5CancelFee = findViewById(R.id.txtCancellation5CancelFee);
        txtCancellation5RefundAmount = findViewById(R.id.txtCancellation5RefundAmount);
        btnCancellation5Book = findViewById(R.id.btnCancellation5Book);
        btnCancellation5TellUs = findViewById(R.id.btnCancellation5TellUs);
        txtCancellation5CancelTotalPayment = findViewById(R.id.txtCancellation5CancelTotalPayment);
        txtCancellation5DepartTitle = findViewById(R.id.txtCancellation5DepartTitle);
        txtCancellationDepartPickUpTime = findViewById(R.id.txtCancellationDepartPickUpTime);
        txtCancellation5DepartPickUpDate = findViewById(R.id.txtCancellation5DepartPickUpDate);
        txtCancellation5DepartPickUpPoint = findViewById(R.id.txtCancellation5DepartPickUpPoint);
        txtCancellation5DepartPickUpLocation = findViewById(R.id.txtCancellation5DepartPickUpLocation);
        txtCancellation5DepartDropOffTime = findViewById(R.id.txtCancellation5DepartDropOffTime);
        txtCancellation5DepartDropOffPoint = findViewById(R.id.txtCancellation5DepartDropOffPoint);
        txtCancellation5DepartDropOffLocation = findViewById(R.id.txtCancellation5DepartDropOffLocation);
        txtCancellation5DepartSeatNo = findViewById(R.id.txtCancellation5DepartSeatNo);
        txtCancellation5ReturnTitle = findViewById(R.id.txtCancellation5ReturnTitle);
        txtCancellation5ReturnDescription = findViewById(R.id.txtCancellation5ReturnDescription);
        txtCancellation5ReturnSeatNo = findViewById(R.id.txtCancellation5ReturnSeatNo);
        txtCancellation5ReturnPickUpTime = findViewById(R.id.txtCancellation5ReturnPickUpTime);
        txtCancellation5ReturnPickUpDate = findViewById(R.id.txtCancellation5ReturnPickUpDate);
        txtCancellation5ReturnPickUpPoint = findViewById(R.id.txtCancellation5ReturnPickUpPoint);
        txtCancellation5ReturnPickUpLocation = findViewById(R.id.txtCancellation5ReturnPickUpLocation);
        txtCancellation5ReturnDropOffTime = findViewById(R.id.txtCancellation5ReturnDropOffTime);
        txtCancellation5ReturnDropOffDate = findViewById(R.id.txtCancellation5ReturnDropOffDate);
        txtCancellation5ReturnDropOffPoint = findViewById(R.id.txtCancellation5ReturnDropOffPoint);
        txtCancellation5ReturnDropOffLocation = findViewById(R.id.txtCancellation5ReturnDropOffLocation);
        txtCancellation5ReturnDropOffShuttleBus = findViewById(R.id.txtCancellation5ReturnDropOffShuttleBus);
        txtCancellation5DepartDropOffDate = findViewById(R.id.txtCancellation5DepartDropOffDate);
        llReturn=findViewById(R.id.llReturn);

        loadData();
        openDialog();
//        Intent intent = getIntent();
//        String cancelIncorrect = intent.getStringExtra("cancelIncorrect");
    }

    private void openDialog() {
        final Dialog dialog = new Dialog(Cancellation5Activity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_cancellation6_item);

        Window window = dialog.getWindow();
        if (window == null) {
            return;
        }

        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.copyFrom(window.getAttributes());
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        layoutParams.gravity = Gravity.BOTTOM;
        layoutParams.horizontalMargin = 0;

        window.setAttributes(layoutParams);

        dialog.setCancelable(true);

        Button btnCancellation6DialogBook = dialog.findViewById(R.id.btnCancellation6DialogBook);

        btnCancellation6DialogBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void loadData() {
        PaidTicket paidTicket = MySharedPreferences.getObject(getApplicationContext(),"cancelingTicket",PaidTicket.class);
        String id = paidTicket.get_id();

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String refundPercentage = sharedPreferences.getString("refundPercentage", "0");
        String refundFee = sharedPreferences.getString("refundFee", "0");

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.child("BookedTicket").child(id).addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                progressDialog.dismiss(); // Dismiss progressDialog after data loading is complete

                if (snapshot.exists()) {
                    String transactionNumber = snapshot.child("TransactionNumber").getValue(String.class);
                    Map<String, String> cancellationDetails = (Map<String, String>) snapshot.child("Cancellation").getValue();

                    if (transactionNumber != null && cancellationDetails != null) {


                        txtCancellation5TransactionNo.setText(transactionNumber.toString());
                        String cancellationReason = cancellationDetails.get("reason");
                        String timeOfCancel = cancellationDetails.get("timeOfCancel");

                        txtCancellation5TransactionNo.setText(transactionNumber);
                        txtCancellation5CancelTime.setText(timeOfCancel);
                        txtCancellation5Reason.setText(cancellationReason);

                        txtCancellation5CancelTotalPayment.setText(paidTicket.getTotalPayment());
                        txtCancellation5CancelFee.setText(refundFee);
                        txtCancellation5RefundAmount.setText(String.valueOf(Integer.parseInt(paidTicket.getTotalPayment()) - Integer.parseInt(refundFee)));

                        String departTitle = snapshot.child("departure").child("bus").getValue(String.class);
                        txtCancellation5DepartTitle.setText(departTitle);
                        String departPickUpTime = snapshot.child("departure").child("pickUpPoint").child("time").getValue(String.class);
                        txtCancellationDepartPickUpTime.setText(departPickUpTime);
                        String departPickUpDate = snapshot.child("departure").child("pickUpPoint").child("date").getValue(String.class);
                        txtCancellation5DepartPickUpDate.setText(departPickUpDate);
                        String departPickUpPoint = snapshot.child("departure").child("pickUpPoint").child("point").getValue(String.class);
                        txtCancellation5DepartPickUpPoint.setText(departPickUpPoint);
                        String departPickUpAddress = snapshot.child("departure").child("pickUpPoint").child("address").getValue(String.class);
                        txtCancellation5DepartPickUpLocation.setText(departPickUpAddress);

                        ArrayList<String> DSeats = new ArrayList<>();

                        for (DataSnapshot subData: snapshot.child("departure").child("seat").getChildren()) {
                            String seat = subData.getValue(String.class);
                            if (seat != null) {
                                DSeats.add(seat);
                            }
                        }

                        txtCancellation5DepartSeatNo.setText(DSeats.toString());

                        if (paidTicket.getReturn() == null) {
                            llReturn.setVisibility(View.GONE);
                        } else {
                            String returnTitle = snapshot.child("return").child("bus").getValue(String.class);
                            txtCancellation5ReturnTitle.setText(returnTitle);
                            String departReturnTime = snapshot.child("return").child("pickUpPoint").child("time").getValue(String.class);
                            txtCancellation5ReturnPickUpTime.setText(departReturnTime);
                            String departReturnDate = snapshot.child("return").child("pickUpPoint").child("time").getValue(String.class);
                            txtCancellation5ReturnPickUpDate.setText(departReturnDate);
                            String departReturnPoint = snapshot.child("return").child("pickUpPoint").child("point").getValue(String.class);
                            txtCancellation5ReturnPickUpPoint.setText(departReturnPoint);
                            String departReturnAddress = snapshot.child("return").child("pickUpPoint").child("address").getValue(String.class);
                            txtCancellation5ReturnPickUpLocation.setText(departReturnAddress);

                            String returnDropOffTime = snapshot.child("return").child("dropOffPoint").child("time").getValue(String.class);
                            txtCancellation5ReturnDropOffTime.setText(returnDropOffTime);
                            String returnDropOffDate = snapshot.child("return").child("dropOffPoint").child("time").getValue(String.class);
                            txtCancellation5ReturnDropOffDate.setText(returnDropOffDate);
                            String returnDropOffPoint = snapshot.child("return").child("dropOffPoint").child("point").getValue(String.class);
                            txtCancellation5ReturnDropOffPoint.setText(returnDropOffPoint);
                            String returnDropOffAddress = snapshot.child("return").child("dropOffPoint").child("address").getValue(String.class);
                            txtCancellation5ReturnDropOffLocation.setText(returnDropOffAddress);

                            ArrayList<String> RSeats = new ArrayList<>();

                            for (DataSnapshot subData: snapshot.child("return").child("seat").getChildren()) {
                                String seat = subData.getValue(String.class);
                                if (seat != null) {
                                    RSeats.add(seat);
                                }
                            }

                            txtCancellation5ReturnSeatNo.setText(RSeats.toString());
                        }






                    }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss(); // Dismiss progressDialog if data loading is cancelled


            }

        });
    }
}
//        ArrayList<CancelTicket> cancelTickets = new ArrayList<>();
//        myRef.child("BookedTicket").child("-NwASRIkAJewELKUkMSg").addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//
//            }




//                for (DataSnapshot data : dataSnapshot.getChildren()) {

//                    String transactionNumber = data.child("TransactionNumber").getValue(String.class);
//                    String totalDepartPayment = data.child("departure").child("totalPrice").getValue(String.class);
//                    String reason = data.child("reason").getValue(String.class);
//                    String cancelTime = data.child("cancelTime").getValue(String.class);
//                    String status = data.child("status").getValue(String.class);
//                    Intent intent = getIntent();
//                    String cancellationFee = intent.getStringExtra("cancellation_fee");
//                    String refundableAmount = intent.getStringExtra("refundable_amount");
//                    if (accountId.equals(accountId) && status != null && status.equals("Cancel")) {
//                        String departureBusType = data.child("departure").child("bus").getValue(String.class);
//                        String departurePickUpTime = data.child("departure").child("pickUpPoint").child("time").getValue(String.class);
//                        String departurePickUpDate = data.child("departure").child("pickUpPoint").child("time").getValue(String.class);
//                        String departurePickUpPoint = data.child("departure").child("pickUpPoint").child("point").getValue(String.class);
//                        String departurePickUpLocation = data.child("departure").child("pickUpPoint").child("address").getValue(String.class);
//
//                        String departureDropOffTime = data.child("departure").child("dropOffPoint").child("time").getValue(String.class);
//                        String departureDropOffDate = data.child("departure").child("dropOffPoint").child("time").getValue(String.class);
//                        String departureDropOffPoint = data.child("departure").child("dropOffPoint").child("point").getValue(String.class);
//                        String departureDropOffLocation = data.child("departure").child("dropOffPoint").child("address").getValue(String.class);
//
//
//                        String returnBusType = data.child("return").child("bus").getValue(String.class);
//                        String returnPickUpTime = data.child("return").child("pickUpPoint").child("time").getValue(String.class);
//                        String returnPickUpDate = data.child("return").child("pickUpPoint").child("time").getValue(String.class);
//                        String returnPickUpPoint = data.child("return").child("pickUpPoint").child("point").getValue(String.class);
//                        String returnPickUpLocation = data.child("return").child("pickUpPoint").child("address").getValue(String.class);
//
//                        String returnDropOffTime = data.child("return").child("dropOffPoint").child("time").getValue(String.class);
//                        String returnDropOffDate = data.child("return").child("dropOffPoint").child("time").getValue(String.class);
//                        String returnDropOffPoint = data.child("return").child("dropOffPoint").child("point").getValue(String.class);
//                        String returnDropOffLocation = data.child("return").child("dropOffPoint").child("address").getValue(String.class);
//
//                        // Retrieve seat values from Firebase
//                        DatabaseReference seatsRef = database.getReference("seats");
//                        seatsRef.addListenerForSingleValueEvent(new ValueEventListener() {
//                            @Override
//                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                                StringBuilder resultBuilder = new StringBuilder();
//
//                                for (DataSnapshot seatSnapshot : dataSnapshot.getChildren()) {
//                                    String seat = seatSnapshot.getValue(String.class);
//
//                                    // Append the seat value to the resultBuilder
//                                    if (seat != null) {
//                                        if (resultBuilder.length() > 0) {
//                                            resultBuilder.append(", ");
//                                        }
//                                        resultBuilder.append(seat);
//                                    }
//                                }
//
//                                String result = resultBuilder.toString();
//                                // Now you have the concatenated result: "4A, 4B"
//                                // You can use this result as needed in your application
//                                Log.d("FirebaseResult", "Result: " + result);
//
//
//                                // Now, you can use the 'result' variable here, where you need the seat values.
//                                // For example, you can display it in a TextView or use it for any other purpose.
//                                txtCancellation5Reason.setText(reason);
//                                txtCancellation5TransactionNo.setText(transactionNumber);
//                                txtCancellation5CancelTime.setText(cancelTime);
//                                txtCancellation5CancelTotalPayment.setText(totalDepartPayment);
//                                txtCancellation5CancelFee.setText(cancellationFee);
//                                txtCancellation5RefundAmount.setText(refundableAmount);
//                                txtCancellation5DepartTitle.setText(departureBusType);
//                                txtCancellationDepartPickUpTime.setText(departurePickUpTime);
//                                txtCancellation5DepartPickUpDate.setText(departurePickUpDate);
//                                txtCancellation5DepartPickUpPoint.setText(departurePickUpPoint);
//                                txtCancellation5DepartPickUpLocation.setText(departurePickUpLocation);
//                                txtCancellation5DepartDropOffTime.setText(departureDropOffTime);
//                                txtCancellation5DepartDropOffDate.setText(departureDropOffDate);
//                                txtCancellation5DepartDropOffPoint.setText(departureDropOffPoint);
//                                txtCancellation5DepartDropOffLocation.setText(departureDropOffLocation);
//                                txtCancellation5ReturnTitle.setText(returnBusType);
//                                txtCancellation5ReturnPickUpTime.setText(returnPickUpTime);
//                                txtCancellation5ReturnPickUpDate.setText(returnPickUpDate);
//                                txtCancellation5ReturnPickUpPoint.setText(returnPickUpPoint);
//                                txtCancellation5ReturnPickUpLocation.setText(returnPickUpLocation);
//                                txtCancellation5ReturnDropOffTime.setText(returnDropOffTime);
//                                txtCancellation5ReturnDropOffDate.setText(returnDropOffDate);
//                                txtCancellation5ReturnDropOffPoint.setText(returnDropOffPoint);
//                                txtCancellation5ReturnDropOffLocation.setText(returnDropOffLocation);
//                            }
//
//                            @Override
//                            public void onCancelled(@NonNull DatabaseError databaseError) {
//                                // Handle errors
//                            }
//                        });
//
//
//                    }

//                }
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                Log.e(TAG, "loadPost:onCancelled", databaseError.toException());
//            }
//        });
//    }



//    private void loadData() {
//        FirebaseDatabase database = FirebaseDatabase.getInstance();
//        DatabaseReference myRef = database.getReference("CancelReason");
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                for (DataSnapshot data: dataSnapshot.getChildren()) {
//                    String cancel5Id=data.getKey();
//                    String cancel5Description = data.child("Description").getValue(String.class);
//                    CancelReason cancelReason = new CancelReason();
//                    cancelReason.setCancelId(cancel5Id);
//                    cancelReason.setCancelDescription(cancel5Description);
//                }
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                Log.w(TAG, "loadPost:onCancelled", databaseError.toException());
//            }
//        });
