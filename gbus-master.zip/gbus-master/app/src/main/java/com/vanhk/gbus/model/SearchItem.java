package com.vanhk.gbus.model;

import java.io.Serializable;

public class SearchItem implements Serializable {
    private String DLocation;
    private String ALocation;
    private String DDate;

    public String getDLocation() {
        return DLocation;
    }

    public void setDLocation(String DLocation) {
        this.DLocation = DLocation;
    }

    public String getALocation() {
        return ALocation;
    }

    public void setALocation(String ALocation) {
        this.ALocation = ALocation;
    }

    public String getDDate() {
        return DDate;
    }

    public void setDDate(String DDate) {
        this.DDate = DDate;
    }

    public String getRDate() {
        return RDate;
    }

    public void setRDate(String RDate) {
        this.RDate = RDate;
    }

    public SearchItem() {
    }

    public SearchItem(String DLocation, String ALocation, String DDate, String RDate) {
        this.DLocation = DLocation;
        this.ALocation = ALocation;
        this.DDate = DDate;
        this.RDate = RDate;
    }

    private String RDate;

    @Override
    public String toString() {
        return  DLocation + "," + ALocation + "," + DDate + "," + RDate;
    }
}
