package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.Ticket;

import java.util.ArrayList;

public class ChooseSeat_ReturnActivity extends AppCompatActivity implements View.OnClickListener {

    private ArrayList<Button> seatButtons = new ArrayList<>();
    private ArrayList<SeatInfo> seatInfoList = new ArrayList<>();
    private ArrayList<String> selectedSeats = new ArrayList<>();
    private int totalPrice = 0;
    private Ticket selectedTicket;
    private ProgressDialog progressDialog; // ProgressDialog instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_seat_depart1);

        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.show(); // Show ProgressDialog

        addViews();
        setupClickListeners();
        initializeSeatInfo();
        updateTotalPrice();

        Button btnBookTickets = findViewById(R.id.btnChooseSeatDepart1Book);
        btnBookTickets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bookTickets();
            }
        });

        progressDialog.dismiss(); // Dismiss ProgressDialog after initializing views and data
    }

    private void bookTickets() {
        if (selectedTicket == null) {
            return;
        }
        MySharedPreferences.saveObject(this, "DSeats", selectedSeats);
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("RTotalPrice", String.valueOf(totalPrice));
        editor.apply();

        Intent intent = new Intent(this, PickupDeparture1Activity.class);
        intent.putExtra("totalPrice", totalPrice);
        intent.putExtra("ticket", selectedTicket);
        startActivity(intent);
        finish();
    }

    private void initializeSeatInfo() {
        if (selectedTicket == null) {
            return;
        }
        for (int i = 0; i < seatButtons.size(); i++) {
            seatInfoList.add(new SeatInfo(i + 1, true, selectedTicket.getPrice()));
        }
    }

    private void updateTotalPrice() {
        totalPrice = 0;
        for (SeatInfo seatInfo : seatInfoList) {
            if (!seatInfo.isAvailable()) {
                totalPrice += seatInfo.getPrice();
            }
        }
        TextView txtChooseSeatDepart1Price = findViewById(R.id.txtChooseSeatDepart1Price);
        txtChooseSeatDepart1Price.setText(String.format("%,d VND", totalPrice));
    }

    private void setupClickListeners() {
        for (Button button : seatButtons) {
            button.setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View v) {
        int seatIndex = seatButtons.indexOf(v);
        if (seatIndex != -1) {
            SeatInfo seatInfo = seatInfoList.get(seatIndex);
            if (seatInfo.isAvailable()) {
                seatInfo.setAvailable(false);
                v.setBackground(ContextCompat.getDrawable(this, R.drawable.ic_seatselected));
                selectedSeats.add(seatButtons.get(seatIndex).getText().toString());
            } else {
                seatInfo.setAvailable(true);
                v.setBackground(ContextCompat.getDrawable(this, R.drawable.ic_seatavailable));
                selectedSeats.remove(seatButtons.get(seatIndex).getText().toString());
            }
            updateTotalPrice();
        }
    }

    private void addViews() {
        // Add buttons for each seat
        seatButtons.add((Button) findViewById(R.id.btnChooseSeatDepart1Enable1A));
        seatButtons.add((Button) findViewById(R.id.btn1b));
        seatButtons.add((Button) findViewById(R.id.btn1c));
        seatButtons.add((Button) findViewById(R.id.btnChooseSeatDepart1Enable1D));
        seatButtons.add((Button) findViewById(R.id.btn2a));
        seatButtons.add((Button) findViewById(R.id.btnChooseSeatDepart1Enable2B));
        seatButtons.add((Button) findViewById(R.id.btn2c));
        seatButtons.add((Button) findViewById(R.id.btn2d));
        seatButtons.add((Button) findViewById(R.id.btn3a));
        seatButtons.add((Button) findViewById(R.id.btnChooseSeatDepart1Enable3B));
        seatButtons.add((Button) findViewById(R.id.btnChooseSeatDepart1Enable3C));
        seatButtons.add((Button) findViewById(R.id.btn3d));
        seatButtons.add((Button) findViewById(R.id.btnChooseSeatDepart1Enable4A));
        seatButtons.add((Button) findViewById(R.id.btnChooseSeatDepart1Enable4B));
        seatButtons.add((Button) findViewById(R.id.btnChooseSeatDepart1Enable4C));
        seatButtons.add((Button) findViewById(R.id.btn4d));
        seatButtons.add((Button) findViewById(R.id.btn5a));
        seatButtons.add((Button) findViewById(R.id.btn5b));
        seatButtons.add((Button) findViewById(R.id.btn5c));
        seatButtons.add((Button) findViewById(R.id.btn5d));

        Intent intent = getIntent();
        selectedTicket = (Ticket) intent.getSerializableExtra("ticket");

        assert selectedTicket != null;
        ArrayList<String> seats = selectedTicket.getSeat();

        for (int i = 0; i < seatButtons.size(); i++) {
            String seatCode = seatButtons.get(i).getText().toString();

            GradientDrawable drawable = new GradientDrawable();
            drawable.setCornerRadius(8);
            drawable.setColor(Color.parseColor("#E2E4E7"));

            boolean isSeatExist = seats.contains(seatCode);
            if (isSeatExist) {
                seatButtons.get(i).setTextColor(Color.BLACK);
                seatButtons.get(i).setBackground(drawable);
                seatButtons.get(i).setEnabled(false);
            } else {
                seatButtons.get(i).setTextColor(Color.parseColor("#4D56BE"));
                seatButtons.get(i).setBackgroundResource(R.drawable.button_outline);
                seatButtons.get(i).setEnabled(true);
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, TripDetails1Activity.class);
        startActivity(intent);
        finish();
    }

    private static class SeatInfo {
        private int seatNumber;
        private boolean available;
        private int price;

        SeatInfo(int seatNumber, boolean available, int price) {
            this.seatNumber = seatNumber;
            this.available = available;
            this.price = price;
        }

        int getSeatNumber() {
            return seatNumber;
        }

        boolean isAvailable() {
            return available;
        }

        void setAvailable(boolean available) {
            this.available = available;
        }

        int getPrice() {
            return price;
        }
    }
}
