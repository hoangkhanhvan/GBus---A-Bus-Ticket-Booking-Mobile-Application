package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.google.android.material.slider.LabelFormatter;
import com.google.android.material.slider.RangeSlider;

import java.text.NumberFormat;
import java.util.Currency;

public class ResultList2Activity extends AppCompatActivity {
    ImageView imgResultList2Close;

    LinearLayout layoutResultList2EarlyMorning,layoutResultList2Morning
            ,layoutResultList2Afternoon,layoutResultList2Evening;

    TextView txtResultList1PriceStart,txtResultList1End,txtResultList2SeatAvailability;

    Button btnResultList21Star,btnResultList22Star,btnResultList23Star
            ,btnResultList24Star,btnResultList25Star,btnResultList2Remove,btnResultList2Save;

    CheckBox chkResultList2Seat,chkResultList2SleeperSeat,chkResultList2CoupleSleeper
            ,chkResultList2FrontRow;

    Switch switchResultList2Promotion,switchResultListImmediate,switchResultList2Limousine;

    ImageButton imgResultList2Minus,imgResultList2Plus;
    RangeSlider rsPriceRange;

    ProgressDialog progressDialog; // Declare ProgressDialog variable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_list2);
        addViews();
        addEvents();

        // Initialize the progressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable
    }

    private void addEvents() {
        imgResultList2Close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultList2Activity.this, ResultList1Activity.class);
                startActivity(intent);
            }
        });

        // Adding listener to RangeSlider
//        rsPriceRange.addOnSliderTouchListener(new RangeSlider.OnSliderTouchListener() {
//            @Override
//            public void onStartTrackingTouch(RangeSlider slider) {
//                // Responds to when slider's touch event is being started
//            }
//
//            @Override
//            public void onStopTrackingTouch(RangeSlider slider) {
//                // Responds to when slider's touch event is being stopped
//            }
//        });

//        rsPriceRange.addOnChangeListener(new RangeSlider.OnChangeListener() {
//            @Override
//            public void onValueChange(RangeSlider slider, float value, boolean fromUser) {
//                // Responds to when slider's value changes
//            }
//        });
//        rsPriceRange.setLabelFormatter(new LabelFormatter() {
//            @Override
//            public String getFormattedValue(float value) {
//                NumberFormat format = NumberFormat.getCurrencyInstance();
//                format.setMaximumFractionDigits(0);  // Sets the number of digits after the decimal
//                format.setCurrency(Currency.getInstance("VND"));
//                return format.format(value);
//            }
//        });

    }

    private void addViews() {
        imgResultList2Close=findViewById(R.id.imgResultList2Close);
        layoutResultList2EarlyMorning=findViewById(R.id.layoutResultList2EarlyMorning);
        layoutResultList2Morning=findViewById(R.id.layoutResultList2Morning);
        layoutResultList2Afternoon=findViewById(R.id.layoutResultList2Afternoon);
        layoutResultList2Evening=findViewById(R.id.layoutResultList2Evening);
        txtResultList1PriceStart=findViewById(R.id.txtResultList1PriceStart);
        txtResultList1End=findViewById(R.id.txtResultList1End);
        btnResultList21Star=findViewById(R.id.btnResultList21Star);
        btnResultList22Star=findViewById(R.id.btnResultList22Star);
        btnResultList23Star=findViewById(R.id.btnResultList23Star);
        btnResultList24Star=findViewById(R.id.btnResultList24Star);
        btnResultList25Star=findViewById(R.id.btnResultList25Star);
        chkResultList2Seat=findViewById(R.id.chkResultList2Seat);
        chkResultList2SleeperSeat=findViewById(R.id.chkResultList2SleeperSeat);
        chkResultList2CoupleSleeper=findViewById(R.id.chkResultList2CoupleSleeper);
        imgResultList2Minus=findViewById(R.id.imgResultList2Minus);
        imgResultList2Plus=findViewById(R.id.imgResultList2Plus);
        txtResultList2SeatAvailability=findViewById(R.id.txtResultList2SeatAvailability);
        chkResultList2FrontRow=findViewById(R.id.chkResultList2FrontRow);
        switchResultList2Promotion=findViewById(R.id.switchResultList2Promotion);
        switchResultListImmediate=findViewById(R.id.switchResultListImmediate);
        switchResultList2Limousine=findViewById(R.id.switchResultList2Limousine);
        btnResultList2Remove=findViewById(R.id.btnResultList2Remove);
        btnResultList2Save=findViewById(R.id.btnResultList2Save);
        // rsPriceRange=findViewById(R.id.rsPriceRange);
    }
}
