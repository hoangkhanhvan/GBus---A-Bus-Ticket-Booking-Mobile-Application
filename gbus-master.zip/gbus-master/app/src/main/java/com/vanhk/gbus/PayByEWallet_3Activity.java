package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PayByEWallet_3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_by_ewallet3);
    }
}