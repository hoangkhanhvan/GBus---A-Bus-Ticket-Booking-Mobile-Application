package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.model.CompleteTiket;

import java.util.Locale;

public class ViewInvoice_CompleteActivity extends AppCompatActivity {
    TextView txtViewInvoiceCompleteCompleteTime, txtViewInvoiceCompleteTag,
            txtViewInvoiceCompleteName, txtViewInvoiceCompletePhoneNumber, txtViewInvoiceCompleteEmail,
            txtViewInvoiceCompleteTimestamp, txtViewInvoiceCompleteTransactionNo, txtViewInvoiceCompleteTrip, txtViewInvoiceCompleteState,
            txtViewInvoiceCompleteBusType, txtViewInvoiceCompleteQuantity, txtViewInvoiceCompleteDepartSeat, txtViewInvoiceCompleteReturnSeat,
            txtViewInvoiceCompleteDepartPickUpLocation, txtViewInvoiceCompleteDepartPickUpDescription, txtViewInvoiceCompleteDepartDropOffLocation,
            txtViewInvoiceCompleteDepartDropOffDescription, txtViewInvoiceCompleteReturnPickUpLocation, txtViewInvoiceCompleteReturnPickUpDescription,
            txtViewInvoiceCompleteReturnDropOffLocation, txtViewInvoiceCompleteReturnDropOffDescription, txtViewInvoiceCompleteSubtotal,
            txtViewInvoiceCompleteDiscount, txtSubtotal, txtViewInvoiceCompleteTotal;
    Button btnViewInvoiceCompleteViewInvoice, btnViewInvoiceCompleteBackToHomepage;
    ImageView imgViewInvoiceCompleteBack;
    String bookedTicketId = "";


    // Declare ProgressDialog variable
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_invoice_complete);
        addViews();
        addEvents();

        // Initialize the ProgressDialog

    }

    private void addEvents() {
        btnViewInvoiceCompleteViewInvoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ViewInvoice_CompleteActivity.this, Rating_3Activity.class);
                startActivity(intent);

            }
        });
        btnViewInvoiceCompleteBackToHomepage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ViewInvoice_CompleteActivity.this,HomepageActivity.class);
                startActivity(intent);
            }
        });

        imgViewInvoiceCompleteBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ViewInvoice_CompleteActivity.this,HomepageActivity.class);
                startActivity(intent);
            }
        });


    }

    private void addViews() {
        txtViewInvoiceCompleteCompleteTime = findViewById(R.id.txtViewInvoiceCompleteCompleteTime);
        txtViewInvoiceCompleteTag = findViewById(R.id.txtViewInvoiceCompleteTag);
        txtViewInvoiceCompleteName = findViewById(R.id.txtViewInvoiceCompleteName);
        txtViewInvoiceCompletePhoneNumber = findViewById(R.id.txtViewInvoiceCompletePhoneNumber);
        txtViewInvoiceCompleteEmail = findViewById(R.id.txtViewInvoiceCompleteEmail);
        txtViewInvoiceCompleteTimestamp = findViewById(R.id.txtViewInvoiceCompleteTimestamp);
        txtViewInvoiceCompleteTransactionNo = findViewById(R.id.txtViewInvoiceCompleteTransactionNo);
        txtViewInvoiceCompleteTrip = findViewById(R.id.txtViewInvoiceCompleteTrip);
        txtViewInvoiceCompleteState = findViewById(R.id.txtViewInvoiceCompleteState);
        txtViewInvoiceCompleteBusType = findViewById(R.id.txtViewInvoiceCompleteBusType);
        txtViewInvoiceCompleteQuantity = findViewById(R.id.txtViewInvoiceCompleteQuantity);
        txtViewInvoiceCompleteDepartSeat = findViewById(R.id.txtViewInvoiceCompleteDepartSeat);
        txtViewInvoiceCompleteReturnSeat = findViewById(R.id.txtViewInvoiceCompleteReturnSeat);
        txtViewInvoiceCompleteDepartPickUpLocation = findViewById(R.id.txtViewInvoiceCompleteDepartPickUpLocation);
        txtViewInvoiceCompleteDepartPickUpDescription = findViewById(R.id.txtViewInvoiceCompleteDepartPickUpDescription);
        txtViewInvoiceCompleteDepartDropOffLocation = findViewById(R.id.txtViewInvoiceCompleteDepartDropOffLocation);
        txtViewInvoiceCompleteDepartDropOffDescription = findViewById(R.id.txtViewInvoiceCompleteDepartDropOffDescription);
        txtViewInvoiceCompleteReturnPickUpLocation = findViewById(R.id.txtViewInvoiceCompleteReturnPickUpLocation);
        txtViewInvoiceCompleteReturnPickUpDescription = findViewById(R.id.txtViewInvoiceCompleteReturnPickUpDescription);
        txtViewInvoiceCompleteReturnDropOffLocation = findViewById(R.id.txtViewInvoiceCompleteReturnDropOffLocation);
        txtViewInvoiceCompleteReturnDropOffDescription = findViewById(R.id.txtViewInvoiceCompleteReturnDropOffDescription);
        txtViewInvoiceCompleteSubtotal = findViewById(R.id.txtViewInvoiceCompleteSubtotal);
        txtViewInvoiceCompleteDiscount = findViewById(R.id.txtViewInvoiceCompleteDiscount);
        txtSubtotal = findViewById(R.id.txtSubtotal);
        txtViewInvoiceCompleteTotal = findViewById(R.id.txtViewInvoiceCompleteTotal);
        btnViewInvoiceCompleteViewInvoice = findViewById(R.id.btnViewInvoiceCompleteViewInvoice);
        btnViewInvoiceCompleteBackToHomepage = findViewById(R.id.btnViewInvoiceCompleteBackToHomepage);
        imgViewInvoiceCompleteBack = findViewById(R.id.imgViewInvoiceCompleteBack);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        bookedTicketId = sharedPreferences.getString("BookedTicketId", "");
        loadData();
    }

    private void loadData() {
        // Show the ProgressDialog
        progressDialog.show();
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        myRef.child("BookedTicket").child(bookedTicketId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                CompleteTiket completeTiket = snapshot.getValue(CompleteTiket.class);
                if (completeTiket != null && completeTiket.getPassenger() != null) {
                    txtViewInvoiceCompleteName.setText(completeTiket.getPassenger().getName());
                    txtViewInvoiceCompletePhoneNumber.setText(completeTiket.getPassenger().getPhoneNumber());
                    txtViewInvoiceCompleteEmail.setText(completeTiket.getPassenger().getEmail());

                }
                if (completeTiket != null) {
                    txtViewInvoiceCompleteTag.setText(completeTiket.getStatus());
                    txtViewInvoiceCompleteTimestamp.setText(completeTiket.getBookedTime());
                    txtViewInvoiceCompleteCompleteTime.setText(completeTiket.getCompletedTime());
                }

                if (snapshot.exists()) {
                    String transactionno = snapshot.child("TransactionNumber").getValue(String.class);
                    if (transactionno != null) {
                        txtViewInvoiceCompleteTransactionNo.setText(transactionno.toString());
                    }
                }

                if (completeTiket != null && completeTiket.getDeparture() != null) {
                    txtViewInvoiceCompleteTrip.setText(completeTiket.getDeparture().getDlocation() + " - " + completeTiket.getDeparture().getAlocation());
                    txtViewInvoiceCompleteBusType.setText(completeTiket.getDeparture().getBus());
                }
                // Dismiss the ProgressDialog when data loading is complete
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                // Dismiss the ProgressDialog if loading is canceled or fails
                progressDialog.dismiss();
            }
        });

        DatabaseReference myRef1 = database.getReference();
        myRef1.child("BookedTicket").child(bookedTicketId).child("departure").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String seatLocation1 = snapshot.child("seat").child("0").getValue(String.class);
                    String seatLocation2 = snapshot.child("seat").child("1").getValue(String.class);
                    if (seatLocation1 != null && seatLocation2 != null) {
                        String aSeat = seatLocation1 + ", " + seatLocation2 + " (Departure Trip)";
                        txtViewInvoiceCompleteDepartSeat.setText(aSeat);
                        Log.d("seat", "Combined seat: " + aSeat);
                    }
                } else {
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        DatabaseReference myRef2 = database.getReference();
        myRef2.child("BookedTicket").child(bookedTicketId).child("return").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String seatLocation1 = snapshot.child("seat").child("0").getValue(String.class);
                    String seatLocation2 = snapshot.child("seat").child("1").getValue(String.class);
                    if (seatLocation1 != null && seatLocation2 != null) {
                        String aSeat = seatLocation1 + ", " + seatLocation2 + " (Return Trip)";
                        txtViewInvoiceCompleteReturnSeat.setText(aSeat);
                        Log.d("seat", "Combined seat: " + aSeat);
                    }
                } else {
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        DatabaseReference myRef4 = database.getReference();
        myRef4.child("BookedTicket").child(bookedTicketId).child("departure").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String point = snapshot.child("pickUpPoint").child("point").getValue(String.class);
                    String address = snapshot.child("pickUpPoint").child("address").getValue(String.class);
                    String dateStr = snapshot.child("pickUpPoint").child("dateStr").getValue(String.class);
                    String time = snapshot.child("pickUpPoint").child("time").getValue(String.class);

                    String point1 = snapshot.child("dropOffPoint").child("point").getValue(String.class);
                    String address1 = snapshot.child("dropOffPoint").child("address").getValue(String.class);
                    String dateStr1 = snapshot.child("dropOffPoint").child("dateStr").getValue(String.class);
                    String time1 = snapshot.child("dropOffPoint").child("time").getValue(String.class);


                    if (point != null && address != null && dateStr != null && time != null && point1 != null && address1 != null && dateStr1 != null && time1 != null) {
                        txtViewInvoiceCompleteDepartPickUpLocation.setText(point.toString());
                        txtViewInvoiceCompleteDepartPickUpDescription.setText(address.toString());

                        txtViewInvoiceCompleteDepartDropOffLocation.setText(point1.toString());
                        txtViewInvoiceCompleteDepartDropOffDescription.setText(address1.toString());

                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        DatabaseReference myRef5 = database.getReference();
        myRef5.child("BookedTicket").child(bookedTicketId).child("return").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String point = snapshot.child("pickUpPoint").child("point").getValue(String.class);
                    String address = snapshot.child("pickUpPoint").child("address").getValue(String.class);
                    String dateStr = snapshot.child("pickUpPoint").child("dateStr").getValue(String.class);
                    String time = snapshot.child("pickUpPoint").child("time").getValue(String.class);

                    String point1 = snapshot.child("dropOffPoint").child("point").getValue(String.class);
                    String address1 = snapshot.child("dropOffPoint").child("address").getValue(String.class);
                    String dateStr1 = snapshot.child("dropOffPoint").child("dateStr").getValue(String.class);
                    String time1 = snapshot.child("dropOffPoint").child("time").getValue(String.class);


                    if (point != null && address != null && dateStr != null && time != null && point1 != null && address1 != null && dateStr1 != null && time1 != null) {
                        txtViewInvoiceCompleteReturnPickUpLocation.setText(point.toString());
                        txtViewInvoiceCompleteReturnPickUpDescription.setText(address.toString());

                        txtViewInvoiceCompleteReturnDropOffLocation.setText(point1.toString());
                        txtViewInvoiceCompleteReturnDropOffDescription.setText(address1.toString());

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        DatabaseReference myRef6 = database.getReference();
        myRef6.child("BookedTicket").child(bookedTicketId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) ;
                {
                    DataSnapshot departureSeatsSnapshot = snapshot.child("departure").child("seat");
                    DataSnapshot returnSeatsSnapshot = snapshot.child("return").child("seat");
                    int totalSeats = 0;
                    totalSeats += departureSeatsSnapshot.getChildrenCount();
                    totalSeats += returnSeatsSnapshot.getChildrenCount();

                    String totalSeat = totalSeats + " Tickets";
                    txtViewInvoiceCompleteQuantity.setText(totalSeat);

                    String totalSeat1 = "Subtotal (" + totalSeats + " Tickets)";
                    txtSubtotal.setText(totalSeat1);


                    long totalPriceDeparture = snapshot.child("departure").child("totalPrice").getValue(Long.class);
                    long totalPriceReturn = snapshot.child("return").child("totalPrice").getValue(Long.class);
                    long subtotal = totalPriceDeparture + totalPriceReturn;
                    String formattedSubtotal = String.format(Locale.getDefault(), "%,d VND", subtotal);
                    txtViewInvoiceCompleteSubtotal.setText(formattedSubtotal);

                    DatabaseReference myRef7 = database.getReference();
                    myRef7.child("Vouchers").child("0").addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                String percentageString = snapshot.child("percentage").getValue(String.class).replace("%", "");
                                int percentage = Integer.parseInt(percentageString);
                                int discount = (int) (subtotal * percentage / 100.0);

                                String formattedDiscount = String.format(Locale.getDefault(), "%,d VND", discount);
                                txtViewInvoiceCompleteDiscount.setText(formattedDiscount);

                                double totalAfterDiscount = subtotal - discount;
                                String formattedTotal = String.format(Locale.getDefault(), "%,d VND", (int) totalAfterDiscount);
                                txtViewInvoiceCompleteTotal.setText(formattedTotal);
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }

        });
    }
}