    package com.vanhk.gbus;


    import androidx.annotation.NonNull;
    import androidx.appcompat.app.AppCompatActivity;


    import android.app.ProgressDialog;
    import android.content.Context;
    import android.content.Intent;
    import android.content.SharedPreferences;
    import android.graphics.Bitmap;
    import android.graphics.BitmapFactory;
    import android.os.Bundle;
    import android.util.Base64;
    import android.util.Log;
    import android.view.View;
    import android.widget.Button;
    import android.widget.ImageView;
    import android.widget.LinearLayout;
    import android.widget.ListView;
    import android.widget.ProgressBar;
    import android.widget.TextView;


    import com.google.firebase.database.DataSnapshot;
    import com.google.firebase.database.DatabaseError;
    import com.google.firebase.database.DatabaseReference;
    import com.google.firebase.database.FirebaseDatabase;
    import com.google.firebase.database.ValueEventListener;
    import com.vanhk.gbus.adapter.TripDetail3Adapter;
    import com.vanhk.gbus.model.MySharedPreferences;
    import com.vanhk.gbus.model.Ticket;
    import com.vanhk.gbus.model.TripDetail3;


    import java.util.ArrayList;


    public class TripDetails3Activity extends AppCompatActivity {
        TextView txtTripDetail3DepartLocation, txtTripDetail3ArrivalLocation,
                txtTripdetails3Tag, txtTripDetails3DepartDate,
                txtTripDetails3PcikupDropoff, txtTripDetails3Amenities, txtTripDetails3BusFeatures,
                txtTripDetails3RatingNumber, TripDetails3RatingAmount,
                txtTripDetails3Criteria1, txtTripDetails3Criteria2, txtTripDetails3Criteria3,
                txtTripDetails3Criteria4, txtTripDetails3Criteria5, txtTripDetails3Criteria6;
        ImageView TripDetails3Close;
        ImageView imgDetailTrip3Star;
        LinearLayout layoutTripDetails3Reviews;
        ListView lvTripDetails3;
        Button btnTripDetails3Book;
        String TAG = "FIREBASE";
        TripDetail3Adapter tripDetail3Adapter;
        ArrayList<TripDetail3> tripDetail3List;
        Ticket selectedTicket;
        ArrayList<String> FullInformation = new ArrayList<>();
        ArrayList<String> VerifiedInformation = new ArrayList<>();
        ArrayList<String> ConvenienceComfort = new ArrayList<>();
        ArrayList<String> Safety = new ArrayList<>();
        ArrayList<String> ServiceQuality = new ArrayList<>();
        ArrayList<String> EmployeesAttitudes = new ArrayList<>();
        ArrayList<String> Tags = new ArrayList<>();

        // Declare ProgressDialog variable
        ProgressDialog progressDialog;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_trip_details3);
            addViews();
            addEvents();

            // Initialize the progressDialog
            progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Loading..."); // Set message for the ProgressDialog
            progressDialog.setCancelable(false); // Make it not cancelable
        }


        private void addEvents() {
            TripDetails3Close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(TripDetails3Activity.this,ResultList1Activity.class);
                    startActivity(intent);
                }
            });

    //        Cái này cần loadData
            btnTripDetails3Book.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Show the ProgressDialog when "Book" button is clicked
                    progressDialog.show();

                    Intent getIntent = getIntent();
                    String accountId = getIntent.getStringExtra("accountId");

                    Intent intent = new Intent(TripDetails3Activity.this, ChooseSeat_Depart_1Activity.class);

                    SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("departureTicketId", selectedTicket.get_id());
                    editor.apply();

                    ArrayList<String> search = getIntent.getStringArrayListExtra("search");

                    intent.putExtra("ticket",selectedTicket);
                    intent.putStringArrayListExtra("search",search);
                    MySharedPreferences.saveObject(TripDetails3Activity.this, "DTicket", selectedTicket);
                    boolean isReturn = sharedPreferences.getBoolean("isReturn",false);
                    if (isReturn) {
                        MySharedPreferences.saveObject(TripDetails3Activity.this, "RTicket", selectedTicket);

                    } else {
                        MySharedPreferences.saveObject(TripDetails3Activity.this, "DTicket", selectedTicket);

                    }

                    startActivity(intent);
                    // Dismiss the ProgressDialog after starting the new activity
                    progressDialog.dismiss();
                }
            });


            txtTripDetails3Amenities.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(TripDetails3Activity.this,TripDetails4Activity.class);
                    startActivity(intent);
                }
            });


            txtTripDetails3BusFeatures.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(TripDetails3Activity.this,TripDetails5Activity.class);
                    startActivity(intent);
                }
            });



            txtTripDetails3PcikupDropoff.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getApplicationContext(), TripDetails1Activity.class);
                    startActivity(intent);
                }
            });




        }


        private void addViews() {
            txtTripDetail3DepartLocation=findViewById(R.id.txtTripDetail3DepartLocation);
            txtTripDetail3ArrivalLocation=findViewById(R.id.txtTripDetail3ArrivalLocation);
            txtTripdetails3Tag=findViewById(R.id.txtTripdetails3Tag);
            txtTripDetails3DepartDate=findViewById(R.id.txtTripDetails3DepartDate);
            txtTripDetails3PcikupDropoff=findViewById(R.id.txtTripDetails3PcikupDropoff);
            txtTripDetails3Amenities=findViewById(R.id.txtTripDetails3Amenities);
            txtTripDetails3BusFeatures=findViewById(R.id.txtTripDetails3BusFeatures);
            txtTripDetails3RatingNumber=findViewById(R.id.txtTripDetails3RatingNumber);
            TripDetails3RatingAmount=findViewById(R.id.TripDetails3RatingAmount);
            txtTripDetails3Criteria1=findViewById(R.id.txtTripDetails3Criteria1);
            txtTripDetails3Criteria2=findViewById(R.id.txtTripDetails3Criteria2);
            txtTripDetails3Criteria3=findViewById(R.id.txtTripDetails3Criteria3);
            txtTripDetails3Criteria4=findViewById(R.id.txtTripDetails3Criteria4);
            txtTripDetails3Criteria5=findViewById(R.id.txtTripDetails3Criteria5);
            txtTripDetails3Criteria6=findViewById(R.id.txtTripDetails3Criteria6);
            imgDetailTrip3Star=findViewById(R.id.imgDetailTrip3Star);
            layoutTripDetails3Reviews=findViewById(R.id.layoutTripDetails3Reviews);
            lvTripDetails3=findViewById(R.id.lvTripDetails3);
            btnTripDetails3Book=findViewById(R.id.btnTripDetails3Book);
            TripDetails3Close=findViewById(R.id.TripDetails3Close);


            tripDetail3List = new ArrayList<>();

            tripDetail3Adapter = new TripDetail3Adapter(TripDetails3Activity.this, R.layout.lvtripdetails3reviews);
            lvTripDetails3.setAdapter(tripDetail3Adapter);
            loadData();
        }

        private void loadProgress() {
            int tagsSize = Tags.size();

            if (tagsSize != 0) {
                ProgressBar pbFullInformation = findViewById(R.id.pbBookingPreview1);
                pbFullInformation.setProgress((int) (((double) FullInformation.size() / tagsSize) * 100));

                ProgressBar pbConvenienceComfort = findViewById(R.id.pbBookingPreview2);
                pbConvenienceComfort.setProgress((int) (((double) ConvenienceComfort.size() / tagsSize) * 100));

                ProgressBar pbServiceQuality = findViewById(R.id.pbBookingPreview3);
                pbServiceQuality.setProgress((int) (((double) ServiceQuality.size() / tagsSize) * 100));

                ProgressBar pbVerifiedInformation = findViewById(R.id.pbBookingPreview4);
                pbVerifiedInformation.setProgress((int) (((double) VerifiedInformation.size() / tagsSize) * 100));

                ProgressBar pbSafety = findViewById(R.id.pbBookingPreview5);
                pbSafety.setProgress((int) (((double) Safety.size() / tagsSize) * 100));

                ProgressBar pbEmployeeAttitudes = findViewById(R.id.progressBar);
                pbEmployeeAttitudes.setProgress((int) (((double) EmployeesAttitudes.size() / tagsSize) * 100));
            }
        }



        private void loadData() {
            selectedTicket = MySharedPreferences.getObject(TripDetails3Activity.this,"SelectedTicket",Ticket.class);

            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            String RouteId = sharedPreferences.getString("RouteId","");

            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("Feedback");
            ArrayList<String> FeedbackList = new ArrayList<>();
            FeedbackList = selectedTicket.getReviews();





            ArrayList<String> finalFeedbackList = FeedbackList;
            myRef.addValueEventListener(new ValueEventListener() {

                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot data : dataSnapshot.getChildren()) {
                        String _id = data.child("_id").getValue(String.class);
                        for (int i = 0; i < finalFeedbackList.size(); i++) {
                            if (_id.equals(finalFeedbackList.get(i))) {
                                Long destination = data.child("Destination").getValue(Long.class);
                                Long totalTrip = data.child("TotalTrip").getValue(Long.class);
                                Long rating = data.child("Rating").getValue(Long.class);
                                if (destination != null && totalTrip != null && rating != null) {
                                    String avatar = data.child("Avatar").getValue(String.class);
                                    String customerName = data.child("CustomerName").getValue(String.class);
                                    String date = data.child("Date").getValue(String.class);
                                    String feedback = data.child("Feedback").getValue(String.class);

                                    ArrayList<String> Images = new ArrayList<>();
                                    for (DataSnapshot subData: data.child("Image").getChildren()) {
                                        String Str = subData.getValue(String.class);
                                        Images.add(Str);
                                    }

                                    for (DataSnapshot subData: data.child("Tag").getChildren()) {
                                        String Str = subData.getValue(String.class);
                                        Log.d("Tag: ", Str);
                                        Tags.add(Str);
                                        if (Str.equals("Full Information")) {
                                            FullInformation.add("1");
                                        } else if (Str.equals("Employee’s Attitudes")) {
                                            EmployeesAttitudes.add("1");
                                        } else if (Str.equals("Convenience & Comfort")) {
                                            ConvenienceComfort.add("1");
                                        } else if (Str.equals("Verified Information")) {
                                            VerifiedInformation.add("1");
                                        } else if (Str.equals("Safety")) {
                                            Safety.add("1");
                                        } else if (Str.equals("Service Quality")) {
                                            ServiceQuality.add("1");
                                        }
                                        loadProgress();
                                    }

                                    // Decode the Base64 string into a byte array


                                    TripDetail3 tripDetail3 = new TripDetail3();
                                    tripDetail3.setTotalTrip(totalTrip.toString());
                                    tripDetail3.setDestination(destination.toString());
                                    tripDetail3.setAvatar(convertBase64toBitmap(avatar));
                                    tripDetail3.setFeedback(feedback);
                                    tripDetail3.setRating(rating.toString());
                                    tripDetail3.setCustomerName(customerName);
                                    tripDetail3.setDate(date);
                                    tripDetail3.setImage(Images);

                                    tripDetail3Adapter.add(tripDetail3);
                                }
                            }
                        }
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.e(TAG, "loadPost:onCancelled", error.toException());
                }
            });

        }

        private Bitmap convertBase64toBitmap(String base64String) {
            try {
                // Remove the data URI prefix if present
                String pureBase64Encoded = base64String.split(",")[1];

                // Decode the Base64 string into a byte array
                byte[] decodedBytes = Base64.decode(pureBase64Encoded, Base64.DEFAULT);

                // Convert the byte array into a Bitmap
                Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);

                return bitmap;
            } catch (Exception e) {
                e.printStackTrace();
                return null; // Return null to indicate failure
            }
        }
    }
