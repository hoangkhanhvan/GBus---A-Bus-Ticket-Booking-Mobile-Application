package com.vanhk.gbus.adapter;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.vanhk.gbus.R;
import com.vanhk.gbus.model.Payment;
import com.vanhk.gbus.model.Voucher;

import java.util.ArrayList;

public class PaymentAdapter extends RecyclerView.Adapter<PaymentAdapter.ViewHolder> {
    public ArrayList<Payment> paymentArrayList;
    public int selectedPosition = -1; // Variable to keep track of the currently checked position

    public PaymentAdapter(ArrayList<Payment> payments) {
        if (payments != null) {
            this.paymentArrayList = new ArrayList<>(payments);
        } else {
            this.paymentArrayList = new ArrayList<>();
        }
    }
    public Payment getItem(int position) {
        if (position >= 0 && position < paymentArrayList.size()) {
            return paymentArrayList.get(position);
        } else {
            return null;
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.choose_payment_method_items, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Payment payment = paymentArrayList.get(position);
        holder.bind(payment, position);
    }

    @Override
    public int getItemCount() {
        return paymentArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtMethod, txtSubLogo, txtSubTitle;
        RadioButton radioBtn;
        ImageView imgMethod;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtMethod = itemView.findViewById(R.id.txtMethod);
            imgMethod = itemView.findViewById(R.id.imageView8);
            radioBtn = itemView.findViewById(R.id.radChoosePaymentMethod);
            txtSubLogo = itemView.findViewById(R.id.textView32);
            txtSubTitle = itemView.findViewById(R.id.textView49);

            // Set click listener for the item view
//            itemView.setOnClickListener(v -> {
//                int position = getAdapterPosition();
//                if (position != RecyclerView.NO_POSITION) {
//                    // Update the selected position directly in the adapter
//                    selectedPosition = position;
//                    notifyItemChanged(position); // Notify adapter of data set change for this specific item
//                }
//            });

            // Set checked change listener for the radio button
            radioBtn.setOnClickListener(v -> {
                selectedPosition = getAdapterPosition();
                notifyDataSetChanged();
            });
        }

        public void bind(Payment payment, int position) {
            txtMethod.setText(payment.getMethod());
            radioBtn.setChecked(position == selectedPosition);
            imgMethod.setImageBitmap(convertBase64toBitmap(payment.getImage()));
            txtSubLogo.setText(payment.getMethod());
            txtSubTitle.setText("Link " + payment.getMethod() + " account");


        }
    }

    // Method to add a new payment to the adapter
    public void add(Payment payment) {
        paymentArrayList.add(payment);
        notifyItemInserted(paymentArrayList.size() - 1);
    }

    // Method to clear all items from the adapter
    public void clear() {
        if (paymentArrayList != null) {
            paymentArrayList.clear();
            notifyDataSetChanged();
        }
    }

    // Method to get the selected item
    public Payment getSelectedPayment() {
        if (selectedPosition != -1 && selectedPosition < paymentArrayList.size()) {
            return paymentArrayList.get(selectedPosition);
        }
        return null;
    }

    // Method to get the selected position
    public int getSelectedPosition() {
        return selectedPosition;
    }

    private Bitmap convertBase64toBitmap(String base64String) {
        try {
            // Remove the data URI prefix if present
            String pureBase64Encoded = base64String.split(",")[1];

            // Decode the Base64 string into a byte array
            byte[] decodedBytes = Base64.decode(pureBase64Encoded, Base64.DEFAULT);

            // Convert the byte array into a Bitmap
            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);

            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Return null to indicate failure
        }
    }


}
