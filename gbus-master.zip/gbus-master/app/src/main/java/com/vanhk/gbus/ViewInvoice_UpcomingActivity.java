package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.model.BookedTicket;
import com.vanhk.gbus.model.Driver;
import com.vanhk.gbus.model.Ticket1;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class ViewInvoice_UpcomingActivity extends AppCompatActivity {
    static final int CALL_PHONE_PERMISSION_REQUEST_CODE = 101;
    TextView txtViewInvoiceUpcomingCountDown, txtViewInvoiceUpcomingTag,
            txtViewInvoiceUpcomingName, txtViewInvoiceUpcomingPhoneNumber, txtViewInvoiceUpcomingEmail,
            txtViewInvoiceUpcomingLicensePlate,
            txtDriver1, txtViewInvoiceUpcomingPhoneDriver1,
            txtDriver2, txtViewInvoiceUpcomingPhoneDriver2,
            txtInvoiceUpcomingTimestamp, txtInvoiceUpcomingTransactionNo, txtViewInvoiceUpcomingTrip, txtViewInvoiceUpcomingState,
            txtViewInvoiceUpcomingBusType, txtViewInvoiceUpcomingQuantity, txtViewInvoiceUpcomingSeatDepart, txtViewInvoiceUpcomingSeatReturn,
            txtViewInvoiceUpcomingDepartPickupLocation, txtViewInvoiceUpcomingDepartPickupDescription, txtViewInvoiceUpcomingDepartPickupExpectedTime2,
            txtViewInvoiceUpcomingDepartDropoffLocation, txtDepartDropoffDescription, txtViewInvoiceUpcomingDepartDropoffExpectedTime,
            txtSubtotalTicket, txtViewInvoiceUpcomingSubtotal, txtViewInvoiceUpcomingDiscount, txtViewInvoiceUpcomingTotal,
            txtViewInvoiceUpcomingReturnPickupLocation, txtViewInvoiceUpcomingReturnPickupDescription, txtViewInvoiceUpcomingReturnPickupExpectedTime,
            txtViewInvoiceUpcomingReturnDropoffLocation, txtViewInvoiceUpcomingReturnDropoffDescription, txtViewInvoiceUpcomingReturDropoffExpectedTime;
    TextView txtReturn,textView43;
    ImageView imgViewInvoiceUpcomingBack;
    Button btnViewInvoiceUpcomingViewInvoice;
    LinearLayout llReturn;

    ImageButton imageCallButton1, imageCallButton2;
    private CountDownTimer countDownTimer;

    private String driverPhoneNumber;
    private String driverPhoneNumber1;
    private String driverPhoneNumber2;
    String bookedTicketId = "";

    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_invoice_upcoming);

        addViews();
        addEvents();

        // Initialize the ProgressDialog

    }

    private void addEvents() {
        imgViewInvoiceUpcomingBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewInvoice_UpcomingActivity.this, PaidTicketActivity.class);
                startActivity(intent);
            }
        });

        btnViewInvoiceUpcomingViewInvoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewInvoice_UpcomingActivity.this, HomepageActivity.class);
                startActivity(intent);
            }
        });

//        countDownTimer = new CountDownTimer(15 * 60 * 1000, 1000) {
//            @Override
//            public void onTick(long millisUntilFinished) {
//                long minutes = millisUntilFinished / 60000;
//                long seconds = (millisUntilFinished % 60000) / 1000;
//                String timeLeftFormatted = String.format("%02d:%02d", minutes, seconds);
//                txtViewInvoiceUpcomingCountDown.setText(timeLeftFormatted);
//            }
//
//            @Override
//            public void onFinish() {
//                txtViewInvoiceUpcomingCountDown.setText("Out of time");
//            }
//        }.start();

        //Click on Image Call

        imageCallButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkingPermission(driverPhoneNumber1);
                if (txtViewInvoiceUpcomingPhoneDriver1 != null) {
                    showCallConfirmationDialog(driverPhoneNumber1);
                } else {
                    // Show a toast message indicating that the driver's phone number is not available
                    Toast.makeText(ViewInvoice_UpcomingActivity.this, "Driver's phone number not available", Toast.LENGTH_SHORT).show();
                }
            }
        });
        imageCallButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkingPermission(driverPhoneNumber2);
                if (txtViewInvoiceUpcomingPhoneDriver2 != null) {
                    showCallConfirmationDialog(driverPhoneNumber2);
                } else {
                    // Handle case where driver phone number is not available
                    Toast.makeText(ViewInvoice_UpcomingActivity.this, "Driver's phone number not available", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void checkingPermission(String driverPhoneNumber) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            // Request the permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, CALL_PHONE_PERMISSION_REQUEST_CODE);
        } else {
            // Permission already granted, proceed with making the call
            showCallConfirmationDialog(driverPhoneNumber);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CALL_PHONE_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed with making the call
            } else {
                // Permission denied, show a message or take appropriate action
                Toast.makeText(this, "Permission denied to make phone calls", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showCallConfirmationDialog(final String driverPhoneNumber) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Call Driver?");
        builder.setMessage("Do you want to make a direct call to driver?");
        // YES Button
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                makeDirectCall(driverPhoneNumber);
                dialog.dismiss();
            }
        });
        // NO Button
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        // Create an AlertDialog
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(true);

        // Show Dialog
        dialog.show();
    }

    private void makeDirectCall(String driverPhoneNumber) {
        Intent intent = new Intent(Intent.ACTION_CALL);
        Uri uri = Uri.parse("tel:" + driverPhoneNumber);
        intent.setData(uri);
        startActivity(intent);
    }

    private void addViews() {
        txtViewInvoiceUpcomingCountDown = findViewById(R.id.txtViewInvoiceUpcomingCountDown);
        txtViewInvoiceUpcomingTag = findViewById(R.id.txtViewInvoiceUpcomingTag);
        txtViewInvoiceUpcomingName = findViewById(R.id.txtViewInvoiceUpcomingName);
        txtViewInvoiceUpcomingPhoneNumber = findViewById(R.id.txtViewInvoiceUpcomingPhoneNumber);
        txtViewInvoiceUpcomingEmail = findViewById(R.id.txtViewInvoiceUpcomingEmail);
        txtViewInvoiceUpcomingLicensePlate = findViewById(R.id.txtViewInvoiceUpcomingLicensePlate);
        txtDriver1 = findViewById(R.id.txtDriver1);
        txtViewInvoiceUpcomingPhoneDriver1 = findViewById(R.id.txtViewInvoiceUpcomingPhoneDriver1);
        txtDriver2 = findViewById(R.id.txtDriver2);
        txtViewInvoiceUpcomingPhoneDriver2 = findViewById(R.id.txtViewInvoiceUpcomingPhoneDriver2);
        txtInvoiceUpcomingTimestamp = findViewById(R.id.txtInvoiceUpcomingTimestamp);
        txtInvoiceUpcomingTransactionNo = findViewById(R.id.txtInvoiceUpcomingTransactionNo);
        txtViewInvoiceUpcomingTrip = findViewById(R.id.txtViewInvoiceUpcomingTrip);
        txtViewInvoiceUpcomingState = findViewById(R.id.txtViewInvoiceUpcomingState);
        txtViewInvoiceUpcomingBusType = findViewById(R.id.txtViewInvoiceUpcomingBusType);
        txtViewInvoiceUpcomingQuantity = findViewById(R.id.txtViewInvoiceUpcomingQuantity);
        txtViewInvoiceUpcomingSeatDepart = findViewById(R.id.txtViewInvoiceUpcomingSeatDepart);
        txtViewInvoiceUpcomingSeatReturn = findViewById(R.id.txtViewInvoiceUpcomingSeatReturn);
        txtViewInvoiceUpcomingDepartPickupLocation = findViewById(R.id.txtViewInvoiceUpcomingDepartPickupLocation);
        txtViewInvoiceUpcomingDepartPickupDescription = findViewById(R.id.txtViewInvoiceUpcomingDepartPickupDescription);
        txtViewInvoiceUpcomingDepartPickupExpectedTime2 = findViewById(R.id.txtViewInvoiceUpcomingDepartPickupExpectedTime2);
        txtViewInvoiceUpcomingDepartDropoffLocation = findViewById(R.id.txtViewInvoiceUpcomingDepartDropoffLocation);
        txtDepartDropoffDescription = findViewById(R.id.txtDepartDropoffDescription);
        txtViewInvoiceUpcomingDepartDropoffExpectedTime = findViewById(R.id.txtViewInvoiceUpcomingDepartDropoffExpectedTime);
        txtSubtotalTicket = findViewById(R.id.txtSubtotalTicket);
        txtViewInvoiceUpcomingSubtotal = findViewById(R.id.txtViewInvoiceUpcomingSubtotal);
        txtViewInvoiceUpcomingDiscount = findViewById(R.id.txtViewInvoiceUpcomingDiscount);
        txtViewInvoiceUpcomingTotal = findViewById(R.id.txtViewInvoiceUpcomingTotal);
        imgViewInvoiceUpcomingBack = findViewById(R.id.imgViewInvoiceUpcomingBack);
        btnViewInvoiceUpcomingViewInvoice = findViewById(R.id.btnViewInvoiceUpcomingViewInvoice);
        txtViewInvoiceUpcomingReturnPickupLocation = findViewById(R.id.txtViewInvoiceUpcomingReturnPickupLocation);
        txtViewInvoiceUpcomingReturnPickupDescription = findViewById(R.id.txtViewInvoiceUpcomingReturnPickupDescription);
        txtViewInvoiceUpcomingReturnPickupExpectedTime = findViewById(R.id.txtViewInvoiceUpcomingReturnPickupExpectedTime);
        txtViewInvoiceUpcomingReturnDropoffLocation = findViewById(R.id.txtViewInvoiceUpcomingReturnDropoffLocation);
        txtViewInvoiceUpcomingReturnDropoffDescription = findViewById(R.id.txtViewInvoiceUpcomingReturnDropoffDescription);
        txtViewInvoiceUpcomingReturDropoffExpectedTime = findViewById(R.id.txtViewInvoiceUpcomingReturDropoffExpectedTime);
        imageCallButton1=findViewById(R.id.imageCallButton1);
        imageCallButton2=findViewById(R.id.imageCallButton2);
        txtReturn = findViewById(R.id.txtReturn);
        llReturn = findViewById(R.id.llReturn);
        textView43 = findViewById(R.id.textView43);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        bookedTicketId = sharedPreferences.getString("BookedTicketId", "");
        Log.d("Ticket",bookedTicketId);
        loadData();

        imageCallButton1 = findViewById(R.id.imageCallButton1);


    }

    private void loadData() {
        // Show the ProgressDialog
        progressDialog.show();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        final BookedTicket[] ticket = {new BookedTicket()};
        if (ticket[0].getReturn() != null) {
            txtReturn.setVisibility(View.VISIBLE);
            llReturn.setVisibility(View.VISIBLE);
            txtViewInvoiceUpcomingState.setText("Round-trip");
        } else {
            txtReturn.setVisibility(View.GONE);
            llReturn.setVisibility(View.GONE);
            txtViewInvoiceUpcomingState.setText("One-way-trip");
        }

        myRef.child("BookedTicket").child(bookedTicketId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ticket[0] = snapshot.getValue(BookedTicket.class);
                String discountPrice = snapshot.child("discountPrice").getValue(String.class);
                if (ticket[0] != null && ticket[0].getPassenger() != null) {
                    txtViewInvoiceUpcomingName.setText(ticket[0].getPassenger().getName());
                    txtViewInvoiceUpcomingPhoneNumber.setText(ticket[0].getPassenger().getPhoneNumber());
                    txtViewInvoiceUpcomingEmail.setText(ticket[0].getPassenger().getEmail());

                }
                if (ticket[0] != null) {
                    txtViewInvoiceUpcomingTag.setText(ticket[0].getStatus());
                    txtInvoiceUpcomingTimestamp.setText(ticket[0].getBookedTime());
                }

                if (snapshot.exists()) {
                    String transactionno = snapshot.child("TransactionNumber").getValue(String.class);
                    if (transactionno != null) {
                        txtInvoiceUpcomingTransactionNo.setText(transactionno.toString());
                    }
                }
                String status = calculateTimeStatus(ticket[0].getDeparture().getTicket().getDTime(), ticket[0].getDeparture().getTicket().getATime(), ticket[0].getDeparture().getTicket().getDate());
                if (status.equals("Upcoming")) {
                    txtViewInvoiceUpcomingTag.setText("Upcoming");
                    txtViewInvoiceUpcomingTag.setTextColor(Color.parseColor("#4D2E00"));
                    txtViewInvoiceUpcomingTag.setBackgroundColor(Color.parseColor("#FFDDB5"));
                    startCountdownTimer(txtViewInvoiceUpcomingCountDown, ticket[0].getDeparture().getTicket().getDTime(),
                            ticket[0].getDeparture().getTicket().getDate(),true);
                    textView43.setText("Trip will depart in: ");
                } else if (status.equals("Ongoing")) {
                    txtViewInvoiceUpcomingTag.setText("Ongoing");
                    txtViewInvoiceUpcomingTag.setTextColor(Color.parseColor("#0D6EFD"));
                    txtViewInvoiceUpcomingTag.setBackgroundColor(Color.parseColor("#DCECFF"));
                    startCountdownTimer(txtViewInvoiceUpcomingCountDown, ticket[0].getDeparture().getTicket().getATime(),
                            ticket[0].getDeparture().getTicket().getDate(),false);
                    textView43.setText("Expected drop-off at: ");
                } else if (status.equals("Completed")) {
                    txtViewInvoiceUpcomingTag.setText("Completed");
                    txtViewInvoiceUpcomingTag.setTextColor(Color.parseColor("#129C12"));
                    txtViewInvoiceUpcomingTag.setBackgroundColor(Color.parseColor("#D8F7E0"));
                    txtViewInvoiceUpcomingCountDown.setVisibility(View.GONE);
                    textView43.setText(ticket[0].getDeparture().getTicket().getATime()+" - "+ticket[0].getDeparture().getTicket().getDate());
                }
                int totalPrice = 0;
                int totalSeats = 0;
                if (ticket[0].getReturn() != null) {
                    totalPrice = ticket[0].getDeparture().getTotalPrice() + ticket[0].getReturn().getTotalPrice();
                    totalSeats = ticket[0].getDeparture().getSeat().size() + ticket[0].getReturn().getSeat().size();
                } else {
                    totalPrice = ticket[0].getDeparture().getTotalPrice();
                    totalSeats = ticket[0].getDeparture().getSeat().size() ;
                    txtViewInvoiceUpcomingSeatReturn.setVisibility(View.GONE);
                }
                txtViewInvoiceUpcomingQuantity.setText(totalSeats + " ticket(s)");
                txtSubtotalTicket.setText(totalSeats + " ticket(s)");
                txtViewInvoiceUpcomingSeatDepart.setText(ticket[0].getDeparture().getSeat().toString() + "(Departure Trip)");
                if (discountPrice != null) {
                    String formattedDiscount = String.format(Locale.getDefault(), "%,d VND", totalPrice - Integer.parseInt(discountPrice));
                    txtViewInvoiceUpcomingDiscount.setText(formattedDiscount);

                    String formattedTotal = String.format(Locale.getDefault(), "%,d VND", (int) Integer.parseInt(discountPrice));
                    txtViewInvoiceUpcomingTotal.setText(formattedTotal);
                } else {
                    txtViewInvoiceUpcomingDiscount.setText("0");
                    String formattedTotal = String.format(Locale.getDefault(), "%,d VND", (int) totalPrice);
                    txtViewInvoiceUpcomingTotal.setText(formattedTotal);
                }

                //Khúc driver này chưa truy suất được từ id bên database BookedTicket sang database Driver
                if (ticket[0] != null && ticket[0].getDeparture().getTicket().getDriver() != null) {
                    List<String> driverIds = ticket[0].getDeparture().getTicket().getDriver();
                    if (!driverIds.isEmpty()) {
                        loadDriverInfo(driverIds.get(0), txtDriver1, txtViewInvoiceUpcomingPhoneDriver1);
                        Toast.makeText(ViewInvoice_UpcomingActivity.this, "Have driver", Toast.LENGTH_SHORT).show();
                        if (driverIds.size() > 1) {
                            //loadDriverInfo2(driverIds.get(1), txtDriver2, txtViewInvoiceUpcomingPhoneDriver2);

                        }
                    }
                }

                if (ticket[0] != null && ticket[0].getDeparture() != null) {
                    txtViewInvoiceUpcomingTrip.setText(ticket[0].getDeparture().getDLocation() + " - " + ticket[0].getDeparture().getALocation());
                    txtViewInvoiceUpcomingBusType.setText(ticket[0].getDeparture().getBus());
                }
                // Dismiss the ProgressDialog when data loading is complete

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Dismiss the ProgressDialog if loading is canceled or fails
            }


            private void loadDriverInfo(String driverId, TextView txtDriver1, TextView txtViewInvoiceUpcomingPhoneDriver1) {
                DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Driver");
                ref.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot data: dataSnapshot.getChildren()) {
                            String _id = data.child("_id").getValue(String.class);
                            Log.d("Driver", _id);
                            if (_id != null && _id.equals(driverId)) {
                                String driverName = data.child("Name").getValue(String.class);
                                String phoneNumber = data.child("PhoneNumber").getValue(String.class);
                                txtDriver1.setText(driverName);
                                txtViewInvoiceUpcomingPhoneDriver1.setText(phoneNumber);
                                driverPhoneNumber1 = phoneNumber;
                            }
                            else if (_id != null && _id.equals(ticket[0].getDeparture().getTicket().getDriver().get(1))) {
                                String driverName = data.child("Name").getValue(String.class);
                                String phoneNumber = data.child("PhoneNumber").getValue(String.class);
                                txtDriver2.setText(driverName);
                                txtViewInvoiceUpcomingPhoneDriver2.setText(phoneNumber);
                                driverPhoneNumber2 = phoneNumber;
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }
                });

            }
        });

        DatabaseReference myRef2 = database.getReference();
        myRef2.child("BookedTicket").child(bookedTicketId).child("return").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String seatLocation1 = snapshot.child("seat").child("0").getValue(String.class);
                    String seatLocation2 = snapshot.child("seat").child("1").getValue(String.class);
                    if (seatLocation1 != null && seatLocation2 != null) {
                        String aSeat = seatLocation1 + ", " + seatLocation2 + " (Return Trip)";
                        txtViewInvoiceUpcomingSeatReturn.setText(aSeat);
                        Log.d("seat", "Combined seat: " + aSeat);
                    }
                } else {
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        DatabaseReference myRef4 = database.getReference();
        myRef4.child("BookedTicket").child(bookedTicketId).child("departure").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String point = snapshot.child("pickUpPoint").child("point").getValue(String.class);
                    String address = snapshot.child("pickUpPoint").child("address").getValue(String.class);
                    String dateStr = snapshot.child("pickUpPoint").child("dateStr").getValue(String.class);
                    String time = snapshot.child("pickUpPoint").child("time").getValue(String.class);

                    String point1 = snapshot.child("dropOffPoint").child("point").getValue(String.class);
                    String address1 = snapshot.child("dropOffPoint").child("address").getValue(String.class);
                    String dateStr1 = snapshot.child("dropOffPoint").child("dateStr").getValue(String.class);
                    String time1 = snapshot.child("dropOffPoint").child("time").getValue(String.class);


                    if (point != null && address != null && dateStr != null && time != null && point1 != null && address1 != null && dateStr1 != null && time1 != null) {
                        txtViewInvoiceUpcomingDepartPickupLocation.setText(point.toString());
                        txtViewInvoiceUpcomingDepartPickupDescription.setText(address.toString());

                        String aExpect = time + " - " + dateStr;
                        txtViewInvoiceUpcomingDepartPickupExpectedTime2.setText(aExpect);
                        //Log.d("seat", "Combined seat: " + aExpect);


                        txtViewInvoiceUpcomingDepartDropoffLocation.setText(point1.toString());
                        txtDepartDropoffDescription.setText(address1.toString());
                        String aExpect1 = time1 + " - " + dateStr1;
                        txtViewInvoiceUpcomingDepartDropoffExpectedTime.setText(aExpect1);
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        DatabaseReference myRef5 = database.getReference();
        myRef5.child("BookedTicket").child(bookedTicketId).child("return").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String point = snapshot.child("pickUpPoint").child("point").getValue(String.class);
                    String address = snapshot.child("pickUpPoint").child("address").getValue(String.class);
                    String dateStr = snapshot.child("pickUpPoint").child("dateStr").getValue(String.class);
                    String time = snapshot.child("pickUpPoint").child("time").getValue(String.class);

                    String point1 = snapshot.child("dropOffPoint").child("point").getValue(String.class);
                    String address1 = snapshot.child("dropOffPoint").child("address").getValue(String.class);
                    String dateStr1 = snapshot.child("dropOffPoint").child("dateStr").getValue(String.class);
                    String time1 = snapshot.child("dropOffPoint").child("time").getValue(String.class);


                    if (point != null && address != null && dateStr != null && time != null && point1 != null && address1 != null && dateStr1 != null && time1 != null) {
                        txtViewInvoiceUpcomingReturnPickupLocation.setText(point.toString());
                        txtViewInvoiceUpcomingReturnPickupDescription.setText(address.toString());

                        String aExpect = time + " - " + dateStr;
                        txtViewInvoiceUpcomingReturnPickupExpectedTime.setText(aExpect);
                        //Log.d("seat", "Combined seat: " + aExpect);


                        txtViewInvoiceUpcomingReturnDropoffLocation.setText(point1.toString());
                        txtViewInvoiceUpcomingReturnDropoffDescription.setText(address1.toString());
                        String aExpect1 = time1 + " - " + dateStr1;
                        txtViewInvoiceUpcomingReturDropoffExpectedTime.setText(aExpect1);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        DatabaseReference myRef6 = database.getReference();
        myRef6.child("BookedTicket").child(bookedTicketId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                BookedTicket ticket = snapshot.getValue(BookedTicket.class);
                if (snapshot.exists()) ;
                {
                    DataSnapshot departureSeatsSnapshot = snapshot.child("departure").child("seat");
                    DataSnapshot returnSeatsSnapshot = snapshot.child("return").child("seat");
                    if (ticket!=null) {
                        int totalPrice = 0;
                        if (ticket.getReturn() != null) {
                            totalPrice = ticket.getDeparture().getTotalPrice() + ticket.getReturn().getTotalPrice();
                        } else {
                            totalPrice = ticket.getDeparture().getTotalPrice();
                        }
                        String formattedSubtotal = String.format(Locale.getDefault(), "%,d VND", totalPrice);
                        txtViewInvoiceUpcomingSubtotal.setText(formattedSubtotal);

                        DatabaseReference myRef7 = database.getReference();
                        int finalTotalPrice = totalPrice;
                        myRef7.child("Vouchers").child("0").addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if (snapshot.exists()) {
                                    String percentageString = snapshot.child("percentage").getValue(String.class).replace("%", "");
                                    int percentage = Integer.parseInt(percentageString);
                                    int discount = (int) (finalTotalPrice * percentage / 100.0);
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                    }


                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }

        });

        DatabaseReference myRef7 = database.getReference();
        myRef7.child("Vehicle").child("0").addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String license = snapshot.child("LicenseNumber").getValue(String.class);
                    if (license != null) {
                        txtViewInvoiceUpcomingLicensePlate.setText(license.toString());
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        progressDialog.dismiss();
    }

    DatabaseReference database1 = FirebaseDatabase.getInstance().getReference();
    DatabaseReference bookedTicketRef = database1.child("BookedTicket");
    DatabaseReference driversRef = database1.child("Drivers");

    private void fetchDriverInfoFromBookedTicket() {
        bookedTicketRef.child(bookedTicketId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String driver1Id = dataSnapshot.child("departure").child("ticket").child("driver").child("0").getValue(String.class);
                    String driver2Id = dataSnapshot.child("departure").child("ticket").child("driver").child("1").getValue(String.class);

                    fetchDriverDetails(driver1Id, txtDriver1, txtViewInvoiceUpcomingPhoneDriver1);
                    fetchDriverDetails(driver2Id, txtDriver2, txtViewInvoiceUpcomingPhoneDriver1);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("Firebase Data", "loadBookedTicket:onCancelled", databaseError.toException());
            }
        });
    }


    private void fetchDriverDetails(String driverId, TextView nameTextView, TextView phoneTextView) {
        driversRef.child("0").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String name = dataSnapshot.child("Name").getValue(String.class);
                    String phone = dataSnapshot.child("PhoneNumber").getValue(String.class);
                    nameTextView.setText(name);
                    phoneTextView.setText(phone);
                } else {
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("Firebase Data", "loadDriver:onCancelled", databaseError.toException());
            }
        });
    }
    public static String calculateTimeStatus(String startTimeStr, String endTimeStr, String startDateStr) {
        // Get current time
        Calendar currentTime = Calendar.getInstance();

        // Parse start time string
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
        Calendar startTime = Calendar.getInstance();
        try {
            Date startTimeDate = timeFormat.parse(startTimeStr);
            startTime.setTime(startTimeDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return "Invalid time format";
        }

        // Parse end time string
        Calendar endTime = Calendar.getInstance();
        try {
            Date endTimeDate = timeFormat.parse(endTimeStr);
            endTime.setTime(endTimeDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return "Invalid time format";
        }

        // Parse start date string
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Calendar startDate = Calendar.getInstance();
        try {
            Date startDateDate = dateFormat.parse(startDateStr);
            startDate.setTime(startDateDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return "Invalid date format";
        }

        // Combine start date and start time
        startTime.set(Calendar.YEAR, startDate.get(Calendar.YEAR));
        startTime.set(Calendar.MONTH, startDate.get(Calendar.MONTH));
        startTime.set(Calendar.DAY_OF_MONTH, startDate.get(Calendar.DAY_OF_MONTH));

        // Combine start date and end time
        endTime.set(Calendar.YEAR, startDate.get(Calendar.YEAR));
        endTime.set(Calendar.MONTH, startDate.get(Calendar.MONTH));
        endTime.set(Calendar.DAY_OF_MONTH, startDate.get(Calendar.DAY_OF_MONTH));

        // Check current time against start and end times
        if (currentTime.before(startTime)) {
            return "Upcoming";
        } else if (currentTime.after(startTime) && currentTime.before(endTime)) {
            return "Ongoing";
        } else {
            return "Completed";
        }
    }
    private void startCountdownTimer(TextView textView, String timeStr, String dateStr, boolean isDeparture) {
        SimpleDateFormat dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
        Calendar targetDateTime = Calendar.getInstance();
        try {
            Date targetDate = dateTimeFormat.parse(dateStr + " " + timeStr);
            targetDateTime.setTime(targetDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return;
        }

        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                long currentTimeMillis = System.currentTimeMillis();
                long timeDifferenceMillis = targetDateTime.getTimeInMillis() - currentTimeMillis;

                if (timeDifferenceMillis > 0) {
                    long hours = TimeUnit.MILLISECONDS.toHours(timeDifferenceMillis) % 24;
                    long minutes = TimeUnit.MILLISECONDS.toMinutes(timeDifferenceMillis) % 60;
                    long seconds = TimeUnit.MILLISECONDS.toSeconds(timeDifferenceMillis) % 60;
                    textView.setText(String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds));

                    // Update every second
                    handler.postDelayed(this, 1000);
                } else {
                    textView.setText("00:00");
                }
            }
        });
    }
}

