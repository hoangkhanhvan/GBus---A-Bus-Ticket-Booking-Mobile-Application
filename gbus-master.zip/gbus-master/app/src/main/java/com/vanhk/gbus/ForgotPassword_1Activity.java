package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class ForgotPassword_1Activity extends AppCompatActivity {

    EditText edtForgotPassword1;
    Button btnForgotPassword1Next;
    Toolbar toolbarForgotPasswordBack;
    DatabaseReference myRef;

    FirebaseAuth auth;
    FirebaseDatabase database;

    String TAG = "FIREBASE";

    final String PREF_NAME = "ForgotPasswordData";

    ProgressDialog progressDialog; // Declare ProgressDialog

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password1);
        addViews();
        addEvents();

        setSupportActionBar(toolbarForgotPasswordBack);

        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog

    }

    //Internet changed
    BroadcastReceiver internetReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Toast.makeText(context, "Internet changed", Toast.LENGTH_LONG).show();
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            if (networkInfo != null && networkInfo.isConnected()) {
                btnForgotPassword1Next.setEnabled(true);
            } else {
                btnForgotPassword1Next.setBackgroundColor(R.drawable.button_background_disable);
                btnForgotPassword1Next.setEnabled(false);
            }
        }
    };

    private void addEvents() {
        toolbarForgotPasswordBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to start the specific previous Activity
                Intent intent = new Intent(ForgotPassword_1Activity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        btnForgotPassword1Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edtForgotPassword1.getText().toString().trim().isEmpty()) {
                    Toast.makeText(ForgotPassword_1Activity.this, "Please enter your Phone Number / Email", Toast.LENGTH_LONG).show();
                    edtForgotPassword1.setError("Phone Number / Email is required");
                    edtForgotPassword1.requestFocus();
                    return;
                } else {
                    final String enteredUserName = edtForgotPassword1.getText().toString().trim();
                    progressDialog.setMessage("Checking Account..."); // Set message for ProgressDialog
                    progressDialog.show(); // Show ProgressDialog
                    checkUserCredentials(enteredUserName);
                }
            }
        });

    }

    private void checkUserCredentials(String enteredCredential) {
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("account");

        progressDialog.setMessage("Checking account information...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                progressDialog.dismiss();
                boolean found = false;

                for (DataSnapshot data : dataSnapshot.getChildren()) {

                    String userName = data.child("accountUserName").getValue(String.class);

                    if (userName != null && isValidEmail(enteredCredential) && enteredCredential.equals(userName)) {
                        found = true;
                        editor.putString("Email", userName); // Assuming userEmail is the correct one to store
                        editor.apply();
                        Toast.makeText(ForgotPassword_1Activity.this, userName, Toast.LENGTH_SHORT).show();
                        proceedToResetPassword("Email");
                        break;
                    } else if (userName != null && isValidPhoneNumber(enteredCredential) && enteredCredential.equals(userName)) {
                        found = true;
                        proceedToResetPassword("Phone");
                        break;
                    }
                }

                if (!found) {
                    Toast.makeText(ForgotPassword_1Activity.this, "No account found with provided information. Please try again.", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
                Log.w(TAG, "onCancelled", databaseError.toException());
                Toast.makeText(ForgotPassword_1Activity.this, "Error checking account. Please try again later.", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void proceedToResetPassword(String method) {
        Intent intent;
        if (method.equals("Email")) {
            intent = new Intent(ForgotPassword_1Activity.this, ForgotPassword_2_2Activity.class);
        } else {
            intent = new Intent(ForgotPassword_1Activity.this, ForgotPassword_2_1Activity.class);
        }
        startActivity(intent);
    }

    private void sendResetLinkByEmail(String email) {
        // Code to send reset link to the email
        Intent intent = new Intent(ForgotPassword_1Activity.this, ForgotPassword_2_2Activity.class);
        startActivity(intent);
    }

    private boolean isValidPhoneNumber(String enteredUserName) {
        String phonePattern = "^\\d{10}$";
        return enteredUserName.matches(phonePattern);
    }

    private boolean isValidEmail(String enteredUserName) {
        String emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        return enteredUserName.matches(emailPattern);
    }

    protected void onPause() {
        super.onPause();
        saveForgotPasswordInformation();

        if (internetReceiver != null) {
            unregisterReceiver(internetReceiver);
        }
    }

    private void saveForgotPasswordInformation() {
        SharedPreferences preferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("account_username", edtForgotPassword1.getText().toString());
        editor.commit();
    }

    void readForgotPasswordInformation() {
        SharedPreferences preferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        String userName = preferences.getString("account_username", "");
        boolean save = preferences.getBoolean("SAVE", false);
        if (save == true) {
            edtForgotPassword1.setText(userName);
        }
    }

    protected void onResume() {
        super.onResume();
        readForgotPasswordInformation();

        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(internetReceiver, filter);
    }

    private void addViews() {
        edtForgotPassword1 = findViewById(R.id.edtForgotPassword1);
        btnForgotPassword1Next = findViewById(R.id.btnForgotPassword1Next);
        toolbarForgotPasswordBack = findViewById(R.id.toolbarForgotPasswordBack);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("account");
    }

    private void sendEmail() {
        try {
            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            String OTP = generateOTP();

            String stringSenderEmail = "gbusbookingapp@gmail.com";
            String stringReceiverEmail = sharedPreferences.getString("Email","");
            String stringPasswordSenderEmail = "zfrn jxxy bqfy trtu";

            String stringHost = "smtp.gmail.com";

            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("OTP", OTP);
            editor.putString("Email", stringReceiverEmail);
            editor.apply();

            Properties properties = System.getProperties();

            properties.put("mail.smtp.host", stringHost);
            properties.put("mail.smtp.port", "465");
            properties.put("mail.smtp.ssl.enable", "true");
            properties.put("mail.smtp.auth", "true");

            javax.mail.Session session = Session.getInstance(properties, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(stringSenderEmail, stringPasswordSenderEmail);
                }
            });

            MimeMessage mimeMessage = new MimeMessage(session);
            mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(stringReceiverEmail));

            mimeMessage.setSubject("OTP Code Verification");
            mimeMessage.setText("Hello,\n\nYour OTP (One-Time Password) verification code is: " + OTP + "\n\nPlease use this code to verify your identity.\n\nIf you did not request this OTP, please ignore this email.\n\nThank you,\nGBus");

            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Transport.send(mimeMessage);
                    } catch (MessagingException e) {
                        e.printStackTrace();
                    }
                }
            });
            thread.start();

        } catch (AddressException e) {
            e.printStackTrace();
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    public static String generateOTP() {
        // Define the length of the OTP
        int otpLength = 4;

        // Generate random digits for the OTP
        Random random = new Random();
        StringBuilder otp = new StringBuilder();

        for (int i = 0; i < otpLength; i++) {
            otp.append(random.nextInt(10)); // Generates a random digit (0-9)
        }

        return otp.toString();
    }

//    private void setSupportActionBar(Toolbar toolbarBack) {
//        setSupportActionBar(toolbarBack);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setDisplayShowHomeEnabled(true);    }

//    private void doForgotPassword() {
//        String emailOrPhone = edtForgotPassword1.getText().toString().trim();
//
//        if (!emailOrPhone.isEmpty()) {
//            myRef.orderByChild("phone").equalTo(emailOrPhone).addListenerForSingleValueEvent(new ValueEventListener() {
//                @Override
//                public void onDataChange(@NonNull DataSnapshot snapshot) {
//                    if (snapshot.exists()) {
//                        // Sđt hoặc email tồn tại trong DB
//                        Intent intent = new Intent(ForgotPassword_1Activity.this, ForgotPassword_2_1Activity.class);
//                        intent.putExtra("emailOrPhone", emailOrPhone);
//                        startActivity(intent);
//                    } else {
//                        Toast.makeText(ForgotPassword_1Activity.this, "Email or phone number not found", Toast.LENGTH_SHORT).show();
//                    }
//                }
//                @Override
//                public void onCancelled(@NonNull DatabaseError error) {
//                    Toast.makeText(ForgotPassword_1Activity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
//                }
//            });
//        } else {
//            // Hiển thị thông báo lỗi nếu để trống
//            Toast.makeText(this, "Please enter email or phone number", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    private boolean isValidPhoneNumber(String userNameOrPhoneNumber) {
//        String phonePattern = "^\\d{10}$";
//        return userNameOrPhoneNumber.matches(phonePattern);
//    }
//
//    private boolean isValidEmail(String enteredUserName) {
//        String emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
//        return enteredUserName.matches(emailPattern);
//    }
}