package com.vanhk.gbus.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;

import com.vanhk.gbus.ChooseSeat_Depart_1Activity;
import com.vanhk.gbus.R;
import com.vanhk.gbus.ResultList1Activity;
import com.vanhk.gbus.TripDetails1Activity;
import com.vanhk.gbus.TripDetails2Activity;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.Ticket;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class TicketAdapter extends ArrayAdapter<Ticket> {
    Activity context;
    int resource;
    private OnBookNowClickListener onBookNowClickListener;
    private ArrayList<Ticket> tickets;
    public TicketAdapter(@NonNull Activity context, int resource) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
        tickets = new ArrayList<>();
    }

    public void setOnBookNowClickListener(OnBookNowClickListener listener) {
        this.onBookNowClickListener = listener;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = context.getLayoutInflater().inflate(resource, null);

        TextView DTime = view.findViewById(R.id.txtResultList1DepartTimeItem);
        TextView ATIme = view.findViewById(R.id.txtResultList1ArrivalTimeItem);
        TextView DurationTime = view.findViewById(R.id.txtResultList1Duration);
        TextView DOffice = view.findViewById(R.id.txtResultList1PickUpStartItem);
        TextView AOffice = view.findViewById(R.id.txtResultList1DropOffEndItem);
        TextView Bus = view.findViewById(R.id.txtResultList1BusNameItem);
        TextView Price = view.findViewById(R.id.txtResultList1BusPriceItem);
        TextView Seat = view.findViewById(R.id.txtResultList1SeatNumberItem);
        TextView Review = view.findViewById(R.id.txtResultList1ItemReviews);
        Button btnBooking = view.findViewById(R.id.btnResultList1BookNow);
        CardView cvTicket = view.findViewById(R.id.cvTicket);

        btnBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onBookNowClickListener != null) {
                    onBookNowClickListener.onBookNowClick(position);
                }
            }
        });

        cvTicket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to detail activity
                Ticket ticket = getItem(position);
                if (ticket != null) {
                    Intent intent = new Intent(context, TripDetails1Activity.class);
                    // Pass any necessary data to the detail activity using intent extras
                    MySharedPreferences.saveObject(context,"SelectedTicket",ticket);
                    context.startActivity(intent);
                }
            }
        });

        Ticket ticket = getItem(position);

        if (ticket!=null) {
            DTime.setText(ticket.getDTime());
            ATIme.setText(ticket.getATime());
            DurationTime.setText(calculateTimeDifference(ticket.getDTime(),ticket.getATime()));
            DOffice.setText(ticket.getDOffice());
            AOffice.setText(ticket.getAOffice());
            Bus.setText(ticket.getBus());
            Price.setText(String.valueOf(ticket.getPrice()));
            Seat.setText(String.valueOf(21-ticket.getSeat().size()));
            Review.setText(String.valueOf(ticket.getReviews().size()));
        }
        return view;
    }

    public static String calculateTimeDifference(String startTime, String endTime) {
        SimpleDateFormat format = new SimpleDateFormat("HH:mm");
        try {
            Date startDate = format.parse(startTime);
            Date endDate = format.parse(endTime);

            long difference = endDate.getTime() - startDate.getTime();
            if (difference < 0) {
                difference += 24 * 60 * 60 * 1000; // Add 24 hours in milliseconds
            }

            long hours = (difference / (60 * 60 * 1000)) % 24;
            long minutes = (difference / (60 * 1000)) % 60;

            return String.format("%02d:%02d", hours, minutes);

        } catch (ParseException e) {
            e.printStackTrace();
            return null; // Handle parse exception
        }
    }

    public interface OnBookNowClickListener {
        void onBookNowClick(int position);
    }

    public void add(Ticket ticket) {
        super.add(ticket);
        tickets.add(ticket); // Add the item to the internal list
    }

    // Method to get the list of items
    public ArrayList<Ticket> getItems() {
        return tickets;
    }

}
