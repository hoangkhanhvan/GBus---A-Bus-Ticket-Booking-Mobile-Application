package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.Layout;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.SearchHistoryAdapter;
import com.vanhk.gbus.adapter.TripDetail3Adapter;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.SearchHistory;
import com.vanhk.gbus.model.SearchItem;
import com.vanhk.gbus.model.Ticket;
import com.vanhk.gbus.model.TripDetail3;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class HomepageActivity extends AppCompatActivity {
    LinearLayout linearlayoutHomepageDepartLocation, linearlayoutHomepageArrivalLocation,
            linearlayoutDepartDate, linearlayoutReturnDate, linearlayoutHomepageScrollViewRecentSearch,
            linearlayoutHomepageNavigationSearch, linearlayoutHomepageNavigationHistory,
            linearlayoutHomepageNavigationNotifications, linearlayoutHomepageNavigationAccount, llSearchHistory;
    Switch switchHomepageDate;
    Ticket selectedTicket;
    Button btnHomepagePickupDeparture1Book, btnHomepageClear;
    HorizontalScrollView scrollviewHomepageRecentSearch;
    ListView lvHomepageReviews;
    RecyclerView rvHomepageSearch;

    TextView txtHomepageDepart, txtHomepageSelectArrival, txtHomepageSelectDepartDate, txtHomepageSelectArrivalDate;
    TripDetail3Adapter tripDetail3Adapter;
    ArrayList<TripDetail3> tripDetail3List;
    ArrayList<SearchHistory> searchHistoryArrayList = new ArrayList<>();

    SearchHistoryAdapter searchHistoryAdapter;


    public static final String DATABASE_NAME = "GBUS.db";

    ProgressDialog progressDialog;


    public static final String DB_PATH_SUFFIX = "/databases/";
    public static SQLiteDatabase database = null;

    private void copyDataBase(){
        try{
            File dbFile = getDatabasePath(DATABASE_NAME);
            if(!dbFile.exists()){
                if(CopyDBFromAsset()){
                    Toast.makeText(HomepageActivity.this,
                            "Copy database successful!", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(HomepageActivity.this,
                            "Copy database fail!", Toast.LENGTH_LONG).show();
                }
            }
        }catch (Exception e){
            Log.e("Error: ", e.toString());
        }
    }

    private boolean CopyDBFromAsset() {
        String dbPath = getApplicationInfo().dataDir + DB_PATH_SUFFIX + DATABASE_NAME;
        try {
            InputStream inputStream = getAssets().open(DATABASE_NAME);
            File f = new File(getApplicationInfo().dataDir + DB_PATH_SUFFIX);
            if(!f.exists()){
                f.mkdir();
            }
            OutputStream outputStream = new FileOutputStream(dbPath);
            byte[] buffer = new byte[1024]; int length;
            while((length=inputStream.read(buffer))>0){
                outputStream.write(buffer,0, length);
            }
            outputStream.flush();
            outputStream.close();
            inputStream.close();
            return  true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }



    ArrayList<String> Tags = new ArrayList<>();

    String TAG = "FIREBASE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        addViews();
        addEvents();
        copyDataBase();
        loadSearchHistoryIntoListView();

        // Initialize ProgressDialog
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void addEvents() {
        linearlayoutHomepageNavigationHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show ProgressDialog before starting the activity
                progressDialog.show();

                Intent intent = new Intent(HomepageActivity.this, UnpaidTicketActivity.class);
                startActivity(intent);

                // Dismiss ProgressDialog when the activity starts
                progressDialog.dismiss();
            }
        });
        linearlayoutHomepageDepartLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(HomepageActivity.this, Homepage2_1Activity.class);
                intent.putExtra("ALocation", txtHomepageSelectArrival.getText().toString());
                startActivity(intent);
            }
        });
        linearlayoutHomepageArrivalLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(HomepageActivity.this, Homepage2_2Activity.class);
                intent.putExtra("DLocation", txtHomepageDepart.getText().toString());
                startActivity(intent);
            }
        });
        linearlayoutDepartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDatePicker("departure");
            }
        });
        linearlayoutReturnDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDatePicker("return");
            }
        });
        btnHomepagePickupDeparture1Book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String DLocation = txtHomepageDepart.getText().toString();
                String ALocation = txtHomepageSelectArrival.getText().toString();
                if (!DLocation.equals("Select Departure Location") && !ALocation.equals("Select Arrival Location")) {
                    SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putBoolean("isReturnDone",false);
                    if (switchHomepageDate.isChecked()) {

                        editor.putString("RDate", txtHomepageSelectArrivalDate.getText().toString());
                    } else {

                        editor.putString("RDate", "Select Return Date");
                    }


                    SearchItem searchItem = new SearchItem();
                    editor.putString("DLocation",txtHomepageDepart.getText().toString());
                    editor.putString("ALocation",txtHomepageSelectArrival.getText().toString());
                    editor.putString("DDate",txtHomepageSelectDepartDate.getText().toString());

                    editor.apply();
                    Intent intent=new Intent(HomepageActivity.this, ResultList1Activity.class);
                    intent.putExtra("Search",searchItem.toString());
                    startActivity(intent);
                    processSave();
                } else {
                    Toast.makeText(HomepageActivity.this, "Please select location", Toast.LENGTH_SHORT).show();
                }

            }
        });
        btnHomepageClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processDelete();
            }
        });
        linearlayoutHomepageNavigationNotifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(HomepageActivity.this, NotificationsActivity.class);
                startActivity(intent);
            }
        });
        linearlayoutHomepageNavigationAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(HomepageActivity.this, AccountMangement1Activity.class);
                startActivity(intent);
            }
        });
        switchHomepageDate.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                if (isChecked) {
                    linearlayoutReturnDate.setVisibility(View.VISIBLE);
                    editor.putString("RDate", txtHomepageSelectArrivalDate.getText().toString());
                } else {
                    linearlayoutReturnDate.setVisibility(View.GONE);
                    editor.putString("RDate", "Select Return Date");
                }
                editor.apply();
            }
        });
        linearlayoutHomepageNavigationHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(HomepageActivity.this, UnpaidTicketActivity.class);
                startActivity(intent);
            }
        });
        linearlayoutHomepageNavigationNotifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(HomepageActivity.this, NotificationsActivity.class);
                startActivity(intent);
            }
        });
        linearlayoutHomepageNavigationAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(HomepageActivity.this, AccountMangement1Activity.class);
                startActivity(intent);
            }
        });
    }



    private void processSave() {
        ContentValues record = new ContentValues();

        record.put("SearchId", new Date().getTime());
        record.put("departureLocation", txtHomepageDepart.getText().toString());
        record.put("arrivalLocation", txtHomepageSelectArrival.getText().toString());
        record.put("departureDate", txtHomepageSelectDepartDate.getText().toString());
        record.put("returnDate", txtHomepageSelectArrivalDate.getText().toString());

        // Move existing rows down to make space for the new row


        // Insert the new row at the top (index 0)
        long result = database.insert("SearchHistory", null, record);

        if (result != -1) { // Check if the insertion was successful
            loadSearchHistoryIntoListView();
        }
    }

    private void moveExistingRowsDown() {
        // Perform SQL operation to move existing rows down
        // This operation will depend on your database schema and the SQL dialect you're using
        // You may need to use a temporary table or other techniques to achieve this
        // Here's a simplified example using SQL:
        String sql = "UPDATE SearchHistory SET _id = _id + 1";
        database.execSQL(sql);
    }

    private void loadSearchHistoryIntoListView() {
        String sql = "SELECT * FROM SearchHistory ORDER BY SearchId DESC";
        database=openOrCreateDatabase(DATABASE_NAME,MODE_PRIVATE,null);
        Cursor cursor=database.rawQuery(sql,null);
        if (cursor != null) {
            while(cursor.moveToNext())
            {
//            String productId=cursor.getInt(0);
                String searchDepartureLocation=cursor.getString(1);
                String searchArrivalLocation=cursor.getString(2);
                String searchDepartureDate=cursor.getString(3);
                SearchHistory searchHistory=new SearchHistory();
                searchHistory.setSearchDepartureLocation(searchDepartureLocation);
                searchHistory.setSearchArrivalLocation(searchArrivalLocation);
                searchHistory.setSearchDepartureDate(searchDepartureDate);
                searchHistoryArrayList.add(searchHistory);
                searchHistoryAdapter.notifyDataSetChanged();
            }
            cursor.close();
            if (searchHistoryArrayList.size() > 0) {
                llSearchHistory.setVisibility(View.VISIBLE);
            } else {
                llSearchHistory.setVisibility(View.GONE);
            }

        }
    }

    private void openDatePicker(String type) {
        Calendar calendarDate = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        DatePickerDialog.OnDateSetListener callBack = new                                                                               DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                calendarDate.set(Calendar.YEAR, i);
                calendarDate.set(Calendar.MONTH, i1);
                calendarDate.set(Calendar.DAY_OF_MONTH, i2);
                if (type.equals("departure")) {
                    txtHomepageSelectDepartDate.setText(dateFormat.format(calendarDate.getTime()));
                } else if (type.equals("return")) {
                    txtHomepageSelectArrivalDate.setText(dateFormat.format(calendarDate.getTime()));
                }
            }
        };
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                HomepageActivity.this,
                callBack,
                calendarDate.get(Calendar.YEAR),
                calendarDate.get(Calendar.MONTH),
                calendarDate.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    private void processDelete() {
        llSearchHistory.setVisibility(View.GONE);

        // Delete all rows from the SearchHistory table
        String deleteQuery = "DELETE FROM SearchHistory";
        database.execSQL(deleteQuery);

        searchHistoryArrayList.clear();
        searchHistoryAdapter.notifyDataSetChanged();
    }

    private void addViews() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);

        btnHomepagePickupDeparture1Book=findViewById(R.id.btnHomepagePickupDeparture1Book);
        btnHomepageClear=findViewById(R.id.btnHomepageClear);
        linearlayoutHomepageDepartLocation=findViewById(R.id.linearlayoutHomepageDepartLocation);
        linearlayoutHomepageArrivalLocation=findViewById(R.id.linearlayoutHomepageArrivalLocation);
        linearlayoutDepartDate=findViewById(R.id.linearlayoutDepartDate);
        linearlayoutReturnDate=findViewById(R.id.linearlayoutReturnDate);
        linearlayoutHomepageNavigationSearch=findViewById(R.id.linearlayoutHomepageNavigationSearch);
        linearlayoutHomepageNavigationHistory=findViewById(R.id.linearlayoutHomepageNavigationHistory);
        linearlayoutHomepageNavigationNotifications=findViewById(R.id.linearlayoutHomepageNavigationNotifications);
        linearlayoutHomepageNavigationHistory=findViewById(R.id.linearlayoutHomepageNavigationHistory);
        linearlayoutHomepageNavigationAccount=findViewById(R.id.linearlayoutHomepageNavigationAccount);
        switchHomepageDate=findViewById(R.id.switchHomepageDate);

        txtHomepageDepart=findViewById(R.id.txtHomepageDepart);
        txtHomepageSelectArrival=findViewById(R.id.txtHomepageSelectArrival);
        txtHomepageSelectDepartDate=findViewById(R.id.txtHomepageSelectDepartDate);
        txtHomepageSelectArrivalDate=findViewById(R.id.txtHomepageSelectArrivalDate);

        llSearchHistory = findViewById(R.id.llSearchHistory);
        llSearchHistory.setVisibility(View.GONE);

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        String DLocation = sharedPreferences.getString("DLocation","Select Departure Location");
        String ALocation = sharedPreferences.getString("ALocation","Select Arrival Location");
        txtHomepageDepart.setText(DLocation);
        txtHomepageSelectArrival.setText(ALocation);

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        txtHomepageSelectDepartDate.setText(dateFormat.format(new Date()));
        lvHomepageReviews=findViewById(R.id.lvHomepageReviews);
        tripDetail3List = new ArrayList<>();

        tripDetail3Adapter = new TripDetail3Adapter(HomepageActivity.this, R.layout.lvtripdetails3reviews);
        lvHomepageReviews.setAdapter(tripDetail3Adapter);
        rvHomepageSearch=findViewById(R.id.rvHomepageSearch);
        searchHistoryAdapter=new SearchHistoryAdapter(HomepageActivity.this,searchHistoryArrayList );
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        rvHomepageSearch.setLayoutManager(linearLayoutManager);
        rvHomepageSearch.setAdapter(searchHistoryAdapter);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isReturnDone",false);
        editor.putBoolean("isReturn",false);
        editor.apply();

        loadData();
    }

    public static void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            return;
        }

        int totalHeight = 0;
        int dividerHeight = listView.getDividerHeight();
        int additionalSpacing = 4; // 4 pixels spacing

        for (int i = 0; i < listAdapter.getCount(); i++) {
            View listItem = listAdapter.getView(i, null, listView);
            listItem.measure(
                    View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.AT_MOST),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            );
            totalHeight += listItem.getMeasuredHeight() + dividerHeight + additionalSpacing;
        }

        // Subtract additional spacing after the last item, as it's unnecessary
        totalHeight -= additionalSpacing;

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight;
        listView.setLayoutParams(params);
        listView.requestLayout();
    }


    private void loadData() {
        // Show the ProgressDialog
        progressDialog.show();

        selectedTicket = MySharedPreferences.getObject(HomepageActivity.this,"SelectedTicket", Ticket.class);

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String RouteId = sharedPreferences.getString("RouteId","");

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Feedback");
        ArrayList<String> FeedbackList = new ArrayList<>();
        if (selectedTicket != null) {
            FeedbackList = selectedTicket.getReviews();
        }

        ArrayList<String> finalFeedbackList = FeedbackList;
        myRef.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    Long destination = data.child("Destination").getValue(Long.class);
                    Long totalTrip = data.child("TotalTrip").getValue(Long.class);
                    Long rating = data.child("Rating").getValue(Long.class);
                    if (destination != null && totalTrip != null && rating != null) {
                        String avatar = data.child("Avatar").getValue(String.class);
                        String customerName = data.child("CustomerName").getValue(String.class);
                        String date = data.child("Date").getValue(String.class);
                        String feedback = data.child("Feedback").getValue(String.class);

                        ArrayList<String> Images = new ArrayList<>();
                        for (DataSnapshot subData: data.child("Image").getChildren()) {
                            String Str = subData.getValue(String.class);
                            Images.add(Str);
                        }

                        // Decode the Base64 string into a byte array


                        TripDetail3 tripDetail3 = new TripDetail3();
                        tripDetail3.setTotalTrip(totalTrip.toString());
                        tripDetail3.setDestination(destination.toString());
                        tripDetail3.setAvatar(convertBase64toBitmap(avatar));
                        tripDetail3.setFeedback(feedback);
                        tripDetail3.setRating(rating.toString());
                        tripDetail3.setCustomerName(customerName);
                        tripDetail3.setDate(date);
                        tripDetail3.setImage(Images);

                        tripDetail3Adapter.add(tripDetail3);
                    }
                }
                tripDetail3Adapter.notifyDataSetChanged(); // Notify the adapter
                setListViewHeightBasedOnChildren(lvHomepageReviews);

                // Dismiss the ProgressDialog when data loading is complete
                progressDialog.dismiss();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "loadPost:onCancelled", error.toException());

                // Dismiss the ProgressDialog if loading is canceled or fails
                progressDialog.dismiss();
            }
        });
    }

    private Bitmap convertBase64toBitmap(String base64String) {
        try {
            // Remove the data URI prefix if present
            String pureBase64Encoded = base64String.split(",")[1];

            // Decode the Base64 string into a byte array
            byte[] decodedBytes = Base64.decode(pureBase64Encoded, Base64.DEFAULT);

            // Convert the byte array into a Bitmap
            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);

            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Return null to indicate failure
        }
    }

    private void safeDismissDialog(ProgressDialog dialog) {
        if (dialog != null && dialog.isShowing()) {
            if (!isFinishing()) {  // Check if activity is not finishing
                dialog.dismiss();
            }
        }
    }

}