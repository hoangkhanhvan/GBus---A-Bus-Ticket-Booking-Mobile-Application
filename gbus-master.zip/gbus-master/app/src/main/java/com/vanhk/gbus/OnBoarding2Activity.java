package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class OnBoarding2Activity extends AppCompatActivity {
    Button btnOnBoarding2Skip, btnOnBoarding2Next;
    ProgressDialog progressDialog; // Declare ProgressDialog

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_on_boarding2);
        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog
        progressDialog.setMessage("Processing...");
        progressDialog.setCancelable(false);
        addViews();
        addEvents();
    }

    private void addEvents() {
        btnOnBoarding2Skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show(); // Show ProgressDialog when skip button is clicked
                processSkip();
            }
        });
        btnOnBoarding2Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show(); // Show ProgressDialog when next button is clicked
                processNext();
            }
        });
    }

    private void processNext() {
        Intent intent=new Intent(OnBoarding2Activity.this, OnBoarding3Activity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        progressDialog.dismiss(); // Dismiss ProgressDialog after starting the next activity
    }

    private void processSkip() {
        Intent intent=new Intent(OnBoarding2Activity.this,LoginActivity.class);
        startActivity(intent);
        progressDialog.dismiss(); // Dismiss ProgressDialog after starting the login activity
    }

    private void addViews() {
        btnOnBoarding2Skip=findViewById(R.id.btnOnBoarding2Skip);
        btnOnBoarding2Next=findViewById(R.id.btnOnBoarding2Next);
    }
}
