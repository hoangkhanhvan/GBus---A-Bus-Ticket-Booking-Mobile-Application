package com.vanhk.gbus.model;

public class Driver {
    private int hours;
    private String license;
    private String name;
    private String phoneNumber;
    private int travelTrip;
    private String _id;

    public Driver() {
        // Default constructor required for calls to DataSnapshot.getValue(Driver.class)
    }

    public Driver(int hours, String license, String name, String phoneNumber, int travelTrip, String _id) {
        this.hours = hours;
        this.license = license;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.travelTrip = travelTrip;
        this._id = _id;
    }

    public int getHours() {
        return hours;
    }

    public String getLicense() {
        return license;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public int getTravelTrip() {
        return travelTrip;
    }

    public String getId() {
        return _id;
    }
}