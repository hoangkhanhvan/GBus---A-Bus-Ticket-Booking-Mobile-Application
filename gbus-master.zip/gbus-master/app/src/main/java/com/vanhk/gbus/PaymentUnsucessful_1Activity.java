package com.vanhk.gbus;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class PaymentUnsucessful_1Activity extends AppCompatActivity {
    TextView txtFailure;
    TextView txtPaymentUnsuccessfulReason;
    TextView txtPaymentUnsuccessfulTimestamp;
    TextView txtPaymentUnsuccessfulPaymentMethod;
    TextView txtPaymentUnsuccessfulTransactionNo;
    Button btnPaymentUnsuccessfulRetry;
    Button btnPaymentUnsuccessfulBackToHomepage;
    Button btnPaymentUnsuccessfulTellUs;
    ProgressDialog progressDialog; // Declare ProgressDialog variable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_unsucessful1);
        addViews();

        // Initialize the progressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Retrying..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable


        // Initialize the toolbarBack

        // Set navigation icon click listener


        //Button Retry
        btnPaymentUnsuccessfulRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show(); // Show the ProgressDialog
                // Simulate retrying process for 2 seconds
                new android.os.Handler().postDelayed(
                        new Runnable() {
                            public void run() {
                                Intent intent = new Intent(PaymentUnsucessful_1Activity.this, Payment1Activity.class);
                                startActivity(intent);
                            }
                        },
                        2000
                );

//                // Inflate the dialog layout
//                LayoutInflater inflater = LayoutInflater.from(PaymentUnsucessful_1Activity.this);
//                View dialogView = inflater.inflate(R.layout.unsuccess_dialog, null);
//
//                // Create the dialog
//                AlertDialog.Builder builder = new AlertDialog.Builder(PaymentUnsucessful_1Activity.this);
//                builder.setView(dialogView);
//                AlertDialog dialog = builder.create();
//
//                // Show the dialog
//                dialog.show();
            }
        });

        //Button back2Homepage
        btnPaymentUnsuccessfulBackToHomepage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();
            }
        });

    }

    private void openDialog() {
        final Dialog dialog = new Dialog(PaymentUnsucessful_1Activity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.unsuccess_dialog);

        Window window = dialog.getWindow();
        if (window == null) {
            return;
        }

        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.copyFrom(window.getAttributes());
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        layoutParams.gravity = Gravity.BOTTOM;
        layoutParams.horizontalMargin = 0;

        window.setAttributes(layoutParams);

        dialog.setCancelable(true);

        Button btnViewBookingHistory = dialog.findViewById(R.id.btnUnsuccessfulDialogViewBookingHistory);
        Button btnViewPaymentGuideline = dialog.findViewById(R.id.btnUnsuccessfulDialogViewPaymentGuideline);

        btnViewBookingHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PaymentUnsucessful_1Activity.this, UnpaidTicketActivity.class);
                startActivity(intent);
            }
        });

        btnViewPaymentGuideline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PaymentUnsucessful_1Activity.this, PaymentGuidelineActivity.class);
                startActivity(intent);
            }
        });

        dialog.show();
    }

    private void addViews() {
        txtFailure = findViewById(R.id.txtFailure);
        txtPaymentUnsuccessfulReason = findViewById(R.id.txtPaymentUnsuccessfulReason);
        txtPaymentUnsuccessfulTimestamp = findViewById(R.id.txtPaymentUnsuccessfulTimestamp);
        txtPaymentUnsuccessfulPaymentMethod = findViewById(R.id.txtPaymentUnsuccessfulPaymentMethod);
        txtPaymentUnsuccessfulTransactionNo = findViewById(R.id.txtPaymentUnsuccessfulTransactionNo);
        btnPaymentUnsuccessfulRetry = findViewById(R.id.btnPaymentUnsuccessfulRetry);
        btnPaymentUnsuccessfulBackToHomepage = findViewById(R.id.btnPaymentUnsuccessfulBackToHomepage);
        btnPaymentUnsuccessfulTellUs = findViewById(R.id.btnPaymentUnsuccessfulTellUs);
    }

//    public void processBookingHistory(View view) {
//        Intent intent = new Intent(this, TicketHistoryActivity.class);
//        startActivity(intent);
//
//        finish();
//    }
//
//    public void processPayGuideline(View view) {
//        Intent intent = new Intent(this, PaymentGuidelineActivity.class);
//        startActivity(intent);
//
//        finish();
//    }
}
