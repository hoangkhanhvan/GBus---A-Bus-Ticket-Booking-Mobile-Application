package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class ForgotPassword_3Activity extends AppCompatActivity {

    EditText edtForgotPassword3NewPassword, edtForgotPassword3ConfirmPassword;
    Button btnForgotPassword3Next;
    Toolbar toolbarBack;
    ProgressDialog progressDialog; // Declare ProgressDialog
    FirebaseDatabase database;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password3);
        addViews();
        addEvents();

        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog
    }

    private void addEvents() {
        toolbarBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btnForgotPassword3Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.setMessage("Checking passwords..."); // Set message for ProgressDialog
                progressDialog.show(); // Show ProgressDialog
                checkPasswords();
            }
        });

        // Listen for changes in EditTexts
        edtForgotPassword3NewPassword.addTextChangedListener(textWatcher);
        edtForgotPassword3ConfirmPassword.addTextChangedListener(textWatcher);
    }

    private void addViews() {
        edtForgotPassword3NewPassword = findViewById(R.id.edtForgotPassword3NewPassword);
        edtForgotPassword3ConfirmPassword = findViewById(R.id.edtForgotPassword3ConfirmPassword);
        btnForgotPassword3Next = findViewById(R.id.btnForgotPassword3Next);
        toolbarBack = findViewById(R.id.toolbarBack);

        btnForgotPassword3Next.setEnabled(false);
    }

    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {}

        @Override
        public void afterTextChanged(Editable s) {
            // Check if both EditTexts have content
            if (!edtForgotPassword3NewPassword.getText().toString().isEmpty() &&
                    !edtForgotPassword3ConfirmPassword.getText().toString().isEmpty()) {
                // Enable btnNext
                btnForgotPassword3Next.setEnabled(true);
            } else {
                btnForgotPassword3Next.setEnabled(false);
            }
        }
    };

    private void checkPasswords() {
        String newPassword = edtForgotPassword3NewPassword.getText().toString().trim();
        String confirmPassword = edtForgotPassword3ConfirmPassword.getText().toString().trim();

        if (newPassword.isEmpty()) {
            Toast.makeText(this, "Please input your password", Toast.LENGTH_SHORT).show();
            progressDialog.dismiss();
        } else if (newPassword.length() < 8) {
            Toast.makeText(this, "Password must have at lease 8 characters", Toast.LENGTH_SHORT).show();
            progressDialog.dismiss();
        } else {
            if (newPassword.equals(confirmPassword)) {
                progressDialog.dismiss(); // Dismiss ProgressDialog
                saveAccount(newPassword);
                Intent intent = new Intent(this, HomepageActivity.class);
                Toast.makeText(this, "Passwords match", Toast.LENGTH_SHORT).show();
            } else {
                progressDialog.dismiss(); // Dismiss ProgressDialog
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            }
        }


    }
    private void saveAccount(String password) {
        database = FirebaseDatabase.getInstance();
        reference = database.getReference("account");
        Map<String, Object> userData = new HashMap<>();
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String email = sharedPreferences.getString("Email","");
        userData.put("accountUserName",email);
        userData.put("accountPassword",password);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot data: snapshot.getChildren()) {
                    String existEmail = data.child("accountUserName").getValue(String.class);
                    if (existEmail != null && existEmail.equals(email)) {
                        String key = data.getKey();
                        reference.child(key).child("accountPassword").setValue(password).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putString("accountId",key);
                                editor.apply();
                                Intent intent = new Intent(ForgotPassword_3Activity.this, HomepageActivity.class);
                                startActivity(intent);
                            }
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        progressDialog.dismiss();
    }
}
