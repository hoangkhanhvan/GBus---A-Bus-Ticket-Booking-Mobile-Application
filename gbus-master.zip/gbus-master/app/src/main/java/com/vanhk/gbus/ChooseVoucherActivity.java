package com.vanhk.gbus;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.EditPoint;
import com.vanhk.gbus.adapter.VoucherAdapter;
import com.vanhk.gbus.adapter.VoucherVerticalAdapter;
import com.vanhk.gbus.model.Point2;
import com.vanhk.gbus.model.Voucher;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class ChooseVoucherActivity extends AppCompatActivity {
    TextView txtChooseVoucherVoucherNumber;
    ImageButton BtnChooseVoucherBack;
    RecyclerView rvChooseVoucher; // Change to RecyclerView
    VoucherVerticalAdapter voucherAdapter;

    // Variable to store the selected route ID
    private String selectedRouteId;
    private ProgressDialog progressDialog; // ProgressDialog instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_voucher);

        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog
        progressDialog.setMessage("Loading Vouchers...");
        progressDialog.setCancelable(false);
        progressDialog.show(); // Show ProgressDialog

        // Add logging to trace the flow
        Log.d(TAG, "onCreate: Initializing views");

        addViews();
        addEvents();

        Log.d(TAG, "onCreate: Views initialized");

        // Initialize RecyclerView and set adapter
        voucherAdapter = new VoucherVerticalAdapter(this, new  ArrayList<>());
        rvChooseVoucher.setLayoutManager(new LinearLayoutManager(this));
        rvChooseVoucher.setAdapter(voucherAdapter);

        loadData(); // Load data after initializing views and adapter
        BtnChooseVoucherBack.setOnClickListener(v -> onBackPressed());
    }

    private void addEvents() {
        rvChooseVoucher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onVoucherSelected();
            }
        });
    }

    private void onVoucherSelected() {

    }


    private void loadData() {

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Vouchers");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                String totalPrice = sharedPreferences.getString("DTotalPrice", "0");
                //list filtered vouchers
                ArrayList<Voucher> filteredVouchers = new ArrayList<>();

                int voucherCount = 0;
                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    String id = data.child("id").getValue(String.class);
                    if (id != null) {
                        Voucher voucher = new Voucher();
                        voucher.setDescription(data.child("description").getValue(String.class));
                        voucher.setPercentage(data.child("percentage").getValue(String.class));
                        voucher.setCondition(data.child("condition").getValue(String.class));
                        voucher.setExpired((data.child("expired").getValue(String.class)));
                        voucher.setId(data.getKey());

                        Long amount = data.child("amount").getValue(Long.class);

                        // Lấy giá trị condition_value từ Firebase và gán vào voucher
                        Long conditionValueStr = data.child("condition_value").getValue(Long.class);
                        if (conditionValueStr != null) {
                            int conditionValue = conditionValueStr.intValue();
                            voucher.setConditionValue(conditionValue);
                        }

                        Long value = data.child("condition_value").getValue(Long.class);
                        if (value != null) {
                            voucher.setConditionValue(value.intValue());
                        }
                        // Assuming image is stored as a base64 string
                        String imageBase64 = data.child("image").getValue(String.class);
                        if (imageBase64 != null) {
                            voucher.setImage(imageBase64);
                        }
                        // Kiểm tra điều kiện của voucher và tổng giá trị đặt vé
                        if (checkVoucherCondition(voucher, totalPrice)) {
                            // Nếu voucher phù hợp với điều kiện, thêm vào danh sách đã lọc
                            filteredVouchers.add(voucher);
                        }

                        if (amount != null && amount.intValue() > 0) {
                            voucherAdapter.add(voucher);
                            voucherCount++;
                        }
                    }
                }

                txtChooseVoucherVoucherNumber.setText("("+voucherCount+")");
                progressDialog.dismiss(); // Dismiss ProgressDialog after loading data
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e(TAG, "loadData:onCancelled", databaseError.toException());
                progressDialog.dismiss(); // Dismiss ProgressDialog in case of error
            }
        });
    }

    private boolean checkVoucherCondition(Voucher voucher, String totalPrice) {
        int conditionValue = voucher.getConditionValue();
        int totalOrderValue = Integer.parseInt(totalPrice);

        // So sánh giá trị đơn hàng với condition_value của voucher
        return totalOrderValue <= conditionValue;
    }


    private void addViews() {
        BtnChooseVoucherBack = findViewById(R.id.BtnChooseVoucherBack);
        // Change to RecyclerView
        rvChooseVoucher = findViewById(R.id.rvChooseVoucher);
        // Set layout manager for RecyclerView
        rvChooseVoucher.setLayoutManager(new LinearLayoutManager(this));
        txtChooseVoucherVoucherNumber=findViewById(R.id.txtChooseVoucherVoucherNumber);

    }



    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, Payment1Activity.class);
        startActivity(intent);
        finish();
    }

    // Utility methods for calculating date and time
    public static String calculateDate(String dateString, String timeString, int minutesToAdd) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(dateFormat.parse(dateString + " " + timeString));
            calendar.add(Calendar.MINUTE, minutesToAdd);
            SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd/MM");
            return outputDateFormat.format(calendar.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String calculateTime(String timeString, int minutesToAdd) {
        String[] parts = timeString.split(":");
        int hours = Integer.parseInt(parts[0]);
        int minutes = Integer.parseInt(parts[1]);
        int totalMinutes = hours * 60 + minutes + minutesToAdd;
        int newHours = totalMinutes / 60;
        int newMinutes = totalMinutes % 60;
        return String.format("%02d:%02d", newHours, newMinutes);
    }
}
