package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.TripDetail5Adapter;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.Ticket;
import com.vanhk.gbus.model.TripDetail3;
import com.vanhk.gbus.model.TripDetail4;
import com.vanhk.gbus.model.TripDetail5;
import com.vanhk.gbus.model.TripDetail52;

import java.util.ArrayList;
import java.util.HashMap;

public class TripDetails5Activity extends AppCompatActivity {
    TextView txtTripDetail5DepartLocation, txtTripDetail5ArrivalLocation, txtTripDetail5Tag, txtTripDetail5Date,
            txtTripDetails5PickupDropoff, txtTripDetails5Amenities;
    TextView txtTripDetails51Sub, txtTripDetails52Sub, txtTripDetails53Sub, txtTripDetails54Sub, txtTripDetails5BusName,
            txtTripDetails51SubDescription;
    LinearLayout txtTripDetails5Reviews;
    ListView lvTripDetails5EmployeeInfo;
    Button btnTripDetail5Book;
    ImageView imgTripDetails5Close, imgTripDetails5Img1, imgTripDetails5Img2, imgTripDetails5Img3;
    String TAG = "FIREBASE";
    TripDetail5Adapter tripDetail5Adapter;
    ArrayList<TripDetail5> tripDetail5List;
    Ticket selectedTicket;

    // Declare ProgressDialog variable
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_details5);
        addViews();
        addEvents();

        // Initialize the progressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable
    }

    private void addEvents() {
        imgTripDetails5Close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TripDetails5Activity.this, ResultList1Activity.class);
                startActivity(intent);
            }
        });
        btnTripDetail5Book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show the ProgressDialog when "Book" button is clicked
                progressDialog.show();

                Intent getIntent = getIntent();
                String accountId = getIntent.getStringExtra("accountId");

                Intent intent = new Intent(TripDetails5Activity.this, ChooseSeat_Depart_1Activity.class);

                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("departureTicketId", selectedTicket.get_id());
                editor.apply();

                ArrayList<String> search = getIntent.getStringArrayListExtra("search");

                intent.putExtra("ticket",selectedTicket);
                intent.putStringArrayListExtra("search",search);
                MySharedPreferences.saveObject(TripDetails5Activity.this, "DTicket", selectedTicket);
                boolean isReturn = sharedPreferences.getBoolean("isReturn",false);
                if (isReturn) {
                    MySharedPreferences.saveObject(TripDetails5Activity.this, "RTicket", selectedTicket);

                } else {
                    MySharedPreferences.saveObject(TripDetails5Activity.this, "DTicket", selectedTicket);

                }

                startActivity(intent);

                // Dismiss the ProgressDialog after starting the new activity
                progressDialog.dismiss();
            }
        });

        txtTripDetails5PickupDropoff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TripDetails5Activity.this, TripDetails1Activity.class);
                startActivity(intent);
            }
        });

        txtTripDetails5Amenities.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TripDetails5Activity.this, TripDetails4Activity.class);
                startActivity(intent);
            }
        });

        txtTripDetails5Reviews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TripDetails5Activity.this, TripDetails3Activity.class);
                startActivity(intent);
            }
        });
    }

    private void addViews() {
        txtTripDetails5PickupDropoff=findViewById(R.id.txtTripDetails5PickupDropoff);
        txtTripDetails5Amenities=findViewById(R.id.txtTripDetails5Amenities);
        txtTripDetails5Reviews=findViewById(R.id.txtTripDetails5Reviews);
        txtTripDetail5DepartLocation = findViewById(R.id.txtTripDetail5DepartLocation);
        txtTripDetail5ArrivalLocation = findViewById(R.id.txtTripDetail5ArrivalLocation);
        txtTripDetail5Tag = findViewById(R.id.txtTripDetail5Tag);
        txtTripDetail5Date = findViewById(R.id.txtTripDetail5Date);
        txtTripDetails51Sub = findViewById(R.id.txtTripDetails51Sub);
        txtTripDetails52Sub = findViewById(R.id.txtTripDetails52Sub);
        txtTripDetails53Sub = findViewById(R.id.txtTripDetails53Sub);
        txtTripDetails54Sub = findViewById(R.id.txtTripDetails54Sub);
        txtTripDetails51SubDescription = findViewById(R.id.txtTripDetails51SubDescription);
        lvTripDetails5EmployeeInfo = findViewById(R.id.lvTripDetails5EmployeeInfo);
        btnTripDetail5Book = findViewById(R.id.btnTripDetail5Book);
        imgTripDetails5Close = findViewById(R.id.imgTripDetails5Close);
        txtTripDetails5BusName = findViewById(R.id.txtTripDetails5BusName);
        imgTripDetails5Img1 = findViewById(R.id.imgTripDetails5Img1);
        imgTripDetails5Img2 = findViewById(R.id.imgTripDetails5Img2);
        imgTripDetails5Img3 = findViewById(R.id.imgTripDetails5Img3);


        tripDetail5List = new ArrayList<>();
        tripDetail5Adapter = new TripDetail5Adapter(TripDetails5Activity.this, R.layout.lvtripdetails5employeeinfo);
        lvTripDetails5EmployeeInfo.setAdapter(tripDetail5Adapter);

        loadData();

    }

    private void loadData() {
        selectedTicket = MySharedPreferences.getObject(TripDetails5Activity.this,"SelectedTicket",Ticket.class);

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String RouteId = sharedPreferences.getString("RouteId","");

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Driver");
        ArrayList<String> DriverList = new ArrayList<>();
        DriverList = selectedTicket.getDriver();

        ArrayList<String> Tags = new ArrayList<>();
        ArrayList<String> finalDriverList = DriverList;
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot data : snapshot.getChildren()) {
                    String _id = data.child("_id").getValue(String.class);
                    for (int i = 0; i < finalDriverList.size(); i++) {
                        if (_id.equals(finalDriverList.get(i))) {
                            Long hours = data.child("Hours").getValue(Long.class);
                            Long travelTrip = data.child("TravelTrip").getValue(Long.class);
                            if (hours != null && travelTrip != null) {
                                String avatar = data.child("Avatar").getValue(String.class);
                                String license = data.child("License").getValue(String.class);
                                String name = data.child("Name").getValue(String.class);
                                String phoneNumber = data.child("PhoneNumber").getValue(String.class);

                                ArrayList<Long> Rating = new ArrayList<>();
                                for (DataSnapshot rating : data.child("Rating").getChildren()) {
                                    Rating.add(rating.getValue(Long.class));
                                }

                                TripDetail5 tripDetail5 = new TripDetail5();
                                tripDetail5.setAvatar(convertBase64toBitmap(avatar));
                                tripDetail5.setLicense(license.toString());
                                tripDetail5.setName(name.toString());
                                tripDetail5.setHours(hours.toString());
                                tripDetail5.setPhoneNumber(phoneNumber.toString());
                                tripDetail5.setTravelTrip(travelTrip.toString());

                                tripDetail5Adapter.add(tripDetail5);
                            }

                        }
                    }

                }
            }

            private Bitmap convertBase64toBitmap(String avatar) {
                try {
                    String pureBase64Encoded = avatar.split(",")[1];
                    byte[] decodedBytes = Base64.decode(pureBase64Encoded, Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);

                    return bitmap;
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        DatabaseReference myRef2 = database.getReference();
        myRef2.child("Bus").addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot data : snapshot.getChildren()) {
                    String _id = data.child("_id").getValue(String.class);
                    assert _id != null;
                    //for (int i = 0; i < Bus.size(); i++) {
                    //if (_id.equals(Bus.get(i))) {
                    String description = data.child("Description").getValue(String.class);
                    txtTripDetails51SubDescription.setText(description);

                    String name = data.child("Name").getValue(String.class);
                    txtTripDetails5BusName.setText(name);

                    String sub1 = data.child("Tag").child("0").child("Text").getValue(String.class);
                    txtTripDetails51Sub.setText(sub1);

                    String sub2 = data.child("Tag").child("1").child("Text").getValue(String.class);
                    txtTripDetails52Sub.setText(sub2);

                    String sub3 = data.child("Tag").child("2").child("Text").getValue(String.class);
                    txtTripDetails53Sub.setText(sub3);

                    String sub4 = data.child("Tag").child("3").child("Text").getValue(String.class);
                    txtTripDetails54Sub.setText(sub4);



                    ArrayList<String> Image = new ArrayList<>();
                    for (DataSnapshot subData: data.child("Image").getChildren()) {
                        String Str = subData.getValue(String.class);
                        Image.add(Str);
                    }
                    if (Image.size() >= 3) {
                        imgTripDetails5Img1.setImageBitmap(convertBase64toBitmap(Image.get(0)));
                        imgTripDetails5Img2.setImageBitmap(convertBase64toBitmap(Image.get(1)));
                        imgTripDetails5Img3.setImageBitmap(convertBase64toBitmap(Image.get(2)));
                    } else {

                    }
                    //String image = data.child("Image").getValue(String.class);
//                    imgTripDetails5Img1.setImageBitmap(convertBase64toBitmap(String.valueOf(Image)));
//                    imgTripDetails5Img2.setImageBitmap(convertBase64toBitmap(String.valueOf(Image)));
//                    imgTripDetails5Img3.setImageBitmap(convertBase64toBitmap(String.valueOf(Image)));


                }
            }

            private Bitmap convertBase64toBitmap(String base64String) {
                try {
                    String pureBase64Encoded = base64String.split(",")[1];
                    byte[] decodedBytes = Base64.decode(pureBase64Encoded, Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
                    return bitmap;
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}