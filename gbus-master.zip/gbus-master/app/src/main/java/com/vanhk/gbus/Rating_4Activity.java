package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.TextView;

public class Rating_4Activity extends AppCompatActivity {

    RatingBar ratingBar4;
    ImageButton btnRating4AddImg, btnRating4AddVideo;
    EditText edtRating4RatingDetails;
    TextView txtRating4NumofWord;
    Intent previousIntent=null;

    Button btnRating3Send;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating4);
        addViews();
        addEvents();
    }

    private void addEvents() {
    }

    private void addViews() {
        
    }
}