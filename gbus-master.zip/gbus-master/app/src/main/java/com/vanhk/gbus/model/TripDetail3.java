package com.vanhk.gbus.model;


import android.graphics.Bitmap;


import java.util.ArrayList;


public class TripDetail3 {
    private Bitmap Avatar;
    private String CustomerName;
    private String Date;
    private String Destination;
    private String Feedback;
    private String Rating;
    private String _id;
    private String TotalTrip;
    private ArrayList<String> Image;

    public TripDetail3() {
    }

    public TripDetail3(Bitmap avatar, String customerName, String date, String destination, String feedback, String rating, String _id, String totalTrip, ArrayList<String> image) {
        Avatar = avatar;
        CustomerName = customerName;
        Date = date;
        Destination = destination;
        Feedback = feedback;
        Rating = rating;
        this._id = _id;
        TotalTrip = totalTrip;
        Image = image;
    }


    public Bitmap getAvatar() {
        return Avatar;
    }


    public void setAvatar(Bitmap avatar) {
        Avatar = avatar;
    }


    public String getCustomerName() {
        return CustomerName;
    }


    public void setCustomerName(String customerName) {
        CustomerName = customerName;
    }


    public String getDate() {
        return Date;
    }


    public void setDate(String date) {
        Date = date;
    }


    public String getDestination() {
        return Destination;
    }


    public void setDestination(String destination) {
        Destination = destination;
    }


    public String getFeedback() {
        return Feedback;
    }


    public void setFeedback(String feedback) {
        Feedback = feedback;
    }


    public String getRating() {
        return Rating;
    }


    public void setRating(String rating) {
        Rating = rating;
    }


    public String get_id() {
        return _id;
    }


    public void set_id(String _id) {
        this._id = _id;
    }


    public String getTotalTrip() {
        return TotalTrip;
    }


    public void setTotalTrip(String totalTrip) {
        TotalTrip = totalTrip;
    }


    public ArrayList<String> getImage() {
        return Image;
    }


    public void setImage(ArrayList<String> image) {
        Image = image;
    }
}
