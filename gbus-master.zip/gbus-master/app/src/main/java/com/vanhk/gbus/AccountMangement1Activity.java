package com.vanhk.gbus;

import static com.vanhk.gbus.ViewInvoice_UpcomingActivity.CALL_PHONE_PERMISSION_REQUEST_CODE;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AccountMangement1Activity extends AppCompatActivity {

    private static final int CALL_PHONE_PERMISSION_REQUEST_CODE = 101;
    private TextView txtUserName, txtAccountManagement1PhoneNumber;
    private ImageView imgAvatar;
    private ProgressDialog progressDialog;

    private String hotlinePhoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_mangement1);

        addViews();

        // Set click listener for the search image view
        ImageView searchImageView = findViewById(R.id.imagesearch);
        searchImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AccountMangement1Activity.this, HomepageActivity.class);
                startActivity(intent);
                finish();
            }
        });

        // Set click listener for the "Change" button
        Button changeButton = findViewById(R.id.btnAccountManagement1Change);
        changeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AccountMangement1Activity.this, AccountManagement2Activity.class);
                startActivity(intent);
            }
        });

        // Set click listener for the article image view
        ImageView imageArticle = findViewById(R.id.imagearticle);
        imageArticle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create Intent to navigate to the History Ticket screen
                Intent intent = new Intent(AccountMangement1Activity.this, UnpaidTicketActivity.class);
                startActivity(intent);
                finish();
            }
        });

        // Set click listener for the notifications image view
        ImageView imgNotifications = findViewById(R.id.imgnotifications);
        imgNotifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create Intent to navigate to the Notification screen
                Intent intent = new Intent(AccountMangement1Activity.this, NotificationsActivity.class);
                startActivity(intent);
                finish();
            }
        });

        txtAccountManagement1PhoneNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkingPermission(hotlinePhoneNumber);
                if (txtAccountManagement1PhoneNumber != null) {
                    showCallConfirmationDialog(hotlinePhoneNumber);
                } else {
                    // Show a toast message indicating that the driver's phone number is not available
                    Toast.makeText(AccountMangement1Activity.this, "Hotline is no longer available", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void addViews() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);

        // Initialize views
        txtUserName = findViewById(R.id.txtAccountManagement1UserName);
        imgAvatar = findViewById(R.id.imgAccountManagement1Ava);
        txtAccountManagement1PhoneNumber=findViewById(R.id.txtAccountManagement1PhoneNumber);



        // Retrieve accountId from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        String accountId = sharedPreferences.getString("accountId", "default_account_id");

        // Connect to Firebase Realtime Database and query user data
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference userRef = database.getReference("account").child(accountId);

        // Show progress dialog before querying data

        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                try {
                    // Retrieve data from Firebase
                    String userName = dataSnapshot.child("userInfo").child("account_name").getValue(String.class);
                    String avatarBase64 = dataSnapshot.child("userInfo").child("account_image").getValue(String.class);

                    // Display data on the UI
                    if (userName != null) {
                        txtUserName.setText(userName);
                    } else {
                        String accountUserName = dataSnapshot.child("accountUserName").getValue(String.class);
                        txtUserName.setText(accountUserName);
                    }

                    // Convert Base64 string to Bitmap and display in ImageView
                    if (avatarBase64 != null) {
                        byte[] decodedString = Base64.decode(avatarBase64, Base64.DEFAULT);
                        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                        imgAvatar.setImageBitmap(decodedByte);
                    }

                    // Dismiss progress dialog after data retrieval is complete
                    progressDialog.dismiss();
                    safeDismissDialog(progressDialog);
                } finally {
                    progressDialog.dismiss();
                }

            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle errors
                Log.e("AccountManagement1", "Failed to read user data.", databaseError.toException());
                // Dismiss progress dialog on error
                progressDialog.dismiss();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        addViews();
    }

    private void checkingPermission(String hotlinePhoneNumber) {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            // Request the permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, CALL_PHONE_PERMISSION_REQUEST_CODE);
        } else {
            // Permission already granted, proceed with making the call
            showCallConfirmationDialog(hotlinePhoneNumber);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CALL_PHONE_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed with making the call
            } else {
                // Permission denied, show a message or take appropriate action
                Toast.makeText(this, "Permission denied to make phone calls", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showCallConfirmationDialog(final String hotlinePhoneNumber) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Call Hotline?");
        builder.setMessage("Do you want to make a direct call to G-BUS hotline?");
        // YES Button
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                makeDirectCall(hotlinePhoneNumber);
                dialog.dismiss();
            }
        });
        // NO Button
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        // Create an AlertDialog
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(true);

        // Show Dialog
        dialog.show();
    }

    private void makeDirectCall(String driverPhoneNumber) {
        Intent intent = new Intent(Intent.ACTION_CALL);
        Uri uri = Uri.parse("tel:" + hotlinePhoneNumber);
        intent.setData(uri);
        startActivity(intent);
    }

    private void safeDismissDialog(ProgressDialog dialog) {
        if (dialog != null && dialog.isShowing()) {
            if (!isFinishing()) {  // Check if activity is not finishing
                dialog.dismiss();
            }
        }
    }

}
