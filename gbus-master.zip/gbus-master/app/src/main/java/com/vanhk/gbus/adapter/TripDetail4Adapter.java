package com.vanhk.gbus.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.vanhk.gbus.R;
import com.vanhk.gbus.model.TripDetail3;
import com.vanhk.gbus.model.TripDetail4;

public class TripDetail4Adapter extends ArrayAdapter<TripDetail4> {
    Activity context;
    int resource;

    public TripDetail4Adapter(@NonNull Activity context, int resource) {
        super(context, resource);
        this.context=context;
        this.resource=resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = this.context.getLayoutInflater();
        View tripdetail4 = inflater.inflate(this.resource,null);

        ImageView imgTripDetails4Utilities = tripdetail4.findViewById(R.id.imgTripDetails4Utilities);
        TextView txtTripDetails4UtilitiesTitle = tripdetail4.findViewById(R.id.txtTripDetails4UtilitiesTitle);
        TextView txtTripDetails4UtilitiesContent = tripdetail4.findViewById(R.id.txtTripDetails4UtilitiesContent);

        TripDetail4 tripDetail4 = getItem(position);
        imgTripDetails4Utilities.setImageBitmap(tripDetail4.getImage());
        txtTripDetails4UtilitiesTitle.setText(tripDetail4.getTitle());
        txtTripDetails4UtilitiesContent.setText(tripDetail4.getDescription());

        return tripdetail4;
    }
}
