package com.vanhk.gbus.model;

import java.io.Serializable;

public class PassengerInfo implements Serializable {
    private String Name;
    private String Email;
    private String PhoneNumber;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public PassengerInfo() {
    }

    public PassengerInfo(String name, String email, String phoneNumber) {
        Name = name;
        Email = email;
        PhoneNumber = phoneNumber;
    }
}
