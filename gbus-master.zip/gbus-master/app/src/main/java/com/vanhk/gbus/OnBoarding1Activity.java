package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class OnBoarding1Activity extends AppCompatActivity {
    Button btnOnBoarding1Skip, btnOnBoarding1Next;
    ProgressDialog progressDialog; // Declare ProgressDialog

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_on_boarding1);
        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog
        progressDialog.setMessage("Processing...");
        progressDialog.setCancelable(false);
        addViews();
        addEvents();
    }

    private void addEvents() {
        btnOnBoarding1Skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show(); // Show ProgressDialog when skip button is clicked
                processSkip();
            }
        });
        btnOnBoarding1Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show(); // Show ProgressDialog when next button is clicked
                processNext();
            }
        });
    }

    private void processNext() {
        Intent intent=new Intent(OnBoarding1Activity.this, OnBoarding2Activity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        progressDialog.dismiss(); // Dismiss ProgressDialog after starting the next activity
    }

    private void processSkip() {
        Intent intent=new Intent(OnBoarding1Activity.this,LoginActivity.class);
        startActivity(intent);
        progressDialog.dismiss(); // Dismiss ProgressDialog after starting the login activity
    }

    private void addViews() {
        btnOnBoarding1Skip=findViewById(R.id.btnOnBoarding1Skip);
        btnOnBoarding1Next=findViewById(R.id.btnOnBoarding1Next);
    }
}
