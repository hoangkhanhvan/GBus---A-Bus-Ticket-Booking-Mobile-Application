package com.vanhk.gbus.adapter;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.vanhk.gbus.R;
import com.vanhk.gbus.model.PaidTicket;

import java.util.ArrayList;

public class CompleteTicketAdapter extends ArrayAdapter<PaidTicket> {
    Activity context;
    int resource;
    ArrayList<PaidTicket> PaidTickets;
    private OnViewInvoiceClickListener onViewInvoiceClickListener;
    private OnRatingClickListener onRatingClickListener;

    public CompleteTicketAdapter(@NonNull Activity context, int resource, ArrayList<PaidTicket> paidTickets) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
        this.PaidTickets = paidTickets;
    }
    public void setonRatingClickListener(OnRatingClickListener listener) {
        this.onRatingClickListener = listener;
    }
    public void setonViewInvoiceClickListener(OnViewInvoiceClickListener listener) {
        this.onViewInvoiceClickListener = listener;
    }
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = context.getLayoutInflater().inflate(resource, null);

        TextView TicketCompletePrice = view.findViewById(com.vanhk.gbus.R.id.txtTicketCompletePrice);
        TextView TicketCompleteStatus = view.findViewById(com.vanhk.gbus.R.id.txtTicketCompleteStatus);
//        TextView UnpaidTicketDate = view.findViewById(R.id.txtUnpaidTicketDate);
//        TextView UnpaidTicketTimeLeft = view.findViewById(R.id.txtUnpaidTicketTimeLeft);
        TextView TicketCompleteDepartTime = view.findViewById(R.id.txtTicketCompleteDepartTime);
        TextView TicketCompleteDepartDate = view.findViewById(R.id.txtTicketCompleteDepartDate);
        TextView TicketCompleteDepartTitleStart = view.findViewById(R.id.txtTicketCompleteDepartTitleStart);
        TextView TicketCompleteDepartTitleEnd = view.findViewById(R.id.txtTicketCompleteDepartTitleEnd);
        TextView TicketCompleteDepartDescription = view.findViewById(R.id.txtTicketCompleteDepartDescription);
        TextView TicketCompleteDepartNo = view.findViewById(R.id.txtTicketCompleteDepartNo);
        TextView TicketCompleteArrivalTime = view.findViewById(R.id.txtTicketCompleteArrivalTime);
        TextView TicketCompleteArrivalDate = view.findViewById(R.id.txtTicketCompleteArrivalDate);
        TextView TicketCompleteArrivalTitleStart = view.findViewById(R.id.txtTicketCompleteArrivalTitleStart);
        TextView TicketCompleteArrivalTitleEnd = view.findViewById(R.id.txtTicketCompleteArrivalTitleEnd);
        TextView TicketCompleteArrivalDescription = view.findViewById(R.id.txtTicketCompleteArrivalDescription);
        TextView TicketCompleteArrivalNo = view.findViewById(R.id.txtTicketCompleteArrivalNo);
        Button btnTicketCompleteRating = view.findViewById(R.id.btnTicketCompleteRating);
        Button btnTicketCompleteViewInvoice = view.findViewById(R.id.btnTicketCompleteViewInvoice);

        btnTicketCompleteViewInvoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onViewInvoiceClickListener != null) {
                    onViewInvoiceClickListener.onViewInvoiceClick(position);
                }
            }
        });
        btnTicketCompleteRating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onRatingClickListener != null) {
                    onRatingClickListener.onRatingClick(position);
                }
            }
        });

        PaidTicket paidTicket = getItem(position);

        if (paidTicket!=null) {
            TicketCompletePrice.setText(String.valueOf(paidTicket.getDeparture().getTotalPrice()+paidTicket.getReturn().getTotalPrice()));
            TicketCompleteStatus.setText(paidTicket.getStatus());
            //note tính time paid
//            PaidTicketDate.setText(calculateUnPaidTime(unPaidTicket.getBookedTime()));
            //note tính countdown
//            startCountdownTimer(UnpaidTicketTimeLeft, calculateUnPaidTime(unPaidTicket.getBookedTime()), unPaidTicket);
            TicketCompleteDepartTime.setText(paidTicket.getDeparture().getPickUpPoint().getTime());
            TicketCompleteDepartDate.setText(paidTicket.getDeparture().getPickUpPoint().getDateStr());
            TicketCompleteDepartTitleStart.setText(paidTicket.getDeparture().getDLocation());
            TicketCompleteDepartTitleEnd.setText(paidTicket.getDeparture().getALocation());
            TicketCompleteDepartDescription.setText(paidTicket.getDeparture().getBus());
            TicketCompleteDepartNo.setText(paidTicket.getTransactionNumber());
            TicketCompleteArrivalTime.setText(paidTicket.getReturn().getPickUpPoint().getTime());
            TicketCompleteArrivalDate.setText(paidTicket.getReturn().getPickUpPoint().getDateStr());
            TicketCompleteArrivalTitleStart.setText(paidTicket.getReturn().getALocation());
            TicketCompleteArrivalTitleEnd.setText(paidTicket.getReturn().getDLocation());
            TicketCompleteArrivalDescription.setText(paidTicket.getReturn().getBus());
            TicketCompleteArrivalNo.setText(paidTicket.getTransactionNumber());

        }
        return view;
    }
    public interface OnViewInvoiceClickListener {

        void onViewInvoiceClick(int position);
    }
    public interface OnRatingClickListener {

        void onRatingClick(int position);
    }

}
