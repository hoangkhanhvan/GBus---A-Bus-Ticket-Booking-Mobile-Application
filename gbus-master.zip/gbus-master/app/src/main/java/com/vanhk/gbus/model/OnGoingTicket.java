package com.vanhk.gbus.model;

public class OnGoingTicket {
    private String ongoingId;
    private String ongoingCategory;
    private int ongoingTime;
    private String ongoingEmail;

    private String ongoingName;
    private String ongoingPhoneNumber;
    private String ongoingLicenseNumber;
    private String ongoingDriverPhoneNumber1;
    private String ongoingDriverPhoneNumber2;
    private int ongoingPaymentTime;
    private String ongoingTransactionNumber;
    private String ongoingDepartureTrip;
    private String ongoingReturnTrip;
    private String ongoingState;
    private String ongoingBusType;
    private String ongoingTotalTicket;
    private String ongoingDepartureSeatNumber1;
    private String ongoingDepartureSeatNumber2;
    private String ongoingReturnSeatNumber1;
    private String ongoingReturnSeatNumber2;
    private String ongoingDeparturePickUpName;
    private String ongoingDeparturePickUpLocation;
    private String ongoingDeparturePickUpTime;
    private String ongoingDepartureDropOffName;
    private String ongoingDepartureDropOffLocation;
    private String ongoingDepartureDropOffTime;
    private String ongoingReturnPickUpName;
    private String ongoingReturnPickUpLocation;
    private String ongoingReturnPickUpTime;
    private String ongoingReturnDropOffName;
    private String ongoingReturnDropOffLocation;
    private String ongoingReturnDropOffTime;
    private int ongoingTotalTickets;
    private int ongoingSubTotal;
    private int ongoingDiscount;

    public OnGoingTicket(String ongoingId, String ongoingCategory, int ongoingTime, String ongoingEmail, String ongoingName, String ongoingPhoneNumber, String ongoingLicenseNumber, String ongoingDriverPhoneNumber1, String ongoingDriverPhoneNumber2, int ongoingPaymentTime, String ongoingTransactionNumber, String ongoingDepartureTrip, String ongoingReturnTrip, String ongoingState, String ongoingBusType, String ongoingTotalTicket, String ongoingDepartureSeatNumber1, String ongoingDepartureSeatNumber2, String ongoingReturnSeatNumber1, String ongoingReturnSeatNumber2, String ongoingDeparturePickUpName, String ongoingDeparturePickUpLocation, String ongoingDeparturePickUpTime, String ongoingDepartureDropOffName, String ongoingDepartureDropOffLocation, String ongoingDepartureDropOffTime, String ongoingReturnPickUpName, String ongoingReturnPickUpLocation, String ongoingReturnPickUpTime, String ongoingReturnDropOffName, String ongoingReturnDropOffLocation, String ongoingReturnDropOffTime, int ongoingTotalTickets, int ongoingSubTotal, int ongoingDiscount) {
        this.ongoingId = ongoingId;
        this.ongoingCategory = ongoingCategory;
        this.ongoingTime = ongoingTime;
        this.ongoingEmail = ongoingEmail;
        this.ongoingName = ongoingName;
        this.ongoingPhoneNumber = ongoingPhoneNumber;
        this.ongoingLicenseNumber = ongoingLicenseNumber;
        this.ongoingDriverPhoneNumber1 = ongoingDriverPhoneNumber1;
        this.ongoingDriverPhoneNumber2 = ongoingDriverPhoneNumber2;
        this.ongoingPaymentTime = ongoingPaymentTime;
        this.ongoingTransactionNumber = ongoingTransactionNumber;
        this.ongoingDepartureTrip = ongoingDepartureTrip;
        this.ongoingReturnTrip = ongoingReturnTrip;
        this.ongoingState = ongoingState;
        this.ongoingBusType = ongoingBusType;
        this.ongoingTotalTicket = ongoingTotalTicket;
        this.ongoingDepartureSeatNumber1 = ongoingDepartureSeatNumber1;
        this.ongoingDepartureSeatNumber2 = ongoingDepartureSeatNumber2;
        this.ongoingReturnSeatNumber1 = ongoingReturnSeatNumber1;
        this.ongoingReturnSeatNumber2 = ongoingReturnSeatNumber2;
        this.ongoingDeparturePickUpName = ongoingDeparturePickUpName;
        this.ongoingDeparturePickUpLocation = ongoingDeparturePickUpLocation;
        this.ongoingDeparturePickUpTime = ongoingDeparturePickUpTime;
        this.ongoingDepartureDropOffName = ongoingDepartureDropOffName;
        this.ongoingDepartureDropOffLocation = ongoingDepartureDropOffLocation;
        this.ongoingDepartureDropOffTime = ongoingDepartureDropOffTime;
        this.ongoingReturnPickUpName = ongoingReturnPickUpName;
        this.ongoingReturnPickUpLocation = ongoingReturnPickUpLocation;
        this.ongoingReturnPickUpTime = ongoingReturnPickUpTime;
        this.ongoingReturnDropOffName = ongoingReturnDropOffName;
        this.ongoingReturnDropOffLocation = ongoingReturnDropOffLocation;
        this.ongoingReturnDropOffTime = ongoingReturnDropOffTime;
        this.ongoingTotalTickets = ongoingTotalTickets;
        this.ongoingSubTotal = ongoingSubTotal;
        this.ongoingDiscount = ongoingDiscount;
    }

    public OnGoingTicket() {
    }

    public String getOngoingId() {
        return ongoingId;
    }

    public void setOngoingId(String ongoingId) {
        this.ongoingId = ongoingId;
    }

    public String getOngoingCategory() {
        return ongoingCategory;
    }

    public void setOngoingCategory(String ongoingCategory) {
        this.ongoingCategory = ongoingCategory;
    }

    public int getOngoingTime() {
        return ongoingTime;
    }

    public void setOngoingTime(int ongoingTime) {
        this.ongoingTime = ongoingTime;
    }

    public String getOngoingEmail() {
        return ongoingEmail;
    }

    public void setOngoingEmail(String ongoingEmail) {
        this.ongoingEmail = ongoingEmail;
    }

    public String getOngoingName() {
        return ongoingName;
    }

    public void setOngoingName(String ongoingName) {
        this.ongoingName = ongoingName;
    }

    public String getOngoingPhoneNumber() {
        return ongoingPhoneNumber;
    }

    public void setOngoingPhoneNumber(String ongoingPhoneNumber) {
        this.ongoingPhoneNumber = ongoingPhoneNumber;
    }

    public String getOngoingLicenseNumber() {
        return ongoingLicenseNumber;
    }

    public void setOngoingLicenseNumber(String ongoingLicenseNumber) {
        this.ongoingLicenseNumber = ongoingLicenseNumber;
    }

    public String getOngoingDriverPhoneNumber1() {
        return ongoingDriverPhoneNumber1;
    }

    public void setOngoingDriverPhoneNumber1(String ongoingDriverPhoneNumber1) {
        this.ongoingDriverPhoneNumber1 = ongoingDriverPhoneNumber1;
    }

    public String getOngoingDriverPhoneNumber2() {
        return ongoingDriverPhoneNumber2;
    }

    public void setOngoingDriverPhoneNumber2(String ongoingDriverPhoneNumber2) {
        this.ongoingDriverPhoneNumber2 = ongoingDriverPhoneNumber2;
    }

    public int getOngoingPaymentTime() {
        return ongoingPaymentTime;
    }

    public void setOngoingPaymentTime(int ongoingPaymentTime) {
        this.ongoingPaymentTime = ongoingPaymentTime;
    }

    public String getOngoingTransactionNumber() {
        return ongoingTransactionNumber;
    }

    public void setOngoingTransactionNumber(String ongoingTransactionNumber) {
        this.ongoingTransactionNumber = ongoingTransactionNumber;
    }

    public String getOngoingDepartureTrip() {
        return ongoingDepartureTrip;
    }

    public void setOngoingDepartureTrip(String ongoingDepartureTrip) {
        this.ongoingDepartureTrip = ongoingDepartureTrip;
    }

    public String getOngoingReturnTrip() {
        return ongoingReturnTrip;
    }

    public void setOngoingReturnTrip(String ongoingReturnTrip) {
        this.ongoingReturnTrip = ongoingReturnTrip;
    }

    public String getOngoingState() {
        return ongoingState;
    }

    public void setOngoingState(String ongoingState) {
        this.ongoingState = ongoingState;
    }

    public String getOngoingBusType() {
        return ongoingBusType;
    }

    public void setOngoingBusType(String ongoingBusType) {
        this.ongoingBusType = ongoingBusType;
    }

    public String getOngoingTotalTicket() {
        return ongoingTotalTicket;
    }

    public void setOngoingTotalTicket(String ongoingTotalTicket) {
        this.ongoingTotalTicket = ongoingTotalTicket;
    }

    public String getOngoingDepartureSeatNumber1() {
        return ongoingDepartureSeatNumber1;
    }

    public void setOngoingDepartureSeatNumber1(String ongoingDepartureSeatNumber1) {
        this.ongoingDepartureSeatNumber1 = ongoingDepartureSeatNumber1;
    }

    public String getOngoingDepartureSeatNumber2() {
        return ongoingDepartureSeatNumber2;
    }

    public void setOngoingDepartureSeatNumber2(String ongoingDepartureSeatNumber2) {
        this.ongoingDepartureSeatNumber2 = ongoingDepartureSeatNumber2;
    }

    public String getOngoingReturnSeatNumber1() {
        return ongoingReturnSeatNumber1;
    }

    public void setOngoingReturnSeatNumber1(String ongoingReturnSeatNumber1) {
        this.ongoingReturnSeatNumber1 = ongoingReturnSeatNumber1;
    }

    public String getOngoingReturnSeatNumber2() {
        return ongoingReturnSeatNumber2;
    }

    public void setOngoingReturnSeatNumber2(String ongoingReturnSeatNumber2) {
        this.ongoingReturnSeatNumber2 = ongoingReturnSeatNumber2;
    }

    public String getOngoingDeparturePickUpName() {
        return ongoingDeparturePickUpName;
    }

    public void setOngoingDeparturePickUpName(String ongoingDeparturePickUpName) {
        this.ongoingDeparturePickUpName = ongoingDeparturePickUpName;
    }

    public String getOngoingDeparturePickUpLocation() {
        return ongoingDeparturePickUpLocation;
    }

    public void setOngoingDeparturePickUpLocation(String ongoingDeparturePickUpLocation) {
        this.ongoingDeparturePickUpLocation = ongoingDeparturePickUpLocation;
    }

    public String getOngoingDeparturePickUpTime() {
        return ongoingDeparturePickUpTime;
    }

    public void setOngoingDeparturePickUpTime(String ongoingDeparturePickUpTime) {
        this.ongoingDeparturePickUpTime = ongoingDeparturePickUpTime;
    }

    public String getOngoingDepartureDropOffName() {
        return ongoingDepartureDropOffName;
    }

    public void setOngoingDepartureDropOffName(String ongoingDepartureDropOffName) {
        this.ongoingDepartureDropOffName = ongoingDepartureDropOffName;
    }

    public String getOngoingDepartureDropOffLocation() {
        return ongoingDepartureDropOffLocation;
    }

    public void setOngoingDepartureDropOffLocation(String ongoingDepartureDropOffLocation) {
        this.ongoingDepartureDropOffLocation = ongoingDepartureDropOffLocation;
    }

    public String getOngoingDepartureDropOffTime() {
        return ongoingDepartureDropOffTime;
    }

    public void setOngoingDepartureDropOffTime(String ongoingDepartureDropOffTime) {
        this.ongoingDepartureDropOffTime = ongoingDepartureDropOffTime;
    }

    public String getOngoingReturnPickUpName() {
        return ongoingReturnPickUpName;
    }

    public void setOngoingReturnPickUpName(String ongoingReturnPickUpName) {
        this.ongoingReturnPickUpName = ongoingReturnPickUpName;
    }

    public String getOngoingReturnPickUpLocation() {
        return ongoingReturnPickUpLocation;
    }

    public void setOngoingReturnPickUpLocation(String ongoingReturnPickUpLocation) {
        this.ongoingReturnPickUpLocation = ongoingReturnPickUpLocation;
    }

    public String getOngoingReturnPickUpTime() {
        return ongoingReturnPickUpTime;
    }

    public void setOngoingReturnPickUpTime(String ongoingReturnPickUpTime) {
        this.ongoingReturnPickUpTime = ongoingReturnPickUpTime;
    }

    public String getOngoingReturnDropOffName() {
        return ongoingReturnDropOffName;
    }

    public void setOngoingReturnDropOffName(String ongoingReturnDropOffName) {
        this.ongoingReturnDropOffName = ongoingReturnDropOffName;
    }

    public String getOngoingReturnDropOffLocation() {
        return ongoingReturnDropOffLocation;
    }

    public void setOngoingReturnDropOffLocation(String ongoingReturnDropOffLocation) {
        this.ongoingReturnDropOffLocation = ongoingReturnDropOffLocation;
    }

    public String getOngoingReturnDropOffTime() {
        return ongoingReturnDropOffTime;
    }

    public void setOngoingReturnDropOffTime(String ongoingReturnDropOffTime) {
        this.ongoingReturnDropOffTime = ongoingReturnDropOffTime;
    }

    public int getOngoingTotalTickets() {
        return ongoingTotalTickets;
    }

    public void setOngoingTotalTickets(int ongoingTotalTickets) {
        this.ongoingTotalTickets = ongoingTotalTickets;
    }

    public int getOngoingSubTotal() {
        return ongoingSubTotal;
    }

    public void setOngoingSubTotal(int ongoingSubTotal) {
        this.ongoingSubTotal = ongoingSubTotal;
    }

    public int getOngoingDiscount() {
        return ongoingDiscount;
    }

    public void setOngoingDiscount(int ongoingDiscount) {
        this.ongoingDiscount = ongoingDiscount;
    }

    public String getOngoingDriverId() {
        return null;
    }
}
