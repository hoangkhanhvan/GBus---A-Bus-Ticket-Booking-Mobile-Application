package com.vanhk.gbus.model;

import android.graphics.Bitmap;

import java.util.ArrayList;

public class TripDetail52 {
    private ArrayList<String> Image;

    private String Description;
    private String Name;
    private int Seat;
    private ArrayList<String> Tag;
    private String _id;

    public TripDetail52(){

    }

    public TripDetail52(ArrayList<String> image, String description, String name, int seat, ArrayList<String> tag, String _id) {
        Image = image;
        Description = description;
        Name = name;
        Seat = seat;
        Tag = tag;
        this._id = _id;
    }

    public ArrayList<String> getImage() {
        return Image;
    }

    public void setImage(ArrayList<String> image) {
        Image = image;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public int getSeat() {
        return Seat;
    }

    public void setSeat(int seat) {
        Seat = seat;
    }

    public ArrayList<String> getTag() {
        return Tag;
    }

    public void setTag(ArrayList<String> tag) {
        Tag = tag;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }
}
