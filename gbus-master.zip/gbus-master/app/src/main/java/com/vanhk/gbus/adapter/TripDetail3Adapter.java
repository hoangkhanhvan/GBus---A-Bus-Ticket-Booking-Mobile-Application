package com.vanhk.gbus.adapter;


import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;


import com.vanhk.gbus.R;
import com.vanhk.gbus.model.TripDetail3;


public class TripDetail3Adapter extends ArrayAdapter<TripDetail3> {
    Activity context;
    int resource;


    public TripDetail3Adapter(@NonNull Activity context, int resource){
        super(context,resource);
        this.context=context;
        this.resource=resource;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = this.context.getLayoutInflater();
        View tripdetail3 = inflater.inflate(this.resource,null);


        ImageView imgTripDetails3Ava = tripdetail3.findViewById(R.id.imgTripDetails3Ava);
        TextView txtTripDetails3ReviewsName = tripdetail3.findViewById(R.id.txtTripDetails3ReviewsName);
        TextView txtTripDetails3ReviewsRatingStar = tripdetail3.findViewById(R.id.txtTripDetails3ReviewsRatingStar);
        TextView txtTripDetails3ReviewsTotalTripNumber = tripdetail3.findViewById(R.id.txtTripDetails3ReviewsTotalTripNumber);
        TextView txtTripDetails3ReviewsDestinationNumber = tripdetail3.findViewById(R.id.txtTripDetails3ReviewsDestinationNumber);
        TextView txtTripDetails3ReviewsComment = tripdetail3.findViewById(R.id.txtTripDetails3ReviewsComment);
        TextView txtTripDetails3ReviewsDate2 = tripdetail3.findViewById(R.id.txtTripDetails3ReviewsDate2);
        ImageView imgTripDetails3Img1 = tripdetail3.findViewById(R.id.imgTripDetails3Img1);
        ImageView imgTripDetails3Img2 = tripdetail3.findViewById(R.id.imgTripDetails3Img2);
        ImageView imgTripDetails3Img3 = tripdetail3.findViewById(R.id.imgTripDetails3Img3);
        //chưa khai báo hình review. là 1 adapter hay ảnh bth


        TripDetail3 tripDetail3 = getItem(position);
        imgTripDetails3Ava.setImageBitmap(tripDetail3.getAvatar());
        txtTripDetails3ReviewsName.setText(tripDetail3.getCustomerName());
        txtTripDetails3ReviewsRatingStar.setText(tripDetail3.getRating());
        txtTripDetails3ReviewsTotalTripNumber.setText(tripDetail3.getTotalTrip());
        txtTripDetails3ReviewsDestinationNumber.setText(tripDetail3.getDestination());
        //txtTripDetails3ReviewsComment.setText(tripDetail3.getFeedback());
        txtTripDetails3ReviewsDate2.setText(tripDetail3.getDate());
        // Set images from the list
        if (tripDetail3.getImage() != null && tripDetail3.getImage().size() >= 3) {
            // Assuming there are at least 3 images
            imgTripDetails3Img1.setImageBitmap(convertBase64toBitmap(tripDetail3.getImage().get(0)));
            imgTripDetails3Img2.setImageBitmap(convertBase64toBitmap(tripDetail3.getImage().get(1)));
            imgTripDetails3Img3.setImageBitmap(convertBase64toBitmap(tripDetail3.getImage().get(2)));
        }

        return tripdetail3;
    }

    private Bitmap convertBase64toBitmap(String base64String) {
        try {
            // Remove the data URI prefix if present
            String pureBase64Encoded = base64String.split(",")[1];

            // Decode the Base64 string into a byte array
            byte[] decodedBytes = Base64.decode(pureBase64Encoded, Base64.DEFAULT);

            // Convert the byte array into a Bitmap
            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);

            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Return null to indicate failure
        }
    }
}
