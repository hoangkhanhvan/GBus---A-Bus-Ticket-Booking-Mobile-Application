package com.vanhk.gbus.adapter;

public class Booking {
}
