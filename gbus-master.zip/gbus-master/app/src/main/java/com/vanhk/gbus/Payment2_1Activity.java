package com.vanhk.gbus;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.os.Bundle;
import android.telecom.TelecomManager;
import android.util.Base64;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.VoucherAdapter;
import com.vanhk.gbus.model.Voucher;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Payment2_1Activity extends AppCompatActivity implements VoucherAdapter.OnVoucherSelectedListener {
    ImageView imgPayment21Back;
    TextView txtPayment21ViewAllVoucher;
    RecyclerView rvPayment21;
    TextView txtPayment21ViewallPaymentMethod;
    TextView txtPayment21PaymentName;
    TextView txtPayment21PaymentNumber;
    Button btnPayment21EditPayment;
    TextView txtPayment21Policy;
    TextView txtPayment21TermofUse;
    TextView txtPayment21Price;
    TextView txtPayment21DiscountPrice;
    Button btnPayment21Continue;

    LinearLayoutManager linearLayoutManager;

    private String selectedRouteId;
    private VoucherAdapter voucherAdapter;
    int selectedVoucherPosition = -1;

    ProgressDialog progressDialog; // Declare ProgressDialog variable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment21);
        progressDialog = new ProgressDialog(this); // Initialize the ProgressDialog

        // Add logging to trace the flow
        Log.d(TAG, "onCreate: Initializing views");

        addViews();

        Log.d(TAG, "onCreate: Views initialized");

        // Initialize RecyclerView and set adapter
        initRecyclerView();

        //back previous screen
        imgPayment21Back.setOnClickListener(v -> onBackPressed());
        //choose "View all" voucher
        txtPayment21ViewAllVoucher.setOnClickListener(v -> {
            Intent intent = new Intent(this, ChooseVoucherActivity.class);
            startActivity(intent);
        });
        //Choose "View all" payment method
        txtPayment21ViewallPaymentMethod.setOnClickListener(v -> {
            Intent intent = new Intent(this, ChoosePaymentMethodActivity.class);
            startActivity(intent);
        });
        // Navigate to PayByEWallet_2Activity
        btnPayment21Continue.setOnClickListener(v -> {
            progressDialog.setMessage("Processing payment..."); // Set message for the ProgressDialog
            progressDialog.setCancelable(false); // Make it not cancelable
            progressDialog.show(); // Show the ProgressDialog

            Intent intent = new Intent(this, PayByEWallet_2Activity.class);
            startActivity(intent);
        });
        loadData();
    }

    private void initRecyclerView() {
        voucherAdapter = new VoucherAdapter(new ArrayList<>(), rvPayment21, this);

        linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        rvPayment21.setLayoutManager(linearLayoutManager);
        rvPayment21.setAdapter(voucherAdapter);
    }

    private void addViews() {
        imgPayment21Back = findViewById(R.id.imgPayment21Back);
        txtPayment21ViewAllVoucher = findViewById(R.id. txtPayment21ViewAllVoucher);
        rvPayment21 = findViewById(R.id.rvPayment21);
        txtPayment21ViewallPaymentMethod  = findViewById(R.id.txtPayment21ViewallPaymentMethod);
        txtPayment21PaymentName = findViewById(R.id.txtPayment21PaymentName);
        txtPayment21PaymentNumber = findViewById(R.id.txtPayment21PaymentNumber);
        btnPayment21EditPayment = findViewById(R.id.btnPayment21EditPayment);
        txtPayment21Policy = findViewById(R.id.txtPayment21Policy);
        txtPayment21TermofUse = findViewById(R.id.txtPayment21TermofUse);
        txtPayment21Price = findViewById(R.id.txtPayment21Price);
        txtPayment21DiscountPrice = findViewById(R.id.txtPayment21DiscountPrice);
        btnPayment21Continue = findViewById(R.id.btnPayment21Continue);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, BookingPreview2Activity.class);
        startActivity(intent);
        finish();
    }
    private void loadData() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Vouchers");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                String totalPrice = sharedPreferences.getString("DTotalPrice", "0");
                //list filtered vouchers
                ArrayList<Voucher> filteredVouchers = new ArrayList<>();

                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    String id = data.child("id").getValue(String.class);
                    if (id != null) {
                        Voucher voucher = new Voucher();
                        voucher.setDescription(data.child("description").getValue(String.class));
                        voucher.setPercentage(data.child("percentage").getValue(String.class));
                        voucher.setCondition(data.child("condition").getValue(String.class));
                        voucher.setExpired((data.child("expired").getValue(String.class)));

                        // Lấy giá trị condition_value từ Firebase và gán vào voucher
                        String conditionValueStr = data.child("condition_value").getValue(String.class);
                        if (conditionValueStr != null) {
                            int conditionValue = Integer.parseInt(conditionValueStr);
                            voucher.setConditionValue(conditionValue);
                        }

                        // Assuming image is stored as a base64 string
                        String imageBase64 = data.child("image").getValue(String.class);
                        if (imageBase64 != null) {
                            voucher.setImage(imageBase64);
                        }

                        // Kiểm tra điều kiện của voucher và tổng giá trị đặt vé
                        if (checkVoucherCondition(voucher, totalPrice)) {
                            // Nếu voucher phù hợp với điều kiện, thêm vào danh sách đã lọc
                            filteredVouchers.add(voucher);
                        }
                    }
                }
                // Hiển thị danh sách voucher đã lọc trên RecyclerView
                voucherAdapter.setVouchers(filteredVouchers);

                if (selectedVoucherPosition != -1) {
                    voucherAdapter.setSelectedPosition(selectedVoucherPosition);
                    voucherAdapter.notifyDataSetChanged();
                }
                progressDialog.dismiss(); // Dismiss the ProgressDialog when loading is complete

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e(TAG, "loadData:onCancelled", databaseError.toException());
                progressDialog.dismiss(); // Dismiss the ProgressDialog if loading is cancelled

            }
        });
    }

    private boolean checkVoucherCondition(Voucher voucher, String totalPrice) {
        int conditionValue = voucher.getConditionValue();
        int totalOrderValue = Integer.parseInt(totalPrice);

        // So sánh giá trị đơn hàng với condition_value của voucher
        return totalOrderValue <= conditionValue;
    }
    // Utility methods for calculating date and time
    public static String calculateDate(String dateString, String timeString, int minutesToAdd) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(dateFormat.parse(dateString + " " + timeString));
            calendar.add(Calendar.MINUTE, minutesToAdd);
            SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd/MM");
            return outputDateFormat.format(calendar.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String calculateTime(String timeString, int minutesToAdd) {
        String[] parts = timeString.split(":");
        int hours = Integer.parseInt(parts[0]);
        int minutes = Integer.parseInt(parts[1]);
        int totalMinutes = hours * 60 + minutes + minutesToAdd;
        int newHours = totalMinutes / 60;
        int newMinutes = totalMinutes % 60;
        return String.format("%02d:%02d", newHours, newMinutes);
    }

    @Override
    public void onVoucherSelected(int position) {

    }
}