package com.vanhk.gbus.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.CountDownTimer;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.vanhk.gbus.ChooseSeat_Depart_1Activity;
import com.vanhk.gbus.HomepageActivity;
import com.vanhk.gbus.R;
import com.vanhk.gbus.ResultList1Activity;
import com.vanhk.gbus.model.CancelTicket;
import com.vanhk.gbus.model.SearchItem;
import com.vanhk.gbus.model.UnPaidTicket;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class CancelTicketAdapter extends ArrayAdapter<CancelTicket> {
    Activity context;
    int resource;
    ArrayList<CancelTicket> CancelTickets;
    private OnRepurchaseClickListener onRepurchaseClickListener;

    public CancelTicketAdapter(@NonNull Activity context, int resource, ArrayList<CancelTicket> cancelTickets) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
        this.CancelTickets = cancelTickets;
    }
    public void setonRepurchaseClickListener(OnRepurchaseClickListener listener) {
        this.onRepurchaseClickListener = listener;
    }

    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = context.getLayoutInflater().inflate(resource, null);

        TextView CancellationPrice = view.findViewById(com.vanhk.gbus.R.id.txtCancellationPrice);
        TextView CancellationDepartureTime = view.findViewById(R.id.txtCancellationDepartureTime);
        TextView CancellationDepartureDate = view.findViewById(R.id.txtCancellationDepartureDate);
        TextView CancellationDepartureStart = view.findViewById(R.id.txtCancellationDepartureStart);
        TextView CancellationDepartureEnd = view.findViewById(R.id.txtCancellationDepartureEnd);
        TextView CancellationDepartureBusType = view.findViewById(R.id.txtCancellationDepartureBusType);
        TextView CancellationDepartureTransactionNumber = view.findViewById(R.id.txtCancellationDepartureTransactionNumber);
        TextView CancellationReturnTime = view.findViewById(R.id.txtCancellationReturnTime);
        TextView CancellationReturnDate = view.findViewById(R.id.txtCancellationReturnDate);
        TextView CancellationReturnStart = view.findViewById(R.id.txtCancellationReturnStart);
        TextView CancellationReturnEnd = view.findViewById(R.id.txtCancellationReturnEnd);
        TextView CancellationReturnBusType= view.findViewById(R.id.txtCancellationReturnBusType);
        TextView CancellationReturnTransactionNumber = view.findViewById(R.id.txtCancellationReturnTransactionNumber);
        Button btnCancellation = view.findViewById(R.id.btnCancellation);
        LinearLayout llReturn = view.findViewById(R.id.llReturn);

        CancelTicket cancelTickets = getItem(position);

        btnCancellation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onRepurchaseClickListener != null) {
                    Intent intent = new Intent(context, ResultList1Activity.class);

                    SharedPreferences sharedPreferences = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putBoolean("isReturnDone",false);
                    if (cancelTickets.getReturn() != null) {
                        editor.putString("RDate", cancelTickets.getReturn().getTicket().getDate());
                    } else {
                        editor.putString("RDate", "Select Return Date");
                    }

                    editor.putString("DLocation",cancelTickets.getDeparture().getDLocation());
                    editor.putString("ALocation",cancelTickets.getDeparture().getALocation());
                    editor.putString("DDate",cancelTickets.getDeparture().getTicket().getDate());

                    editor.apply();
                    context.startActivity(intent);
                }
            }
        });

        if (cancelTickets!=null) {
            if (cancelTickets.getReturn() != null) {
                CancellationPrice.setText(String.valueOf(cancelTickets.getDeparture().getTotalPrice()+cancelTickets.getReturn().getTotalPrice()));

                CancellationDepartureTime.setText(cancelTickets.getDeparture().getPickUpPoint().getTime());
                CancellationDepartureDate.setText(cancelTickets.getDeparture().getPickUpPoint().getDateStr());
                CancellationDepartureStart.setText(cancelTickets.getDeparture().getDLocation());
                CancellationDepartureEnd.setText(cancelTickets.getDeparture().getALocation());
                CancellationDepartureBusType.setText(cancelTickets.getDeparture().getBus());
                CancellationDepartureTransactionNumber.setText(cancelTickets.getDeparture().getSeat().toString());
                CancellationReturnTime.setText(cancelTickets.getReturn().getPickUpPoint().getTime());
                CancellationReturnDate.setText(cancelTickets.getReturn().getPickUpPoint().getDateStr());
                CancellationReturnStart.setText(cancelTickets.getReturn().getDLocation());
                CancellationReturnEnd.setText(cancelTickets.getReturn().getALocation());
                CancellationReturnBusType.setText(cancelTickets.getReturn().getBus());
                CancellationReturnTransactionNumber.setText(cancelTickets.getReturn().getSeat().toString());
            } else {
                llReturn.setVisibility(View.GONE);
                CancellationPrice.setText(String.valueOf(cancelTickets.getDeparture().getTotalPrice()));

                CancellationDepartureTime.setText(cancelTickets.getDeparture().getPickUpPoint().getTime());
                CancellationDepartureDate.setText(cancelTickets.getDeparture().getPickUpPoint().getDateStr());
                CancellationDepartureStart.setText(cancelTickets.getDeparture().getDLocation());
                CancellationDepartureEnd.setText(cancelTickets.getDeparture().getALocation());
                CancellationDepartureBusType.setText(cancelTickets.getDeparture().getBus());
                CancellationDepartureTransactionNumber.setText(cancelTickets.getDeparture().getSeat().toString());
            }

        }
        return view;
    }



    public interface OnRepurchaseClickListener {
        void onRepurchaseClick(int position);
    }

}
