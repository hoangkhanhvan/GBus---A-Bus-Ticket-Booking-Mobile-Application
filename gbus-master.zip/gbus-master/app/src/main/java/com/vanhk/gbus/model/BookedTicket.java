package com.vanhk.gbus.model;

public class BookedTicket {
    private String AccountId;
    private String BookedTime;

    public BookedTicket() {
    }

    public String getAccountId() {
        return AccountId;
    }

    public void setAccountId(String accountId) {
        AccountId = accountId;
    }

    public String getBookedTime() {
        return BookedTime;
    }

    public void setBookedTime(String bookedTime) {
        BookedTime = bookedTime;
    }

    public PassengerInfo getPassenger() {
        return Passenger;
    }

    public void setPassenger(PassengerInfo passenger) {
        Passenger = passenger;
    }

    public Booked getDeparture() {
        return Departure;
    }

    public void setDeparture(Booked departure) {
        Departure = departure;
    }

    public Booked getReturn() {
        return Return;
    }

    public void setReturn(Booked aReturn) {
        Return = aReturn;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    private PassengerInfo Passenger;
    private Booked Departure;

    public BookedTicket(String accountId, String bookedTime, PassengerInfo passenger, Booked departure, Booked aReturn, String status) {
        AccountId = accountId;
        BookedTime = bookedTime;
        Passenger = passenger;
        Departure = departure;
        Return = aReturn;
        Status = status;
    }

    private Booked Return;
    private String Status;

}
