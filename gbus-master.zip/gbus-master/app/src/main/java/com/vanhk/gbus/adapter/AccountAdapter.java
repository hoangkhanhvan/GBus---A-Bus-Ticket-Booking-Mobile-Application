package com.vanhk.gbus.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.vanhk.gbus.R;
import com.vanhk.gbus.model.Account;

public class AccountAdapter extends ArrayAdapter<Account> {
    Activity context;
    int resource;
    public AccountAdapter(@NonNull Activity context, int resource) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
    }
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View account_item=inflater.inflate(resource,null);

//        TextView txtUserName=account_item.findViewById(R.id.txtUserName);
//        TextView txtPassword=account_item.findViewById(R.id.txtPassword);

        Account account=getItem(position);
//        txtUserName.setText(account.getAccountName());
//        txtPassword.setText(account.getAccountPassword());
        

        return account_item;
    }

    public void add(String s) {
    }
}
