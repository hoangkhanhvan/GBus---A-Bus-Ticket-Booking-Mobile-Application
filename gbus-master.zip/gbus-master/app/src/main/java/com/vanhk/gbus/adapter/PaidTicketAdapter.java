package com.vanhk.gbus.adapter;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.Cancellation2Activity;
import com.vanhk.gbus.PaidTicketActivity;
import com.vanhk.gbus.R;
import com.vanhk.gbus.UnpaidTicketActivity;
import com.vanhk.gbus.ViewInvoice_CompleteActivity;
import com.vanhk.gbus.ViewInvoice_OngoingActivity;
import com.vanhk.gbus.ViewInvoice_UpcomingActivity;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.PaidTicket;
import com.vanhk.gbus.model.UnPaidTicket;

import java.util.ArrayList;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class PaidTicketAdapter extends ArrayAdapter<PaidTicket> {
    Activity context;
    int resource;
    ArrayList<PaidTicket> PaidTickets;
    private OnPaidTicketClickListener onPaidTicketClickListener;
    private OnCancelClickListener onCancelClickListener;

    public PaidTicketAdapter(@NonNull Activity context, int resource, ArrayList<PaidTicket> paidTickets) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
        this.PaidTickets = paidTickets;
    }
    public void setonPaidTicketClickListener(OnPaidTicketClickListener listener) {
        this.onPaidTicketClickListener = listener;
    }
    public void setonCancelClickListener(OnCancelClickListener listener) {
        this.onCancelClickListener = listener;
    }
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = context.getLayoutInflater().inflate(resource, null);

        TextView txtPaidTicketUpComing=view.findViewById(R.id.txtPaidTicketUpComing);
        TextView TicketUpcomingPrice = view.findViewById(com.vanhk.gbus.R.id.txtTicketUpcomingPrice);
        TextView TicketUpcomingStatus = view.findViewById(com.vanhk.gbus.R.id.txtTicketUpcomingStatus);
        TextView TicketUpcomingDate = view.findViewById(com.vanhk.gbus.R.id.txtTicketUpcomingDate);
        TextView TicketUpcomingDepartTime = view.findViewById(com.vanhk.gbus.R.id.txtTicketUpcomingDepartTime);
        TextView TicketUpcomingDepartDate = view.findViewById(com.vanhk.gbus.R.id.txtTicketUpcomingDepartDate);
        TextView TicketUpcomingDepartTitleStart = view.findViewById(com.vanhk.gbus.R.id.txtTicketUpcomingDepartTitleStart);
        TextView TicketUpcomingDepartTitleEnd = view.findViewById(com.vanhk.gbus.R.id.txtTicketUpcomingDepartTitleEnd);
        TextView TicketUpcomingDepartDescription = view.findViewById(com.vanhk.gbus.R.id.txtTicketUpcomingDepartDescription);
        TextView TicketUpcomingDepartNo = view.findViewById(com.vanhk.gbus.R.id.txtTicketUpcomingDepartNo);
        TextView TicketUpcomingReturnTime = view.findViewById(com.vanhk.gbus.R.id.txtTicketUpcomingReturnTime);
        TextView TicketUpcomingReturnDate = view.findViewById(com.vanhk.gbus.R.id.txtTicketUpcomingReturnDate);
        TextView TicketUpcomingArrivalTitleStart = view.findViewById(com.vanhk.gbus.R.id.txtTicketUpcomingArrivalTitleStart);
        TextView TicketUpcomingArrivalTitleEnd = view.findViewById(com.vanhk.gbus.R.id.txtTicketUpcomingArrivalTitleEnd);
        TextView TicketUpcomingArrivalDescription = view.findViewById(com.vanhk.gbus.R.id.txtTicketUpcomingArrivalDescription);
        TextView TicketUpcomingArrivalNo = view.findViewById(com.vanhk.gbus.R.id.txtTicketUpcomingArrivalNo);
        Button btnTicketUpcomingCancel = view.findViewById(com.vanhk.gbus.R.id.btnTicketUpcomingCancel);
        Button btnTicketUpcomingViewInvoice = view.findViewById(com.vanhk.gbus.R.id.btnTicketUpcomingViewInvoice);

        LinearLayout llReturn = view.findViewById(R.id.llReturn);
        SharedPreferences sharedPreferences = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();


        PaidTicket paidTicket = getItem(position);
        btnTicketUpcomingCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog(paidTicket, position);
            }
        });
        btnTicketUpcomingViewInvoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putString("BookedTicketId",paidTicket.get_id());
                editor.apply();
                Toast.makeText(context, paidTicket.get_id(), Toast.LENGTH_SHORT).show();
                String status = calculateTimeStatus(paidTicket.getDeparture().getTicket().getDTime(), paidTicket.getDeparture().getTicket().getATime(), paidTicket.getDeparture().getTicket().getDate());
                Intent intent = new Intent(context, ViewInvoice_UpcomingActivity.class);
                context.startActivity(intent);
            }
        });
        if (paidTicket!=null) {
            if (paidTicket.getReturn() != null) {
                TicketUpcomingPrice.setText(String.valueOf(paidTicket.getDeparture().getTotalPrice()+paidTicket.getReturn().getTotalPrice()));

                //note tính time paid
//            PaidTicket.setText(calculateUnPaidTime(unPaidTicket.getBookedTime()));
                //note tính countdown
//            startCountdownTimer(UnpaidTicketTimeLeft, calculateUnPaidTime(unPaidTicket.getBookedTime()), unPaidTicket);
                TicketUpcomingDepartTime.setText(paidTicket.getDeparture().getPickUpPoint().getTime());
                TicketUpcomingDepartDate.setText(paidTicket.getDeparture().getPickUpPoint().getDateStr());
                TicketUpcomingDepartTitleStart.setText(paidTicket.getDeparture().getDLocation());
                TicketUpcomingDepartTitleEnd.setText(paidTicket.getDeparture().getALocation());
                TicketUpcomingDepartDescription.setText(paidTicket.getDeparture().getBus());
                TicketUpcomingDepartNo.setText(paidTicket.getDeparture().getSeat().toString());
                TicketUpcomingReturnTime.setText(paidTicket.getReturn().getPickUpPoint().getTime());
                TicketUpcomingReturnDate.setText(paidTicket.getReturn().getPickUpPoint().getDateStr());
                TicketUpcomingArrivalTitleStart.setText(paidTicket.getReturn().getDLocation());
                TicketUpcomingArrivalTitleEnd.setText(paidTicket.getReturn().getALocation());
                TicketUpcomingArrivalDescription.setText(paidTicket.getReturn().getBus());
                TicketUpcomingArrivalNo.setText(paidTicket.getReturn().getSeat().toString());
                String status = calculateTimeStatus(paidTicket.getDeparture().getTicket().getDTime(), paidTicket.getDeparture().getTicket().getATime(), paidTicket.getDeparture().getTicket().getDate());
                if (status.equals("Upcoming")) {
                    TicketUpcomingStatus.setText("Upcoming");
                    TicketUpcomingStatus.setTextColor(Color.parseColor("#4D2E00"));
                    TicketUpcomingStatus.setBackgroundColor(Color.parseColor("#FFDDB5"));
                    startCountdownTimer(TicketUpcomingDate, paidTicket.getDeparture().getTicket().getDTime(),
                            paidTicket.getDeparture().getTicket().getDate(),true);
                    txtPaidTicketUpComing.setText("Trip will depart in: ");
                } else if (status.equals("Ongoing")) {
                    TicketUpcomingStatus.setText("Ongoing");
                    TicketUpcomingStatus.setTextColor(Color.parseColor("#0D6EFD"));
                    TicketUpcomingStatus.setBackgroundColor(Color.parseColor("#DCECFF"));
                    startCountdownTimer(TicketUpcomingDate, paidTicket.getDeparture().getTicket().getATime(),
                            paidTicket.getDeparture().getTicket().getDate(),false);
                    txtPaidTicketUpComing.setText("Expected drop-off at: ");
                } else if (status.equals("Completed")) {
                    TicketUpcomingStatus.setText("Completed");
                    TicketUpcomingStatus.setTextColor(Color.parseColor("#129C12"));
                    TicketUpcomingStatus.setBackgroundColor(Color.parseColor("#D8F7E0"));
                    btnTicketUpcomingCancel.setVisibility(View.GONE);
                    txtPaidTicketUpComing.setText(paidTicket.getDeparture().getTicket().getATime()+" - "+paidTicket.getDeparture().getTicket().getDate());
                }
            } else {
                TicketUpcomingPrice.setText(String.valueOf(paidTicket.getDeparture().getTotalPrice()));

                llReturn.setVisibility(View.GONE);
                TicketUpcomingDepartTime.setText(paidTicket.getDeparture().getPickUpPoint().getTime());
                TicketUpcomingDepartDate.setText(paidTicket.getDeparture().getPickUpPoint().getDateStr());
                TicketUpcomingDepartTitleStart.setText(paidTicket.getDeparture().getDLocation());
                TicketUpcomingDepartTitleEnd.setText(paidTicket.getDeparture().getALocation());
                TicketUpcomingDepartDescription.setText(paidTicket.getDeparture().getBus());
                TicketUpcomingDepartNo.setText(paidTicket.getDeparture().getSeat().toString());
                String status = calculateTimeStatus(paidTicket.getDeparture().getTicket().getDTime(), paidTicket.getDeparture().getTicket().getATime(), paidTicket.getDeparture().getTicket().getDate());
                if (status.equals("Upcoming")) {
                    TicketUpcomingStatus.setText("Upcoming");
                    TicketUpcomingStatus.setTextColor(Color.parseColor("#4D2E00"));
                    TicketUpcomingStatus.setBackgroundColor(Color.parseColor("#FFDDB5"));
                    startCountdownTimer(TicketUpcomingDate, paidTicket.getDeparture().getTicket().getDTime(),
                            paidTicket.getDeparture().getTicket().getDate(),true);
                    txtPaidTicketUpComing.setText("Trip will depart in: ");
                } else if (status.equals("Ongoing")) {
                    TicketUpcomingStatus.setText("Ongoing");
                    TicketUpcomingStatus.setTextColor(Color.parseColor("#0D6EFD"));
                    TicketUpcomingStatus.setBackgroundColor(Color.parseColor("#DCECFF"));
                    startCountdownTimer(TicketUpcomingDate, paidTicket.getDeparture().getTicket().getATime(),
                            paidTicket.getDeparture().getTicket().getDate(),false);
                    txtPaidTicketUpComing.setText("Expected drop-off at: ");
                } else if (status.equals("Completed")) {
                    TicketUpcomingStatus.setText("Completed");
                    TicketUpcomingStatus.setTextColor(Color.parseColor("#129C12"));
                    TicketUpcomingStatus.setBackgroundColor(Color.parseColor("#D8F7E0"));
                    txtPaidTicketUpComing.setText(paidTicket.getDeparture().getTicket().getATime()+" - "+paidTicket.getDeparture().getTicket().getDate());
                    btnTicketUpcomingCancel.setVisibility(View.GONE);
                }
            }

        }
        return view;

    }


    private void openDialog(PaidTicket paidTicket, int position) {

        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.activity_cancellation1);

        Window window = dialog.getWindow();

        if (window == null) {
            return;
        }

        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        WindowManager.LayoutParams windowAttribute = window.getAttributes();
        windowAttribute.gravity = Gravity.CENTER;
        window.setAttributes(windowAttribute);

        dialog.setCancelable(true);

        Button btnCancellation1Confirm = dialog.findViewById(R.id.btnCancellation1Confirm);
        Button btnCancellation1Back = dialog.findViewById(R.id.btnCancellation1Back);

        btnCancellation1Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, PaidTicketActivity.class);
                context.startActivity(intent);
            }
        });

        btnCancellation1Confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MySharedPreferences.saveObject(context,"cancelingTicket", paidTicket);
                Intent intent = new Intent(context, Cancellation2Activity.class);
                context.startActivity(intent);
            }
        });

        dialog.show();
    }

    public interface OnPaidTicketClickListener {
        void onPaidTicketClick(int position);
    }
    public interface OnCancelClickListener {
        void onCancelClick(int position);
    }

    public static String calculateTimeStatus(String startTimeStr, String endTimeStr, String startDateStr) {
        // Get current time
        Calendar currentTime = Calendar.getInstance();

        // Parse start time string
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
        Calendar startTime = Calendar.getInstance();
        try {
            Date startTimeDate = timeFormat.parse(startTimeStr);
            startTime.setTime(startTimeDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return "Invalid time format";
        }

        // Parse end time string
        Calendar endTime = Calendar.getInstance();
        try {
            Date endTimeDate = timeFormat.parse(endTimeStr);
            endTime.setTime(endTimeDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return "Invalid time format";
        }

        // Parse start date string
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Calendar startDate = Calendar.getInstance();
        try {
            Date startDateDate = dateFormat.parse(startDateStr);
            startDate.setTime(startDateDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return "Invalid date format";
        }

        // Combine start date and start time
        startTime.set(Calendar.YEAR, startDate.get(Calendar.YEAR));
        startTime.set(Calendar.MONTH, startDate.get(Calendar.MONTH));
        startTime.set(Calendar.DAY_OF_MONTH, startDate.get(Calendar.DAY_OF_MONTH));

        // Combine start date and end time
        endTime.set(Calendar.YEAR, startDate.get(Calendar.YEAR));
        endTime.set(Calendar.MONTH, startDate.get(Calendar.MONTH));
        endTime.set(Calendar.DAY_OF_MONTH, startDate.get(Calendar.DAY_OF_MONTH));

        // Check current time against start and end times
        if (currentTime.before(startTime)) {
            return "Upcoming";
        } else if (currentTime.after(startTime) && currentTime.before(endTime)) {
            return "Ongoing";
        } else {
            return "Completed";
        }
    }

    private CountDownTimer countDownTimer;

    private void startCountdownTimer(TextView textView, String timeStr, String dateStr, boolean isDeparture) {
        SimpleDateFormat dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
        Calendar targetDateTime = Calendar.getInstance();
        try {
            Date targetDate = dateTimeFormat.parse(dateStr + " " + timeStr);
            targetDateTime.setTime(targetDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return;
        }

        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                long currentTimeMillis = System.currentTimeMillis();
                long timeDifferenceMillis = targetDateTime.getTimeInMillis() - currentTimeMillis;

                if (timeDifferenceMillis > 0) {
                    long hours = TimeUnit.MILLISECONDS.toHours(timeDifferenceMillis) % 24;
                    long minutes = TimeUnit.MILLISECONDS.toMinutes(timeDifferenceMillis) % 60;
                    long seconds = TimeUnit.MILLISECONDS.toSeconds(timeDifferenceMillis) % 60;
                    textView.setText(String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds));

                    // Update every second
                    handler.postDelayed(this, 1000);
                } else {
                    textView.setText("00:00");
                    if (isDeparture) {
                        // Update status to "Ongoing" when departure countdown finishes
                        updateTicketStatus("Ongoing");
                    } else {
                        // Update status to "Completed" and show a dialog when arrival countdown finishes
                        updateTicketStatus("Completed");
                        openDialog();
                    }
                }
            }
        });
    }


    private void openDialog() {
    }

    private void updateTicketStatus(String newStatus) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("BookedTicket");

        

        notifyDataSetChanged();
    }

}
