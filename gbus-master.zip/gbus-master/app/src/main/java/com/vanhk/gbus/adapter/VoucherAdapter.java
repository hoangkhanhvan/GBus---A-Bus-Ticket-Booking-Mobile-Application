package com.vanhk.gbus.adapter;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.Base64;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.vanhk.gbus.Payment1Activity;
import com.vanhk.gbus.Payment2_1Activity;
import com.vanhk.gbus.R;
import com.vanhk.gbus.model.Voucher;

import java.util.ArrayList;

public class VoucherAdapter extends RecyclerView.Adapter<VoucherAdapter.ViewHolder> {
    private ArrayList<Voucher> voucherArrayList;
    private int selectedPosition = -1;
    private RecyclerView recyclerView;

    public int getSelectedPosition() {
        return selectedPosition;
    }

    public void setSelectedPosition(int selectedPosition) {
        this.selectedPosition = selectedPosition;
    }

    private OnVoucherSelectedListener listener;

    private Context context;

    public VoucherAdapter(Activity context, ArrayList<Voucher> vouchers, RecyclerView recyclerView, OnVoucherSelectedListener listener) {
        this.context = context;
        this.voucherArrayList = vouchers != null ? new ArrayList<>(vouchers) : new ArrayList<>();
        this.recyclerView = recyclerView;
        this.listener = listener;
    }

    public VoucherAdapter(ArrayList<Object> objects, RecyclerView rvPayment21, Payment2_1Activity payment21Activity) {
    }

    public VoucherAdapter(ArrayList<Object> objects, RecyclerView rvPayment1, Payment1Activity payment1Activity) {
    }

    public void setVouchers(ArrayList<Voucher> vouchers) {
        this.voucherArrayList.clear();
        this.voucherArrayList.addAll(vouchers);
        notifyDataSetChanged();
    }

    public Voucher getItem(int position) {
        if (position >= 0 && position < voucherArrayList.size()) {
            return voucherArrayList.get(position);
        } else {
            return null;
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.payment_1_list_items, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Voucher voucher = voucherArrayList.get(position);
        holder.bind(voucher, position);
    }

    @Override
    public int getItemCount() {
        return voucherArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtVoucherItemDescription, txtPayment1ItemDiscountNumber,txtExpired,txtCondition;
        RadioButton radPayment1ItemVoucher;
        ImageView imgVoucherItem;
        CardView cvVoucher;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtVoucherItemDescription = itemView.findViewById(R.id.txtVoucherItemDescription);
            radPayment1ItemVoucher = itemView.findViewById(R.id.radPayment1ItemVoucher);
            imgVoucherItem=itemView.findViewById(R.id.imgVoucherItem);
            txtPayment1ItemDiscountNumber=itemView.findViewById(R.id.txtPayment1ItemDiscountNumber);
            txtExpired=itemView.findViewById(R.id.txtExpired);
            txtCondition=itemView.findViewById(R.id.txtCondition);
            cvVoucher=itemView.findViewById(R.id.cvVoucher);


            // Set click listener for radio button
            radPayment1ItemVoucher.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    selectedPosition = position;
                    notifyDataSetChanged();
                    if (listener != null) {
                        listener.onVoucherSelected(position);
                    }
                    if (recyclerView != null) {
                        recyclerView.smoothScrollToPosition(position);
                    }
                }
            });

            txtCondition.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    notifyDataSetChanged();
                    openDialog(position);
                }
            });
        }

        public void bind(Voucher voucher, int position) {
            txtVoucherItemDescription.setText(voucher.getDescription());
            radPayment1ItemVoucher.setChecked(position == selectedPosition);
            imgVoucherItem.setImageBitmap(convertBase64toBitmap(voucher.getImage()));
            txtPayment1ItemDiscountNumber.setText(voucher.getPercentage()+ " Off");
            txtExpired.setText(voucher.getExpired());

            SharedPreferences sharedPreferences = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            String DTotalPrice = sharedPreferences.getString("DTotalPrice","0");
            String RTotalPrice = sharedPreferences.getString("RTotalPrice","0");

            int totalPrice = Integer.parseInt(DTotalPrice) + Integer.parseInt(RTotalPrice);
            int conditionValue = voucher.getConditionValue();
            if (totalPrice < conditionValue) {
                cvVoucher.setAlpha(0.5f);
                radPayment1ItemVoucher.setClickable(false);
            } else {
                cvVoucher.setAlpha(1.0f);
                radPayment1ItemVoucher.setClickable(true);
            }
        }
    }

    private void openDialog(int position) {
        Voucher voucher = voucherArrayList.get(position);

        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_voucher_condition);

        Window window = dialog.getWindow();

        if (window == null) {
            return;
        }

        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        WindowManager.LayoutParams windowAttribute = window.getAttributes();
        windowAttribute.gravity = Gravity.CENTER;
        window.setAttributes(windowAttribute);

        dialog.setCancelable(true);

        TextView txtVoucherDetailDescription = dialog.findViewById(R.id.txtVoucherDetailDescription);
        TextView txtVoucherDetailCondition = dialog.findViewById(R.id.txtVoucherDetailCondition);
        TextView txtVoucherDetailExpiryDate = dialog.findViewById(R.id.txtVoucherDetailExpiryDate);

        txtVoucherDetailDescription.setText(voucher.getDescription());
        txtVoucherDetailCondition.setText(voucher.getCondition());
        txtVoucherDetailExpiryDate.setText(voucher.getExpired());

        Button btnVoucherDetailGotIt = dialog.findViewById(R.id.btnVoucherDetailGotIt);

        btnVoucherDetailGotIt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    // Method to add a new voucher to the adapter
    public void add(Voucher voucher) {
        voucherArrayList.add(voucher);
        notifyItemInserted(voucherArrayList.size() - 1);
    }

    // Method to clear all items from the adapter
    public void clear() {
        voucherArrayList.clear();
        notifyDataSetChanged();
    }

    // Interface for handling voucher selection
    public interface OnVoucherSelectedListener {
        void onVoucherSelected(int position);
    }
    private Bitmap convertBase64toBitmap(String base64String) {
        try {
            // Remove the data URI prefix if present
            String pureBase64Encoded = base64String.split(",")[1];

            // Decode the Base64 string into a byte array
            byte[] decodedBytes = Base64.decode(pureBase64Encoded, Base64.DEFAULT);

            // Convert the byte array into a Bitmap
            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);

            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Return null to indicate failure
        }
    }


}
