package com.vanhk.gbus.adapter;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.vanhk.gbus.R;

public class LocationAdapter extends ArrayAdapter<String> {
    Activity context;
    int resource;
    public LocationAdapter(@NonNull Activity context, int resource) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
    }

    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = context.getLayoutInflater().inflate(resource, null);

        TextView txtLocation =view.findViewById(R.id.txtHomepage21Location);

        String location = getItem(position);

        txtLocation.setText(location);
        return view;
    }
}
