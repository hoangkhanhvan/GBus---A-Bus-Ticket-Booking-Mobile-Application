package com.vanhk.gbus.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.vanhk.gbus.R;
import com.vanhk.gbus.model.Notification;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class NotificationAdapter extends ArrayAdapter<Notification> {
    Activity context;
    int resource;

    public NotificationAdapter(@NonNull Activity context, int resource) {
        super(context, resource);
        this.context=context;
        this.resource=resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = this.context.getLayoutInflater();
        View notification = inflater.inflate(this.resource,null);

        ImageView imgNoti=notification.findViewById(R.id.imgNoti);
        TextView txtNotiTitle=notification.findViewById(R.id.txtNotiTitle);
        TextView txtNotiDes=notification.findViewById(R.id.txtNotiDes);
        TextView txtNotiTime=notification.findViewById(R.id.txtNotiTime);

        Notification notification1=getItem(position);
        imgNoti.setImageBitmap(notification1.getImage());
        txtNotiTitle.setText(notification1.getTitle());
        txtNotiDes.setText(notification1.getDescription());
        //txtNotiTime.setText(notification1.getTimestamp());

        if (isTodayNotification(notification1.getTimestamp())) {
            DateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
            String formattedTime = timeFormat.format(notification1.getTimestamp());
            txtNotiTime.setText(formattedTime);
        } else {
            DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
            String formattedDate = dateFormat.format(notification1.getTimestamp());
            txtNotiTime.setText(formattedDate);
        }

        return notification;
    }

    private boolean isTodayNotification(long timestamp) {
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);

        Calendar notificationTime = Calendar.getInstance();
        notificationTime.setTimeInMillis(timestamp);
        notificationTime.set(Calendar.HOUR_OF_DAY, 0);
        notificationTime.set(Calendar.MINUTE, 0);
        notificationTime.set(Calendar.SECOND, 0);
        notificationTime.set(Calendar.MILLISECOND, 0);

        return notificationTime.equals(today);
    }


}
