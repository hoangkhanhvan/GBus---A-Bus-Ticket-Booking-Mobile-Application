package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ResultList5Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_list5);
    }
}