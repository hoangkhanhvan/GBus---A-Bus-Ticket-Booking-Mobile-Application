package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.LocationAdapter;
import com.vanhk.gbus.adapter.TripAdapter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Homepage2_1Activity extends AppCompatActivity {
    ListView lvHomepage21Locations;
    EditText edtHomepage21Search;
    ImageView imgHomepage21Back;
    LocationAdapter locationAdapter;
    String TAG="FIREBASE";

    ProgressDialog progressDialog; // Declare ProgressDialog

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage21);
        addViews();
        addEvents();

    }

    public static final String DATABASE_NAME = "GBUS.db";
    public static final String DB_PATH_SUFFIX = "/databases/";
    public static SQLiteDatabase database = null;

    private void copyDataBase(){
        try{
            File dbFile = getDatabasePath(DATABASE_NAME);
            if(!dbFile.exists()){
                if(CopyDBFromAsset()){
                    Log.d("Database","Copy Successful");
                }else{
                    Log.d("Database","Copy Failed");
                }
            }
        }catch (Exception e){
            Log.e("Error: ", e.toString());
        }
    }

    private boolean CopyDBFromAsset() {
        String dbPath = getApplicationInfo().dataDir + DB_PATH_SUFFIX + DATABASE_NAME;
        try {
            InputStream inputStream = getAssets().open(DATABASE_NAME);
            File f = new File(getApplicationInfo().dataDir + DB_PATH_SUFFIX);
            if(!f.exists()){
                f.mkdir();
            }
            OutputStream outputStream = new FileOutputStream(dbPath);
            byte[] buffer = new byte[1024]; int length;
            while((length=inputStream.read(buffer))>0){
                outputStream.write(buffer,0, length);
            }
            outputStream.flush();  outputStream.close(); inputStream.close();
            return  true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void loadLocation() {
        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog

        // Show ProgressDialog before loading locations
        progressDialog.setMessage("Loading Locations...");
        progressDialog.show();

        database = openOrCreateDatabase(DATABASE_NAME,MODE_PRIVATE,null);
        Cursor cursor = database.rawQuery("select * from Location", null);
        while (cursor.moveToNext()) {
            String location = cursor.getString(1);
            locationAdapter.add(location);
        }

        // Dismiss ProgressDialog after loading locations
        progressDialog.dismiss();
    }

    private void addEvents() {
        imgHomepage21Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Homepage2_1Activity.this, HomepageActivity.class);
                Intent returnIntent = getIntent();
                intent.putExtra("ALocation",returnIntent.getStringExtra("ALocation"));
                intent.putExtra("DLocation",returnIntent.getStringExtra("DLocation"));
                startActivity(intent);
            }
        });
        lvHomepage21Locations.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String location = locationAdapter.getItem(position);
                Intent intent = new Intent(Homepage2_1Activity.this, HomepageActivity.class);

                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                editor.putString("DLocation",location);
                editor.apply();
                startActivity(intent);
            }
        });
    }

    private void addViews() {
        lvHomepage21Locations=findViewById(R.id.lvHomepage21Locations);
        edtHomepage21Search=findViewById(R.id.edtHomepage21Search);
        imgHomepage21Back=findViewById(R.id.imgHomepage21Back);
        locationAdapter = new LocationAdapter(Homepage2_1Activity.this,R.layout.lvhomepage21location);
        lvHomepage21Locations.setAdapter(locationAdapter);

        copyDataBase();
        loadLocation();
    }
}