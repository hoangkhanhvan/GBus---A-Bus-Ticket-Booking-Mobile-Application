package com.vanhk.gbus.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.vanhk.gbus.R;
import com.vanhk.gbus.model.Point;
import com.vanhk.gbus.model.Ticket;

public class PointAdapter extends ArrayAdapter<Point> {
    Activity context;
    int resource;
    public PointAdapter(@NonNull Activity context, int resource) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = context.getLayoutInflater().inflate(resource, null);

        TextView Time = view.findViewById(R.id.txtTripDetails1PickupLocationTime);
        TextView Date = view.findViewById(R.id.txtTripDetails1PickupLocationDate);
        TextView PointName = view.findViewById(R.id.txtTripDetails1PickupLocationTitle);
        TextView Address= view.findViewById(R.id.txtTripDetails1PickupLocationLocation);
        TextView ShuttleBus = view.findViewById(R.id.txtTripDetails1PickupLocationTag);

        Point point = getItem(position);

        if (point != null) {
            if (Time != null) Time.setText(point.getTime());
            if (Date != null) Date.setText(point.getDate());
            if (PointName != null) PointName.setText(point.getPoint());
            if (Address != null) Address.setText(point.getAddress());
            if (ShuttleBus != null) {
                if (point.isShuttleBus()) {
                    ShuttleBus.setVisibility(View.INVISIBLE);
                }
            }
        }
        return view;
    }
}
