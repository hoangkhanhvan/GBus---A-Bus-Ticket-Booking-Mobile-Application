package com.vanhk.gbus;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.vanhk.gbus.R;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.Payment;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PayByCreditCard1Activity extends AppCompatActivity {

    Spinner spinnerPaymentMethod;
    EditText edtAccountManagement2Name,edtCardholdername, edtExpireDate, edtInsertcardholdername;
    Button btnAccountManagement2;
    ImageView imgInputCard, imgInputCard2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pay_by_credit_card1);

        addViews();
        addEvents();
    }

    private void addEvents() {
        imgInputCard.setOnClickListener(view -> {
            activeImageView = imgInputCard; // Set the active ImageView
            checkCameraPermission();        // Check permission and launch camera
        });

        imgInputCard2.setOnClickListener(view -> {
            activeImageView = imgInputCard2; // Set the active ImageView
            checkCameraPermission();         // Check permission and launch camera
        });

        btnAccountManagement2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cardNumber = edtAccountManagement2Name.getText().toString().trim();
                String cardHolderName = edtCardholdername.getText().toString().trim();
                String expireDate = edtExpireDate.getText().toString().trim();
                String CVV = edtInsertcardholdername.getText().toString().trim();

                if (cardNumber.isEmpty() || cardHolderName.isEmpty() || expireDate.isEmpty() || CVV.isEmpty()) {
                    Toast.makeText(PayByCreditCard1Activity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Check the validity of the card number
                    if (cardNumber.length() < 12 || cardNumber.length() > 19) {
                        Toast.makeText(PayByCreditCard1Activity.this, "Invalid card number", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    // Check the validity of the expiration date
                    if (!isValidExpireDate(expireDate)) {
                        Toast.makeText(PayByCreditCard1Activity.this, "Invalid expiration date. Format MM/YY", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    // Check the validity of the CVV
                    if (CVV.length() != 3 && CVV.length() != 4) {
                        Toast.makeText(PayByCreditCard1Activity.this, "Invalid CVV", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Intent intent = new Intent(getApplicationContext(), PaymentUnsucessful_1Activity.class);
                    Toast.makeText(PayByCreditCard1Activity.this, "Processing your payment", Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                }
            }
        });
    }

    private boolean isValidExpireDate(String expireDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/yy", Locale.US);
        sdf.setLenient(false);
        try {
            Date expiry = sdf.parse(expireDate);
            Date today = new Date();
            if (expiry.before(today)) {
                return false; // Expired
            }
            return true;
        } catch (ParseException e) {
            return false; // Invalid date format
        }
    }


    private void addViews() {
        spinnerPaymentMethod=findViewById(R.id.spinnerPaymentMethod);
        edtAccountManagement2Name=findViewById(R.id.edtAccountManagement2Name);
        edtCardholdername=findViewById(R.id.edtCardholdername);
        edtExpireDate=findViewById(R.id.edtExpireDate);
        edtInsertcardholdername=findViewById(R.id.edtInsertcardholdername);
        btnAccountManagement2=findViewById(R.id.btnAccountManagement2);
        imgInputCard=findViewById(R.id.imgInputCard);
        imgInputCard2=findViewById(R.id.imgInputCard2);

        String[] paymentMethods = {"MasterCard", "VISA", "Napas"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, paymentMethods);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerPaymentMethod.setAdapter(adapter);

        Payment selectedPayment = MySharedPreferences.getObject(this, "PaymentMethod", Payment.class);
        if (selectedPayment != null && selectedPayment.getMethod() != null) {
            String selectedMethod = selectedPayment.getMethod();
            setSpinnerToValue(spinnerPaymentMethod, selectedMethod);
        }
    }

    private void setSpinnerToValue(Spinner spinner, String value) {
        ArrayAdapter<String> adapter = (ArrayAdapter<String>) spinner.getAdapter();
        int position = adapter.getPosition(value);
        spinner.setSelection(position, true);
    }


    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int REQUEST_CAMERA_PERMISSION = 101;
    private ImageView activeImageView; // To keep track of which ImageView triggered the camera intent

    private void checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        } else {
            dispatchTakePictureIntent();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                dispatchTakePictureIntent();
            } else {
                Toast.makeText(this, "Camera permission is required to use camera.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            if (extras != null) {
                Bitmap imageBitmap = (Bitmap) extras.get("data");
                if (activeImageView != null) {
                    activeImageView.setImageBitmap(imageBitmap);
                }
            }
        }
    }


}