package com.vanhk.gbus.model;


import android.graphics.Bitmap;

import java.io.Serializable;
import java.util.ArrayList;

public class Ticket implements Serializable {
    private String _id;
    private String AOffice;
    private String DOffice;
    private ArrayList<String> Amenities;
    private String ATime;
    private String DTime;

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    private String Image;

    public String get_id() {
        return _id;
    }

    public String getAOffice() {
        return AOffice;
    }

    public void setAOffice(String AOffice) {
        this.AOffice = AOffice;
    }

    public String getDOffice() {
        return DOffice;
    }

    public void setDOffice(String DOffice) {
        this.DOffice = DOffice;
    }

    public ArrayList<String> getAmenities() {
        return Amenities;
    }

    public void setAmenities(ArrayList<String> amenities) {
        Amenities = amenities;
    }

    public String getATime() {
        return ATime;
    }

    public void setATime(String ATime) {
        this.ATime = ATime;
    }

    public String getDTime() {
        return DTime;
    }

    public void setDTime(String DTime) {
        this.DTime = DTime;
    }

    public String getBus() {
        return Bus;
    }

    public void setBus(String bus) {
        Bus = bus;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public ArrayList<String> getDriver() {
        return Driver;
    }

    public void setDriver(ArrayList<String> driver) {
        Driver = driver;
    }

    public String getRoute() {
        return Route;
    }

    public void setRoute(String route) {
        Route = route;
    }

    public ArrayList<String> getSeat() {
        return Seat;
    }

    public void setSeat(ArrayList<String> seat) {
        Seat = seat;
    }

    public ArrayList<String> getReviews() {
        return Reviews;
    }

    public void setReviews(ArrayList<String> reviews) {
        Reviews = reviews;
    }

    public int getPrice() {
        return Price;
    }

    public void setPrice(int price) {
        Price = price;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public Ticket() {
    }

    public Ticket(String _id, String AOffice, String DOffice, ArrayList<String> amenities, String ATime, String DTime, String bus, String date, ArrayList<String> driver, String route, ArrayList<String> seat, ArrayList<String> reviews, int price, String image) {
        this._id = _id;
        this.AOffice = AOffice;
        this.DOffice = DOffice;
        Amenities = amenities;
        this.ATime = ATime;
        this.DTime = DTime;
        Bus = bus;
        Date = date;
        Driver = driver;
        Route = route;
        Seat = seat;
        Reviews = reviews;
        Price = price;
        Image = image;
    }

    private String Bus;
    private String Date;
    private ArrayList<String> Driver;
    private String Route;
    private ArrayList<String> Seat;
    private ArrayList<String> Reviews;
    private int Price;
}


