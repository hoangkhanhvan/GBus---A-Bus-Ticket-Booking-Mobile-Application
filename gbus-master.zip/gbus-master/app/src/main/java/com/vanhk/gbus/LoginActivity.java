package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.app.ProgressDialog; // Import ProgressDialog
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.Manifest;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.AccountAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class LoginActivity extends AppCompatActivity {
    EditText edtLogIn;
    Button btnLogIn, btnLogInGoogle, btnLogInCreateAccount;

    String userPhoneNumber;
    String userEmail;
    AccountAdapter accountAdapter;
    DatabaseReference myRef;
    FirebaseAuth auth;
    FirebaseDatabase database;
    GoogleSignInClient mGoogleSignInClient;
    GoogleSignInOptions gso;
    int RC_SIGN_IN = 20;
    String TAG = "FIREBASE";

    final String PREF_NAME="LoginData";
    private static final int REQUEST_CODE_PERMISSIONS = 100;


    int wrongAttempts = 0; // Counter for wrong login attempts

    ProgressDialog progressDialog; // Declare ProgressDialog

    BroadcastReceiver internetReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Toast.makeText(context, "Internet changed", Toast.LENGTH_LONG).show();
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            if (networkInfo != null && networkInfo.isConnected()) {
                btnLogIn.setEnabled(true);
                btnLogInGoogle.setEnabled(true);
            } else {
                btnLogIn.setBackgroundResource(R.drawable.button_background_disable);
                btnLogIn.setEnabled(false);
                btnLogInGoogle.setEnabled(false);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog
        progressDialog.setMessage("Logging in...");
        progressDialog.setCancelable(false);
        addViews();
        addEvents();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            checkAndRequestNotificationPermission();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
    private void checkAndRequestNotificationPermission() {
        // Define the permissions needed for notifications
        String[] permissions = new String[]{
                Manifest.permission.POST_NOTIFICATIONS
        };

        List<String> permissionsToRequest = new ArrayList<>();
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }

        // Request permissions
        if (!permissionsToRequest.isEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsToRequest.toArray(new String[0]), REQUEST_CODE_PERMISSIONS);
        }
    }


    private void addEvents() {
        btnLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show(); // Show ProgressDialog when login button is clicked
                if (edtLogIn.getText().toString().trim().isEmpty()) {
                    progressDialog.dismiss(); // Dismiss ProgressDialog if input is empty
                    Toast.makeText(LoginActivity.this, "Please enter your Phone Number / Email", Toast.LENGTH_LONG).show();
                    edtLogIn.setError("Phone Number / Email is required");
                    edtLogIn.requestFocus();
                    return;
                } else {
                    final String enteredUserName = edtLogIn.getText().toString().trim();
                    checkAccount(enteredUserName);
                }
            }
        });

        btnLogInCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(LoginActivity.this, SignUp1Activity.class);
                startActivity(intent);
            }
        });

        btnLogInGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                googleSignIn();
            }
        });
    }

    private void googleSignIn() {
        Intent intent=mGoogleSignInClient.getSignInIntent();
        startActivityForResult(intent,1000);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1000) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                Intent intent = new Intent(LoginActivity.this, HomepageActivity.class);
                startActivity(intent);
            } catch (Exception e) {
                Log.e(TAG, "Google sign in failed", e);
                Toast.makeText(this, "Google sign in failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    private void firebaseAuth(String idToken) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken,null);
        auth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            FirebaseUser user = auth.getCurrentUser();
                            HashMap<String, String> map = new HashMap<>();
                            map.put("id",user.getUid());
                            map.put("name",user.getDisplayName());
                            map.put("profile",user.getPhotoUrl().toString());

                            database.getReference().child("users").child(user.getUid()).setValue(map);
                            Intent intent= new Intent(LoginActivity.this,HomepageActivity.class);
                            startActivity(intent);
                            finish();
                        } else {
                            progressDialog.dismiss(); // Dismiss ProgressDialog if login fails
                            Toast.makeText(LoginActivity.this,"Something went wrong",Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    private void checkAccount(final String enteredUserName) {
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                boolean found = false;
                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    String userEmail = data.child("accountEmail").getValue(String.class);
                    String userPhoneNumber = data.child("accountPhoneNumber").getValue(String.class);
                    String userName = data.child("accountUserName").getValue(String.class);

                    if (userName != null && userEmail != null && isValidEmail(enteredUserName) && enteredUserName.equals(userEmail)) {
                        // Email matches, proceed to login
                        found = true;
                        Intent intent = new Intent(LoginActivity.this, Login2Activity.class);
                        startActivity(intent);
                        progressDialog.dismiss(); // Dismiss ProgressDialog after successful login
                        break;
                    } else if (userName != null && userPhoneNumber != null && isValidPhoneNumber(enteredUserName) && enteredUserName.equals(userPhoneNumber)) {
                        // Phone number matches, proceed to login
                        found = true;
                        Intent intent = new Intent(LoginActivity.this, Login2Activity.class);
                        startActivity(intent);
                        progressDialog.dismiss(); // Dismiss ProgressDialog after successful login
                        break;
                    } else if (userName != null && userName != null && enteredUserName.equals(userName)) {
                        // Username matches, proceed to login
                        found = true;
                        Intent intent = new Intent(LoginActivity.this, Login2Activity.class);
                        startActivity(intent);
                        progressDialog.dismiss(); // Dismiss ProgressDialog after successful login
                        break;
                    }
                }
                if (!found) {
                    progressDialog.dismiss(); // Dismiss ProgressDialog if no matching account found
                    // Increment wrong attempts counter
                    wrongAttempts++;
                    // Display appropriate message based on wrong attempts
                    switch (wrongAttempts) {
                        case 1:
                            Toast.makeText(LoginActivity.this, "Wrong attempt 1", Toast.LENGTH_SHORT).show();
                            break;
                        case 2:
                            Toast.makeText(LoginActivity.this, "Wrong attempt 2", Toast.LENGTH_SHORT).show();
                            break;
                        case 3:
                            Toast.makeText(LoginActivity.this, "Wrong attempt 3", Toast.LENGTH_SHORT).show();
                            break;
                        case 4:
                            Toast.makeText(LoginActivity.this, "Wrong attempt 4", Toast.LENGTH_SHORT).show();
                            break;
                        case 5:
                            Toast.makeText(LoginActivity.this, "Wrong attempt 5", Toast.LENGTH_SHORT).show();
                            break;
                        case 6:
                            // Redirect to Forgot Password activity
                            Intent intent = new Intent(LoginActivity.this, ForgotPassword_1Activity.class);
                            startActivity(intent);
                            break;
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w(TAG, "loadPost:onCancelled", databaseError.toException());
            }
        });
    }

    private boolean isValidPhoneNumber(String enteredUserName) {
        String phonePattern = "^\\d{10}$";
        return enteredUserName.matches(phonePattern);
    }

    private boolean isValidEmail(String enteredUserName) {
        String emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        return enteredUserName.matches(emailPattern);
    }

    protected void onPause() {
        super.onPause();
        saveLoginInformation();

        if (internetReceiver != null) {
            unregisterReceiver(internetReceiver);
        }
    }

    private void saveLoginInformation() {
        SharedPreferences preferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("account_username", edtLogIn.getText().toString());
        editor.commit();
    }

    void readLoginInformation() {
        SharedPreferences preferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        String userName = preferences.getString("account_username", "");
        boolean save = preferences.getBoolean("SAVE", false);
        if (save) {
            edtLogIn.setText(userName);
        }
    }

    protected void onResume() {
        super.onResume();
        readLoginInformation();

        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(internetReceiver, filter);
    }

    private void addViews() {
        edtLogIn=findViewById(R.id.edtLogIn);
        btnLogIn=findViewById(R.id.btnLogIn);
        btnLogInGoogle=findViewById(R.id.btnLogInGoogle);
        btnLogInCreateAccount=findViewById(R.id.btnLogInCreateAccount);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("account");
        auth=FirebaseAuth.getInstance();
        gso=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail().build();
        mGoogleSignInClient= GoogleSignIn.getClient(this,gso);
    }
}
