package com.vanhk.gbus.adapter;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.BookingPreview1Activity;
import com.vanhk.gbus.Cancellation2Activity;
import com.vanhk.gbus.ChooseSeat_Depart_1Activity;
import com.vanhk.gbus.Payment1Activity;
import com.vanhk.gbus.R;
import com.vanhk.gbus.ResultList1Activity;
import com.vanhk.gbus.UnpaidTicketActivity;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.Point2;
import com.vanhk.gbus.model.Ticket;
import com.vanhk.gbus.model.UnPaidTicket;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class UnPaidAdapter extends ArrayAdapter<UnPaidTicket> {
    Activity context;
    int resource;
    ArrayList<UnPaidTicket> UnpaidTickets;
    private OnCancelTicketClickListener onCancelTicketClickListener;

    public UnPaidAdapter(@NonNull Activity context, int resource, ArrayList<UnPaidTicket> unpaidTickets) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
        this.UnpaidTickets = unpaidTickets;
    }
    public void setonCancelTicketClickListener(OnCancelTicketClickListener listener) {
        this.onCancelTicketClickListener = listener;
    }

    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = context.getLayoutInflater().inflate(resource, null);

        TextView UnpaidTicketPrice = view.findViewById(com.vanhk.gbus.R.id.txtUnpaidTicketPrice);
        TextView UnpaidTicketDate = view.findViewById(R.id.txtUnpaidTicketDate);
        TextView UnpaidTicketTimeLeft = view.findViewById(R.id.txtUnpaidTicketTimeLeft);
        TextView UnpaidTicketDepartTimeUnpaid = view.findViewById(R.id.txtUnpaidTicketDepartTimeUnpaid);
        TextView UnpaidTicketDepartDateUnpaid = view.findViewById(R.id.txtUnpaidTicketDepartDateUnpaid);
        TextView UnpaidTicketDepartTitleUnpaid1 = view.findViewById(R.id.txtUnpaidTicketDepartTitleUnpaid1);
        TextView UnpaidTicketDepartTitleUnpaid3 = view.findViewById(R.id.txtUnpaidTicketDepartTitleUnpaid3);
        TextView UnpaidTicketDepartDescriptionUnpaid = view.findViewById(R.id.txtUnpaidTicketDepartDescriptionUnpaid);
        TextView UnpaidTicketDepartNoUnpaid = view.findViewById(R.id.txtUnpaidTicketDepartNoUnpaid);
        TextView UnpaidTicketArrivalTimeUnpaid = view.findViewById(R.id.txtUnpaidTicketArrivalTimeUnpaid);
        TextView UnpaidTicketArrivalDateUnpaid = view.findViewById(R.id.txtUnpaidTicketArrivalDateUnpaid);
        TextView UnpaidTicketArrivalTitleUnpaid1 = view.findViewById(R.id.txtUnpaidTicketArrivalTitleUnpaid1);
        TextView UnpaidTicketArrivalTitleUnpaid3 = view.findViewById(R.id.txtUnpaidTicketArrivalTitleUnpaid3);
        TextView UnpaidTicketArrivalLocationUnpaid = view.findViewById(R.id.txtUnpaidTicketArrivalLocationUnpaid);
        TextView UnpaidTicketArrivalNoUnpaid = view.findViewById(R.id.txtUnpaidTicketArrivalNoUnpaid);
        Button btnUnpaidTicketCancelUnpaid = view.findViewById(R.id.btnUnpaidTicketCancelUnpaid);
        Button btnUnpaidTicketPayNowUnpaid=view.findViewById(R.id.btnUnpaidTicketPayNowUnpaid);
        LinearLayout llReturn = view.findViewById(R.id.llReturn);
        LinearLayout llUnpaidTicket = view.findViewById(R.id.llUnpaidTicket);

        UnPaidTicket unPaidTicket = getItem(position);

        llUnpaidTicket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                String BusDes = sharedPreferences.getString("BusDes","Limousine");

                if (unPaidTicket.getReturn() != null) {
                    editor.putBoolean("isReturn",false);
                    MySharedPreferences.saveObject(context,"DTicket", unPaidTicket.getDeparture().getTicket());

                    editor.putStringSet("DSeat", (Set<String>) unPaidTicket.getDeparture().getSeat());

                    MySharedPreferences.saveObject(context,"DPickUpPoint", unPaidTicket.getDeparture().getPickUpPoint());
                    MySharedPreferences.saveObject(context,"DDropOffPoint",unPaidTicket.getDeparture().getDropOffPoint());
                } else {
                    editor.putBoolean("isReturn",true);

                    MySharedPreferences.saveObject(context,"DTicket", unPaidTicket.getDeparture().getTicket());

                    editor.putStringSet("DSeat", (Set<String>) unPaidTicket.getDeparture().getSeat());

                    MySharedPreferences.saveObject(context,"DPickUpPoint", unPaidTicket.getDeparture().getPickUpPoint());
                    MySharedPreferences.saveObject(context,"DDropOffPoint",unPaidTicket.getDeparture().getDropOffPoint());

                    MySharedPreferences.saveObject(context,"RTicket", unPaidTicket.getReturn().getTicket());

                    editor.putStringSet("RSeat", (Set<String>) unPaidTicket.getReturn().getSeat());

                    MySharedPreferences.saveObject(context,"RPickUpPoint", unPaidTicket.getReturn().getPickUpPoint());
                    MySharedPreferences.saveObject(context,"RDropOffPoint",unPaidTicket.getReturn().getDropOffPoint());
                }
                editor.apply();
                Intent intent = new Intent(context, BookingPreview1Activity.class);
                context.startActivity(intent);
            }
        });

        if (unPaidTicket!=null) {
            if (unPaidTicket.getReturn()!=null) {
                UnpaidTicketPrice.setText(String.valueOf(unPaidTicket.getDeparture().getTotalPrice()+unPaidTicket.getReturn().getTotalPrice()));

                //note tính time paid
                UnpaidTicketDate.setText(calculateUnPaidTime(unPaidTicket.getBookedTime()));
                //note tính countdown
                startCountdownTimer(UnpaidTicketTimeLeft, calculateUnPaidTime(unPaidTicket.getBookedTime()), unPaidTicket, position);
                UnpaidTicketDepartTimeUnpaid.setText(unPaidTicket.getDeparture().getPickUpPoint().getTime());
                UnpaidTicketDepartDateUnpaid.setText(unPaidTicket.getDeparture().getPickUpPoint().getDateStr());
                UnpaidTicketDepartTitleUnpaid1.setText(unPaidTicket.getDeparture().getDLocation());
                UnpaidTicketDepartTitleUnpaid3.setText(unPaidTicket.getDeparture().getALocation());
                UnpaidTicketDepartDescriptionUnpaid.setText(unPaidTicket.getDeparture().getBus());
                UnpaidTicketDepartNoUnpaid.setText(unPaidTicket.getDeparture().getSeat().toString());
                UnpaidTicketArrivalTimeUnpaid.setText(unPaidTicket.getReturn().getPickUpPoint().getTime());
                UnpaidTicketArrivalDateUnpaid.setText(unPaidTicket.getReturn().getPickUpPoint().getDateStr());
                UnpaidTicketArrivalTitleUnpaid1.setText(unPaidTicket.getReturn().getDLocation());
                UnpaidTicketArrivalTitleUnpaid3.setText(unPaidTicket.getReturn().getALocation());
                UnpaidTicketArrivalLocationUnpaid.setText(unPaidTicket.getReturn().getBus());
                UnpaidTicketArrivalNoUnpaid.setText(unPaidTicket.getReturn().getSeat().toString());
            } else {
                llReturn.setVisibility(View.GONE);
                UnpaidTicketPrice.setText(String.valueOf(unPaidTicket.getDeparture().getTotalPrice()));

                //note tính time paid
                UnpaidTicketDate.setText(calculateUnPaidTime(unPaidTicket.getBookedTime()));
                //note tính countdown
                startCountdownTimer(UnpaidTicketTimeLeft, calculateUnPaidTime(unPaidTicket.getBookedTime()), unPaidTicket, position);
                UnpaidTicketDepartTimeUnpaid.setText(unPaidTicket.getDeparture().getPickUpPoint().getTime());
                UnpaidTicketDepartDateUnpaid.setText(unPaidTicket.getDeparture().getPickUpPoint().getDateStr());
                UnpaidTicketDepartTitleUnpaid1.setText(unPaidTicket.getDeparture().getDLocation());
                UnpaidTicketDepartTitleUnpaid3.setText(unPaidTicket.getDeparture().getALocation());
                UnpaidTicketDepartDescriptionUnpaid.setText(unPaidTicket.getDeparture().getBus());
                UnpaidTicketDepartNoUnpaid.setText(unPaidTicket.getDeparture().getSeat().toString());
            }


            btnUnpaidTicketCancelUnpaid.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onCancelTicketClickListener != null) {
                        onCancelTicketClickListener.onCancelTicketClick(position);
                    }
                    openDialog(unPaidTicket, position);
                }
            });

            btnUnpaidTicketPayNowUnpaid.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, Payment1Activity.class);


                    SharedPreferences sharedPreferences = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    Log.d("UnPaidAdapter", "Before update: " + sharedPreferences.getString("DTotalPrice", "Default"));

                    MySharedPreferences.saveObject(context, "DTicket", unPaidTicket.getDeparture().getTicket());
                    editor.putString("DTotalPrice",String.valueOf(unPaidTicket.getDeparture().getTotalPrice()));
                    editor.putString("RTotalPrice","0");
                    if (unPaidTicket.getReturn()!=null) {
                        MySharedPreferences.saveObject(context, "RTicket", unPaidTicket.getReturn().getTicket());
                        editor.putString("RTotalPrice",String.valueOf(unPaidTicket.getReturn().getTotalPrice()));
                    }
                    editor.putString("TransactionNumber",unPaidTicket.getTransactionNumber());

                    editor.apply();
                    Log.d("UnPaidAdapter", "After update: " + sharedPreferences.getString("DTotalPrice", "Default"));

                    context.startActivity(intent);
                }
            });
        }
        return view;
    }

    private void openDialog(UnPaidTicket unPaidTicket, int position) {

        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.activity_cancellation1);

        Window window = dialog.getWindow();

        if (window == null) {
            return;
        }

        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        WindowManager.LayoutParams windowAttribute = window.getAttributes();
        windowAttribute.gravity = Gravity.CENTER;
        window.setAttributes(windowAttribute);

        dialog.setCancelable(true);

        Button btnCancellation1Confirm = dialog.findViewById(R.id.btnCancellation1Confirm);
        Button btnCancellation1Back = dialog.findViewById(R.id.btnCancellation1Back);

        btnCancellation1Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, UnpaidTicketActivity.class);
                context.startActivity(intent);
            }
        });

        btnCancellation1Confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateTicketStatusToCancel(unPaidTicket, position);
                updateSeat(unPaidTicket.getDeparture().getTicket().get_id(), unPaidTicket.getDeparture().getSeat());
                if (unPaidTicket.getReturn() != null) {
                    updateSeat( unPaidTicket.getReturn().getTicket().get_id(), unPaidTicket.getReturn().getSeat());
                }
                dialog.dismiss();
            }
        });

        dialog.show();
    }


    private String countdownTime(String bookedTime) {
        try {
            // Parse the booked time from Firebase
            SimpleDateFormat firebaseFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
            Date firebaseDate = firebaseFormat.parse(bookedTime);

            // Subtract 15 minutes from the booked time
            Calendar cal = Calendar.getInstance();
            cal.setTime(firebaseDate);
            cal.add(Calendar.MINUTE, -15);
            Date countdownDate = cal.getTime();

            // Format the result back to a string
            SimpleDateFormat resultFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
            return resultFormat.format(countdownDate);

        } catch (ParseException e) {
            e.printStackTrace();
            return null; // Handle parse exception
        }
    }

    private String calculateUnPaidTime(String bookedTime) {
        try {
            // Parse the booked time from Firebase
            SimpleDateFormat firebaseFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.ENGLISH);
            Date firebaseDate = firebaseFormat.parse(bookedTime);

            // Add 15 minutes to the booked time
            Calendar cal = Calendar.getInstance();
            cal.setTime(firebaseDate);
            cal.add(Calendar.MINUTE, 15);
            Date unpaidDate = cal.getTime();

            // Format the result as HH:mm - EEE/MM/dd/yyyy
            SimpleDateFormat resultFormat = new SimpleDateFormat("HH:mm - EEE/MM/dd/yyyy", Locale.ENGLISH);
            return resultFormat.format(unpaidDate);

        } catch (ParseException e) {
            e.printStackTrace();
            return null; // Handle parse exception
        }
    }
    public interface OnCancelTicketClickListener {
        void onCancelTicketClick(int position);
    }
    public interface OnPayNowClickListener {
        void onPayNowClick(int position);
    }

    private CountDownTimer countDownTimer;
    private void startCountdownTimer(TextView textView, String targetTime, UnPaidTicket selectedUnpaidTicket, int position) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("HH:mm - EEE/MM/dd/yyyy", Locale.ENGLISH);
            Date targetDate = format.parse(targetTime);

            Calendar targetCalendar = Calendar.getInstance();
            targetCalendar.setTime(targetDate);

            long targetMillis = targetCalendar.getTimeInMillis();

            countDownTimer = new CountDownTimer(targetMillis - System.currentTimeMillis(), 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    long seconds = millisUntilFinished / 1000;
                    long minutes = seconds / 60;
                    seconds %= 60;

                    String countdown = String.format(Locale.ENGLISH, "%02d:%02d", minutes, seconds);
                    textView.setText(countdown);
                }

                @Override
                public void onFinish() {
                    textView.setText("00:00"); // Timer finished
                    updateTicketStatusToCancel(selectedUnpaidTicket, position);
                    updateSeat( selectedUnpaidTicket.getDeparture().getTicket().get_id(), selectedUnpaidTicket.getDeparture().getSeat());
                    if (selectedUnpaidTicket.getReturn() != null) {
                        updateSeat( selectedUnpaidTicket.getReturn().getTicket().get_id(), selectedUnpaidTicket.getReturn().getSeat());
                    }

                }
            };

            countDownTimer.start();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private void updateTicketStatusToCancel(UnPaidTicket unPaidTicket, int position) {
        String _id = unPaidTicket.get_id();
        DatabaseReference ticketRef = FirebaseDatabase.getInstance().getReference().child("BookedTicket").child(_id);

        // Remove the whole ticket reference
        ticketRef.removeValue().addOnSuccessListener(unused -> {
            Toast.makeText(context, "Your ticket has been CANCELLED", Toast.LENGTH_SHORT).show();

            // Remove the ticket from the ArrayList
            UnpaidTickets.remove(position);

            // Notify the ListView of the data change to refresh the view
            notifyDataSetChanged();
        });
    }


    private void updateSeat(String ticketId, List<String> seatsToRemove) {
        DatabaseReference ticketsRef = FirebaseDatabase.getInstance().getReference().child("Tickets");

        // Listen to the entire Tickets node
        ticketsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // Iterate over all tickets
                for (DataSnapshot ticketSnapshot : dataSnapshot.getChildren()) {
                    String _id = ticketSnapshot.child("_id").getValue(String.class);
                    // Check if the _id of the ticket matches the ticketId
                    if (ticketId.equals(_id)) {
                        // Process the Seat node of the matching ticket
                        processSeatRemoval(ticketSnapshot.child("Seat"), seatsToRemove);
                        break; // Stop the loop after processing the matching ticket
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w("Firebase", "Failed to read tickets for seat update.", databaseError.toException());
            }
        });
    }

    private void processSeatRemoval(DataSnapshot seatSnapshot, List<String> seatsToRemove) {
        // Iterate over each seat in the Seat node
        for (DataSnapshot singleSeatSnapshot : seatSnapshot.getChildren()) {
            String seat = singleSeatSnapshot.getValue(String.class);
            // Check if the current seat is in the list to remove
            if (seatsToRemove.contains(seat)) {
                singleSeatSnapshot.getRef().removeValue(); // Remove the matching seat
            }
        }
    }


    public void stopCountdownTimer() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }

}
