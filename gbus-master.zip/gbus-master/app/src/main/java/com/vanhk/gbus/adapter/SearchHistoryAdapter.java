package com.vanhk.gbus.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.vanhk.gbus.R;
import com.vanhk.gbus.model.SearchHistory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class SearchHistoryAdapter extends RecyclerView.Adapter<SearchHistoryAdapter.ViewHolder> {
    private ArrayList<SearchHistory> searchHistoryList;
    private Context context;

    public SearchHistoryAdapter(Context context, ArrayList<SearchHistory> searchHistoryList) {
        this.context = context;
        this.searchHistoryList = searchHistoryList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lv_homepage_recentsearch, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        SearchHistory searchHistory = searchHistoryList.get(position);
        holder.txtDepartLocation.setText(searchHistory.getSearchDepartureLocation());
        holder.txtReturnLocation.setText(searchHistory.getSearchArrivalLocation());
        holder.txtDepartDate.setText(searchHistory.getSearchDepartureDate());
        holder.cvSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (isDateSmallerThanCurrentDate(searchHistory.getSearchDepartureDate())) {

                    } else {

                    }
                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    private boolean isDateSmallerThanCurrentDate(String dateString) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date date = sdf.parse(dateString);
        Date currentDate = new Date();

        // Compare the dates
        return date.before(currentDate);
    }


    @Override
    public int getItemCount() {
        return searchHistoryList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtDepartLocation;
        TextView txtReturnLocation;
        TextView txtDepartDate;
        CardView cvSearch;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtDepartLocation = itemView.findViewById(R.id.txtHomepageSearchDepartLocation);
            txtReturnLocation = itemView.findViewById(R.id.txtHomepageSearchArrivalLocation);
            txtDepartDate = itemView.findViewById(R.id.txtHomepageSearchDepartDate);
            cvSearch = itemView.findViewById(R.id.cvSearch);
        }
    }
}
