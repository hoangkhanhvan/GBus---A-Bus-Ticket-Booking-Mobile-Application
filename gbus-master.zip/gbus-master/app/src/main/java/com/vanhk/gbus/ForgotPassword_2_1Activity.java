package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.chaos.view.PinView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ForgotPassword_2_1Activity extends AppCompatActivity {

    TextView txtForgotPassword21PhoneNumber, txtForgotPassword21CountDown;
    PinView pvForgotPassword21VerifyCode;
    Button btnForgotPassword21Resend;

    Toolbar toolbarBack;
    DatabaseReference myRef;
    private CountDownTimer countDownTimer;
    String TAG = "FIREBASE";

    ProgressDialog progressDialog; // Declare ProgressDialog

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password21);
        addViews();
        addEvents();

        startCountdown();
        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog

    }

    private void addEvents() {
        toolbarBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        btnForgotPassword21Resend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.setMessage("Sending OTP..."); // Set message for ProgressDialog
                progressDialog.show(); // Show ProgressDialog
                sendOTP();
                //60 giây
                startCountdown();
            }
        });
    }

    private void addViews() {
        txtForgotPassword21PhoneNumber = findViewById(R.id.txtForgotPassword21PhoneNumber);
        txtForgotPassword21CountDown = findViewById(R.id.txtForgotPassword21CountDown);
        pvForgotPassword21VerifyCode = findViewById(R.id.pvForgotPassword21VerifyCode);
        btnForgotPassword21Resend = findViewById(R.id.btnForgotPassword21Resend);
        toolbarBack = findViewById(R.id.toolbarBack);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("user");

        //Lấy sdt từ intent lên textview
        String account_phone_number = getIntent().getStringExtra("emailOrPhone");
        txtForgotPassword21PhoneNumber.setText(account_phone_number);

        sendOTP();
    }

    private void sendOTP() {
        String emailOrPhone = getIntent().getStringExtra("emailOrPhone");
        myRef.orderByChild("account_phone_number").equalTo(emailOrPhone).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                progressDialog.dismiss(); // Dismiss ProgressDialog

                if (snapshot.exists()) {
                    Toast.makeText(ForgotPassword_2_1Activity.this, "OTP sent successfully", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(ForgotPassword_2_1Activity.this, "Email or phone number not found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss(); // Dismiss ProgressDialog in case of error

                Toast.makeText(ForgotPassword_2_1Activity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void startCountdown() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        countDownTimer = new CountDownTimer(60000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                // Cập nhật đồng hồ đếm ngược
                txtForgotPassword21CountDown.setText((millisUntilFinished / 1000) + "s");
            }

            @Override
            public void onFinish() {
                // Hiển thị lại nút Resend khi đếm ngược kết thúc
                btnForgotPassword21Resend.setVisibility(View.VISIBLE);
            }
        }.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Hủy đếm ngược khi màn hình bị hủ
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }
}