package com.vanhk.gbus;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.Point2;
import com.vanhk.gbus.adapter.EditPoint;
import com.vanhk.gbus.model.Ticket;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class DropoffDeparture1Activity extends AppCompatActivity {

    // Declare variables for the views
    TextView txtDropoffDeparture1BusName;
    TextView txtDropOffDeparture1DepartLocation;
    TextView txtDropOffDeparture1ArrivalLocation;
    TextView txtDropOffDeparture1TagTripType;
    TextView DropOffDeparture1Date;
    TextView txtDropOffDeparture1PickUp;
    TextView txtDropOffDeparture1DropOff;
    TextView txtDropOffDeparture1Price;
    EditPoint pointAdapter;
    ListView lvDropOffDeparture1;
    Ticket selectedTicket;
    ArrayList<String> search;
    ProgressDialog progressDialog; // ProgressDialog instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dropoff_departure1);
        progressDialog = new ProgressDialog(this); // Initialize ProgressDialog
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.show(); // Show ProgressDialog
        addViews();
        loadData();
        // Find the ImageView by its ID
        ImageView imgDropOffDeparture1Back = findViewById(R.id.imgDropOffDeparture1Back);

        // Set an OnClickListener to handle the click event
        imgDropOffDeparture1Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Optional, to close the current activity after navigating
            }
        });

        // Set OnClickListener for "Continue" button
        Button btnContinue = findViewById(R.id.btnDropOffDeparture1Book);
        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Proceed to the next screen
                Point2 selectedPoint = pointAdapter.getSelectedPoint();

                if (selectedPoint == null) {
                    return;
                }

                Point2 p2 = MySharedPreferences.getObject(DropoffDeparture1Activity.this,"DPickUpPoint", Point2.class);
                Toast.makeText(DropoffDeparture1Activity.this, p2.getAddress(), Toast.LENGTH_SHORT).show();

                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                String RDate = sharedPreferences.getString("RDate","");
                String DDate = sharedPreferences.getString("DDate","");
                String DLocation = sharedPreferences.getString("DLocation","");
                String ALocation = sharedPreferences.getString("ALocation","");
                Toast.makeText(DropoffDeparture1Activity.this, RDate, Toast.LENGTH_SHORT).show();

                Intent intent;
                if (RDate.equals("Select Return Date")) {
                    MySharedPreferences.saveObject(DropoffDeparture1Activity.this, "DDropOffPoint", selectedPoint);
                    intent = new Intent(DropoffDeparture1Activity.this, PassengerInformationActivity.class);
                    startActivity(intent);
                } else {
                    ArrayList<String> searchItem = new ArrayList<>();
                    searchItem.add(ALocation);
                    searchItem.add(DLocation);
                    searchItem.add(RDate);
                    searchItem.add(DDate);

                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putBoolean("isReturn",true);
                    editor.apply();

                    boolean isReturn = sharedPreferences.getBoolean("isReturn",false);
                    boolean isReturnDone = sharedPreferences.getBoolean("isReturnDone",false);

                    if (!isReturn) {
                        Toast.makeText(DropoffDeparture1Activity.this, "Return", Toast.LENGTH_SHORT).show();
                        MySharedPreferences.saveObject(DropoffDeparture1Activity.this, "RDropOffPoint", selectedPoint);
                        intent = new Intent(DropoffDeparture1Activity.this, PassengerInformationActivity.class);
                    } else {
                        if (!isReturnDone) {

                            MySharedPreferences.saveObject(DropoffDeparture1Activity.this, "DDropOffPoint", selectedPoint);
                            intent = new Intent(DropoffDeparture1Activity.this, ResultList1Activity.class);
                            Toast.makeText(DropoffDeparture1Activity.this, searchItem.toString(), Toast.LENGTH_SHORT).show();
                            editor.putBoolean("isReturnDone",true);
                            editor.putBoolean("isReturn", true);
                            editor.putString("DLocation",ALocation);
                            editor.putString("ALocation",DLocation);
                            editor.putString("DDate",RDate);
                            editor.putString("RDate",DDate);
                            editor.apply();
                        } else {
                            MySharedPreferences.saveObject(DropoffDeparture1Activity.this, "RDropOffPoint", selectedPoint);
                            intent = new Intent(DropoffDeparture1Activity.this, PassengerInformationActivity.class);
                        }
                    }
                    intent.putStringArrayListExtra("search",search);
                    startActivity(intent);
                }

            }
        });
    }

    private void loadData() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("RouteWithPoints");
        ArrayList<Point2> count = new ArrayList<>();
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot data: dataSnapshot.getChildren()) {

                    String _id = data.child("_id").getValue(String.class);
                    if (_id.equals(selectedTicket.getRoute())) {
                        for (DataSnapshot points: data.child("DropOffPoints").getChildren()) {
                            Point2 point = new Point2();
                            Long time = points.child("Time").getValue(Long.class);
                            if (time != null) {
                                point.setPoint(points.child("Point").getValue(String.class));
                                point.setAddress(points.child("Address").getValue(String.class));
                                point.setShuttleBus(points.child("ShuttleBus").getValue(Boolean.class));
                                String timeStr = calculateTime(selectedTicket.getATime(),time.intValue());
                                point.setTime(timeStr);
                                String dateStr = calculateDate(selectedTicket.getDate(),selectedTicket.getATime(),time.intValue());
                                point.setDateStr(dateStr);
                                pointAdapter.add(point);
                                count.add(point);
                            }
                        }
                    }

                }
                progressDialog.dismiss(); // Dismiss the ProgressDialog after loading data
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e(TAG, "loadPost:onCancelled", databaseError.toException());
                progressDialog.dismiss(); // Dismiss the ProgressDialog in case of error
            }
        });
    }

    private void addViews() {
        txtDropoffDeparture1BusName = findViewById(R.id.txtDropOffDeparture1BusName);
        txtDropOffDeparture1DepartLocation = findViewById(R.id.txtDropOffDeparture1DepartLocation);
        txtDropOffDeparture1ArrivalLocation = findViewById(R.id.DropOffDeparture1ArrivalLocation);
        txtDropOffDeparture1TagTripType = findViewById(R.id.txtDropOffDeparture1TagTripType);
        DropOffDeparture1Date = findViewById(R.id.DropOffDeparture1Date);
        txtDropOffDeparture1PickUp = findViewById(R.id.txtDropOffDeparture1PickUp);
        txtDropOffDeparture1DropOff = findViewById(R.id.txtDropOffDeparture1DropOff);
        txtDropOffDeparture1Price = findViewById(R.id.txtDropOffDeparture1Price);
        lvDropOffDeparture1 = findViewById(R.id.lvDropOffDeparture1);

        Intent getIntent = getIntent();
        selectedTicket = (Ticket) getIntent.getSerializableExtra("ticket");

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String DLocation = sharedPreferences.getString("DLocation","");
        String ALocation = sharedPreferences.getString("ALocation","");
        String DDate = sharedPreferences.getString("DDate","");
        String RDate = sharedPreferences.getString("RDate","");
        txtDropoffDeparture1BusName.setText(selectedTicket.getBus());
        txtDropOffDeparture1DepartLocation.setText(DLocation);
        txtDropOffDeparture1ArrivalLocation.setText(ALocation);
        if (RDate.equals("Select Return Date")) {
            txtDropOffDeparture1TagTripType.setText("One Way Trip");
        } else {
            txtDropOffDeparture1TagTripType.setText("Round Trip");
        }
        DropOffDeparture1Date.setText(DDate);

        pointAdapter = new EditPoint(DropoffDeparture1Activity.this, R.layout.lv_editpickuppoint_depart1_shuttlebus_edt, new ArrayList<>());
        lvDropOffDeparture1.setAdapter(pointAdapter);

        int totalPrice = getIntent().getIntExtra("totalPrice", 0);
        txtDropOffDeparture1Price.setText(String.format("%,d VND", totalPrice));
    }


    public static String calculateDate(String dateString, String timeString, int minutesToAdd) {
        try {
            // Parse the input date and time strings
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(dateFormat.parse(dateString + " " + timeString));

            // Add the minutes
            calendar.add(Calendar.MINUTE, minutesToAdd);

            // Get the updated date
            SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd/MM");
            return outputDateFormat.format(calendar.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return null; // Return null if parsing fails
        }
    }


    public static String calculateTime(String timeString, int minutesToAdd) {
        // Split the time string into hours and minutes
        String[] parts = timeString.split(":");
        int hours = Integer.parseInt(parts[0]);
        int minutes = Integer.parseInt(parts[1]);

        // Convert time to minutes
        int totalMinutes = hours * 60 + minutes;

        // Add the minutes
        totalMinutes += minutesToAdd;

        // Adjust if the total minutes is negative
        if (totalMinutes < 0) {
            totalMinutes += 24 * 60; // Add 24 hours worth of minutes
        }

        // Calculate the new hours and minutes
        int newHours = totalMinutes / 60;
        int newMinutes = totalMinutes % 60;

        // Format the new time
        String newTimeString = String.format("%02d:%02d", newHours, newMinutes);
        return newTimeString;
    }
}
