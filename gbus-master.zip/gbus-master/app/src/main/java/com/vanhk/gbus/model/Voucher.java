package com.vanhk.gbus.model;

public class Voucher {
    private String condition;

    private int conditionValue;

    private String id;
    private String description;
    private String expired;
    private String percentage;
    private String image;
    private String time;

    // Constructors


    public Voucher(String condition, int conditionValue, String id, String description, String expired, String percentage, String image, String time) {
        this.condition = condition;
        this.conditionValue = conditionValue;
        this.id = id;
        this.description = description;
        this.expired = expired;
        this.percentage = percentage;
        this.image = image;
        this.time = time;
    }

    public Voucher() {
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public int getConditionValue() {
        return conditionValue;
    }

    public void setConditionValue(int conditionValue) {
        this.conditionValue = conditionValue;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getExpired() {
        return expired;
    }

    public void setExpired(String expired) {
        this.expired = expired;
    }

    public String getPercentage() {
        return percentage;
    }

    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
