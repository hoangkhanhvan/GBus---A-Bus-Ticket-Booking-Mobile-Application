package com.vanhk.gbus;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.PointAdapter;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.Point;
import com.vanhk.gbus.model.Ticket;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class TripDetails2Activity extends AppCompatActivity {
    ImageView imgTripDetails2Close;
    TextView txtTripDetails2DepartLocation,txtTripDetails2ArrivalLocation
            ,txtTripDetails2Tag,txtTripDetails2Date,txtTripDetails2PickupDropoff
            ,txtTripDetails2Amenities,txtTripDetails2BusFeatures,txtTripDetail2DropOffNumber;
    LinearLayout llTripDetails2Reviews,llTripDetails2PickUp,llTripDetails2DropOff;
    ListView lvTripDetails2;
    Button btnTripDetails2Book;
    PointAdapter pointAdapter;
    String TAG = "FIREBASE";
    Ticket selectedTicket;

    ArrayList<Point> pickUpPoints, dropOffPoints;

    // Declare ProgressDialog variable
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_details2);
        addViews();
        addEvents();

        // Initialize the progressDialog
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait..."); // Set message for the ProgressDialog
        progressDialog.setCancelable(false); // Make it not cancelable
    }

    private void addEvents() {
        llTripDetails2Reviews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TripDetails3Activity.class);
                startActivity(intent);
            }
        });
        txtTripDetails2Amenities.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TripDetails4Activity.class);
                startActivity(intent);
            }
        });
        txtTripDetails2BusFeatures.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TripDetails5Activity.class);
                startActivity(intent);
            }
        });
        imgTripDetails2Close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TripDetails2Activity.this,ResultList1Activity.class);
                startActivity(intent);
            }
        });
        btnTripDetails2Book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show the ProgressDialog when "Book" button is clicked
                progressDialog.show();

                Intent getIntent = getIntent();
                String accountId = getIntent.getStringExtra("accountId");

                Intent intent = new Intent(TripDetails2Activity.this, ChooseSeat_Depart_1Activity.class);

                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("departureTicketId", selectedTicket.get_id());
                editor.apply();

                ArrayList<String> search = getIntent.getStringArrayListExtra("search");

                intent.putExtra("ticket",selectedTicket);
                intent.putStringArrayListExtra("search",search);
                MySharedPreferences.saveObject(TripDetails2Activity.this, "DTicket", selectedTicket);
                boolean isReturn = sharedPreferences.getBoolean("isReturn",false);
                if (isReturn) {
                    MySharedPreferences.saveObject(TripDetails2Activity.this, "RTicket", selectedTicket);

                } else {
                    MySharedPreferences.saveObject(TripDetails2Activity.this, "DTicket", selectedTicket);

                }

                startActivity(intent);

                // Dismiss the ProgressDialog after starting the new activity
                progressDialog.dismiss();
            }
        });
        llTripDetails2PickUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(TripDetails2Activity.this,TripDetails1Activity.class);
                startActivity(intent);
            }
        });
    }

    private void addViews() {
        llTripDetails2Reviews=findViewById(R.id.llTripDetails2Reviews);
        llTripDetails2PickUp=findViewById(R.id.llTripDetails2PickUp);

        imgTripDetails2Close=findViewById(R.id.imgTripDetails2Close);
        txtTripDetails2DepartLocation=findViewById(R.id.txtTripDetails2DepartLocation);
        txtTripDetails2ArrivalLocation=findViewById(R.id.txtTripDetails2ArrivalLocation);
        txtTripDetails2Tag=findViewById(R.id.txtTripDetails2Tag);
        txtTripDetails2Date=findViewById(R.id.txtTripDetails2Date);
        txtTripDetails2PickupDropoff=findViewById(R.id.txtTripDetails2PickupDropoff);
        txtTripDetails2Amenities=findViewById(R.id.txtTripDetails2Amenities);
        txtTripDetails2BusFeatures=findViewById(R.id.txtTripDetails2BusFeatures);
        llTripDetails2Reviews=findViewById(R.id.llTripDetails2Reviews);
        llTripDetails2PickUp=findViewById(R.id.llTripDetails2PickUp);
        llTripDetails2DropOff=findViewById(R.id.llTripDetails2DropOff);
        lvTripDetails2=findViewById(R.id.lvTripDetails2);
        btnTripDetails2Book=findViewById(R.id.btnTripDetails2Book);
        pointAdapter = new PointAdapter(TripDetails2Activity.this,R.layout.lvtripdetails1pickuplocation);
        lvTripDetails2.setAdapter(pointAdapter);
        txtTripDetail2DropOffNumber=findViewById(R.id.txtTripDetail2DropOffNumber);
        loadData();
    }

    private void loadData() {
        selectedTicket = MySharedPreferences.getObject(TripDetails2Activity.this,"SelectedTicket",Ticket.class);

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String RouteId = sharedPreferences.getString("RouteId","");

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("RouteWithPoints");
        ArrayList<Point> count = new ArrayList<>();
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot data: dataSnapshot.getChildren()) {

                    String _id = data.child("_id").getValue(String.class);
                    if (_id.equals(RouteId)) {
                        for (DataSnapshot points: data.child("DropOffPoints").getChildren()) {
                            Point point = new Point();
                            Long time = points.child("Time").getValue(Long.class);
                            if (time != null) {
                                point.setPoint(points.child("Point").getValue(String.class));
                                point.setAddress(points.child("Address").getValue(String.class));
                                point.setShuttleBus(points.child("ShuttleBus").getValue(Boolean.class));
                                String timeStr = calculateTime(selectedTicket.getATime(),time.intValue());
                                point.setTime(timeStr);
                                String dateStr = calculateDate(selectedTicket.getDate(),selectedTicket.getATime(),time.intValue());
                                point.setDate(dateStr);
                                pointAdapter.add(point);
                                count.add(point);
                            }
                            txtTripDetail2DropOffNumber.setText("("+lvTripDetails2.getAdapter().getCount()+")");
                        }
                    }

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e(TAG, "loadPost:onCancelled", databaseError.toException());
            }
        });
    }
    public static String calculateDate(String dateString, String timeString, int minutesToAdd) {
        try {
            // Parse the input date and time strings
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(dateFormat.parse(dateString + " " + timeString));

            // Add the minutes
            calendar.add(Calendar.MINUTE, minutesToAdd);

            // Get the updated date
            SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd/MM");
            return outputDateFormat.format(calendar.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return null; // Return null if parsing fails
        }
    }


    public static String calculateTime(String timeString, int minutesToAdd) {
        // Split the time string into hours and minutes
        String[] parts = timeString.split(":");
        int hours = Integer.parseInt(parts[0]);
        int minutes = Integer.parseInt(parts[1]);

        // Add the minutes
        int totalMinutes = hours * 60 + minutes + minutesToAdd;

        // Calculate the new hours and minutes
        int newHours = totalMinutes / 60;
        int newMinutes = totalMinutes % 60;

        // Format the new time
        String newTimeString = String.format("%02d:%02d", newHours, newMinutes);
        return newTimeString;
    }
}