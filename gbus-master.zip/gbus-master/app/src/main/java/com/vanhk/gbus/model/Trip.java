package com.vanhk.gbus.model;

public class Trip {
    private String tripId;
    private int tripArrivalTime;
    private int tripDepartTime;
    private String tripDiscount;
    private String tripDropOffEnd;
    private String tripPickUpStart;
    private int tripPrice;
    private int tripSeatNumber;
    private  String tripBusType;

    public Trip(String tripId, int tripArrivalTime, int tripDepartTime, String tripDiscount, String tripDropOffEnd, String tripPickUpStart, int tripPrice, int tripSeatNumber, String tripBusType) {
        this.tripId = tripId;
        this.tripArrivalTime = tripArrivalTime;
        this.tripDepartTime = tripDepartTime;
        this.tripDiscount = tripDiscount;
        this.tripDropOffEnd = tripDropOffEnd;
        this.tripPickUpStart = tripPickUpStart;
        this.tripPrice = tripPrice;
        this.tripSeatNumber = tripSeatNumber;
        this.tripBusType = tripBusType;
    }

    public Trip() {
    }

    public String getTripId() {
        return tripId;
    }

    public void setTripId(String tripId) {
        this.tripId = tripId;
    }

    public int getTripArrivalTime() {
        return tripArrivalTime;
    }

    public void setTripArrivalTime(int tripArrivalTime) {
        this.tripArrivalTime = tripArrivalTime;
    }

    public int getTripDepartTime() {
        return tripDepartTime;
    }

    public void setTripDepartTime(int tripDepartTime) {
        this.tripDepartTime = tripDepartTime;
    }

    public String getTripDiscount() {
        return tripDiscount;
    }

    public void setTripDiscount(String tripDiscount) {
        this.tripDiscount = tripDiscount;
    }

    public String getTripDropOffEnd() {
        return tripDropOffEnd;
    }

    public void setTripDropOffEnd(String tripDropOffEnd) {
        this.tripDropOffEnd = tripDropOffEnd;
    }

    public String getTripPickUpStart() {
        return tripPickUpStart;
    }

    public void setTripPickUpStart(String tripPickUpStart) {
        this.tripPickUpStart = tripPickUpStart;
    }

    public int getTripPrice() {
        return tripPrice;
    }

    public void setTripPrice(int tripPrice) {
        this.tripPrice = tripPrice;
    }

    public int getTripSeatNumber() {
        return tripSeatNumber;
    }

    public void setTripSeatNumber(int tripSeatNumber) {
        this.tripSeatNumber = tripSeatNumber;
    }

    public String getTripBusType() {
        return tripBusType;
    }

    public void setTripBusType(String tripBusType) {
        this.tripBusType = tripBusType;
    }
}
