package com.vanhk.gbus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.vanhk.gbus.adapter.BusAdapter;
import com.vanhk.gbus.adapter.TicketAdapter;
import com.vanhk.gbus.adapter.TripAdapter;
import com.vanhk.gbus.model.Bus;
import com.vanhk.gbus.model.MySharedPreferences;
import com.vanhk.gbus.model.Ticket;
import com.vanhk.gbus.model.Trip;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

public class ResultList1Activity extends AppCompatActivity implements TicketAdapter.OnBookNowClickListener {
    ImageView imgResultList1Back;
    TextView txtResultList1DepartLocationTitle,txtResultList1ArrivalLocationTitle
            ,txtResultList1TripTypeTitle,txtResultList1DepartTimeTitle
            ,txtResultList1All,txtResultList1Latest,txtResultList1Ealiest
            ,txtResultList1Fastest,txtResultList1Cheapest;

    Button btnResultList1Filter,btnResultList1Sort,btnResultList1Time;
    ListView lvResultList1;

    LinearLayout llNoResultsLayout;

    TripAdapter tripAdapter;

    TicketAdapter ticketAdapter;

    String TAG = "FIREBASE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_list1);
        addViews();
        addEvents();
        addSortingOptions();
        loadData();

    }

    private void addSortingOptions() {
        txtResultList1All.setOnClickListener(view -> {
            // Reset any previous sorting and load all data
            resetSortingOptions();
            txtResultList1All.setBackground(ContextCompat.getDrawable(this,R.drawable.custom_txt_updateresultlist));
            txtResultList1All.setTextColor(Color.WHITE);
            loadData();
        });

        txtResultList1Latest.setOnClickListener(view -> {
            // Sort by latest departure time and reload data
            sortByLatestDepartureTime();
            resetSortingOptions();
            txtResultList1Latest.setBackground(ContextCompat.getDrawable(this,R.drawable.custom_txt_updateresultlist));
            txtResultList1Latest.setTextColor(Color.WHITE);
        });

        txtResultList1Ealiest.setOnClickListener(view -> {
            // Sort by earliest departure time and reload data
            sortByEarliestDepartureTime();
            resetSortingOptions();
            txtResultList1Ealiest.setBackground(ContextCompat.getDrawable(this,R.drawable.custom_txt_updateresultlist));
            txtResultList1Ealiest.setTextColor(Color.WHITE);
        });

        txtResultList1Fastest.setOnClickListener(view -> {
            // Sort by fastest duration and reload data
            sortByFastestDuration();
            resetSortingOptions();
            txtResultList1Fastest.setBackground(ContextCompat.getDrawable(this,R.drawable.custom_txt_updateresultlist));
            txtResultList1Fastest.setTextColor(Color.WHITE);
        });

        txtResultList1Cheapest.setOnClickListener(view -> {
            // Sort by cheapest price and reload data
            resetSortingOptions();
            txtResultList1Cheapest.setBackground(ContextCompat.getDrawable(this,R.drawable.custom_txt_updateresultlist));
            txtResultList1Cheapest.setTextColor(Color.WHITE);
            sortByCheapestPrice();
        });
    }

    private void resetSortingOptions() {
        txtResultList1All.setBackground(ContextCompat.getDrawable(this,R.drawable.custom_txt_updateresultlist2));
        txtResultList1All.setTextColor(Color.BLACK);

        txtResultList1Latest.setBackground(ContextCompat.getDrawable(this,R.drawable.custom_txt_updateresultlist2));
        txtResultList1Latest.setTextColor(Color.BLACK);

        txtResultList1Ealiest.setBackground(ContextCompat.getDrawable(this,R.drawable.custom_txt_updateresultlist2));
        txtResultList1Ealiest.setTextColor(Color.BLACK);

        txtResultList1Fastest.setBackground(ContextCompat.getDrawable(this,R.drawable.custom_txt_updateresultlist2));
        txtResultList1Fastest.setTextColor(Color.BLACK);

        txtResultList1Cheapest.setBackground(ContextCompat.getDrawable(this,R.drawable.custom_txt_updateresultlist2));
        txtResultList1Cheapest.setTextColor(Color.BLACK);
    }

    private void sortByCheapestPrice() {
        Collections.sort(ticketAdapter.getItems(), new Comparator<Ticket>() {
            @Override
            public int compare(Ticket ticket1, Ticket ticket2) {
                // Extract prices of tickets
                int price1 = ticket1.getPrice();
                int price2 = ticket2.getPrice();

                // Compare prices
                return Integer.compare(price1, price2); // Lower price means cheaper
            }
        });

        // Notify the adapter that data set has changed
        ticketAdapter.notifyDataSetChanged();
    }

    private void sortByFastestDuration() {
        // Method to sort items by fastest duration
            // Sort tickets by the fastest duration
            Collections.sort(ticketAdapter.getItems(), new Comparator<Ticket>() {
                @Override
                public int compare(Ticket ticket1, Ticket ticket2) {
                    // Extract departure and arrival times of tickets
                    String departTime1 = ticket1.getDTime();
                    String arrivalTime1 = ticket1.getATime();
                    String departTime2 = ticket2.getDTime();
                    String arrivalTime2 = ticket2.getATime();

                    // Calculate durations
                    long duration1 = calculateDuration(departTime1, arrivalTime1);
                    long duration2 = calculateDuration(departTime2, arrivalTime2);

                    // Compare durations
                    return Long.compare(duration1, duration2); // Lower duration means faster
                }
            });

            // Notify the adapter that data set has changed
            ticketAdapter.notifyDataSetChanged();
        }

    private long calculateDuration(String departTime1, String arrivalTime1) {
        SimpleDateFormat format = new SimpleDateFormat("HH:mm");
        try {
            Date startDate = format.parse(departTime1);
            Date endDate = format.parse(arrivalTime1);

            long difference = endDate.getTime() - startDate.getTime();
            if (difference < 0) {
                difference += 24 * 60 * 60 * 1000; // Add 24 hours in milliseconds
            }

            // Convert milliseconds to minutes
            return difference / (60 * 1000);

        } catch (ParseException e) {
            e.printStackTrace();
            return -1; // Handle parse exception
        }
    }

    private void sortByEarliestDepartureTime() {
        // This formatter can handle both "H:mm" and "HH:mm".
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("[H:mm][HH:mm]");
        try {
            ticketAdapter.getItems().sort((ticket1, ticket2) -> {
                LocalTime time1 = LocalTime.parse(ticket1.getDTime(), formatter);
                LocalTime time2 = LocalTime.parse(ticket2.getDTime(), formatter);
                return time1.compareTo(time2);
            });
            ticketAdapter.notifyDataSetChanged();
        } catch (DateTimeParseException e) {
            Log.e(TAG, "Error parsing time: " + e.getMessage());
        }
    }


    private void sortByLatestDepartureTime() {
        // This formatter can handle both "H:mm" and "HH:mm".
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("[H:mm][HH:mm]");
        try {
            ticketAdapter.getItems().sort((ticket1, ticket2) -> {
                LocalTime time1 = LocalTime.parse(ticket1.getDTime(), formatter);
                LocalTime time2 = LocalTime.parse(ticket2.getDTime(), formatter);
                return time2.compareTo(time1);
            });
            ticketAdapter.notifyDataSetChanged();
        } catch (DateTimeParseException e) {
            Log.e(TAG, "Error parsing time: " + e.getMessage());
        }
    }


    private void addEvents() {
        imgResultList1Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnResultList1Filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ResultList1Activity.this,ResultList2Activity.class);
                startActivity(intent);
            }
        });
        btnResultList1Sort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialogSort();
            }
        });
        btnResultList1Time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialogTime();
            }
        });

    }

    private void openDialogTime() {
        final Dialog dialog = new Dialog(ResultList1Activity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.activity_result_list6);

        Window window = dialog.getWindow();

        if (window == null) {
            return;
        }

        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        WindowManager.LayoutParams windowAttribute = window.getAttributes();
        windowAttribute.gravity = Gravity.CENTER;
        window.setAttributes(windowAttribute);

        dialog.setCancelable(true);

        LinearLayout layoutResultList6EarlyMorning = dialog.findViewById(R.id.layoutResultList6EarlyMorning);
        LinearLayout layoutResultList6Morning = dialog.findViewById(R.id.layoutResultList6Morning);
        LinearLayout layoutResultList6Afternoon = dialog.findViewById(R.id.layoutResultList6Afternoon);
        LinearLayout layoutResultList6Evening = dialog.findViewById(R.id.layoutResultList6Evening);

        RadioButton radResultList6Default = dialog.findViewById(R.id.radResultList6Default);
        RadioButton radResultList6Earliest = dialog.findViewById(R.id.radResultList6Earliest);
        RadioButton radResultList6Latest = dialog.findViewById(R.id.radResultList6Latest);

        ImageButton btnResultList6Close = dialog.findViewById(R.id.btnResultList6Close);

        // Click listener for Early Morning
        layoutResultList6EarlyMorning.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Sort tickets by departure time in the range 0:00 AM - 6:00 AM
                sortByDepartureTimeRange("0:00 AM", "6:00 AM");
                dialog.dismiss();
            }
        });

        // Click listener for Morning
        layoutResultList6Morning.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Sort tickets by departure time in the range 6:00 AM - 12:00 PM
                sortByDepartureTimeRange("6:00 AM", "12:00 PM");
                dialog.dismiss();
            }
        });

        // Click listener for Afternoon
        layoutResultList6Afternoon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Sort tickets by departure time in the range 12:00 PM - 6:00 PM
                sortByDepartureTimeRange("12:00 PM", "6:00 PM");
                dialog.dismiss();
            }
        });

        // Click listener for Evening
        layoutResultList6Evening.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Sort tickets by departure time in the range 6:00 PM - 12:00 AM
                sortByDepartureTimeRange("6:00 PM", "12:00 AM");
                dialog.dismiss();
            }
        });

        radResultList6Default.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    loadData();
                }
            }
        });

        radResultList6Earliest.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // Handle radResultList5Latest click
                    // For example, perform an action or load data accordingly
                    sortByEarliestDepartureTime();
                }
            }
        });

        radResultList6Latest.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // Handle radResultList5Latest click
                    // For example, perform an action or load data accordingly
                    sortByLatestDepartureTime();
                }
            }
        });



        btnResultList6Close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void sortByDepartureTimeRange(String startTime, String endTime) {
        // Sort tickets by departure time in the specified range
        Collections.sort(ticketAdapter.getItems(), new Comparator<Ticket>() {
            @Override
            public int compare(Ticket ticket1, Ticket ticket2) {
                // Extract departure times of tickets
                String departTime1 = ticket1.getDTime();
                String departTime2 = ticket2.getDTime();

                // Compare departure times based on their position in the specified range
                return compareDepartureTime(departTime1, departTime2, startTime, endTime);
            }
        });

        // Notify the adapter that data set has changed
        ticketAdapter.notifyDataSetChanged();
    }

    private int compareDepartureTime(String departTime1, String departTime2, String startTime, String endTime) {
        // Parse departure times to compare as numbers
        int hour1 = Integer.parseInt(departTime1.split(":")[0]);
        int hour2 = Integer.parseInt(departTime2.split(":")[0]);

        // Check if both times are within the specified range
        if (isBetween(departTime1, startTime, endTime) && isBetween(departTime2, startTime, endTime)) {
            // Compare departure times within the specified range
            return hour1 - hour2; // Lower hour means earlier departure
        } else {
            // Handle cases where one or both times are outside the specified range
            // Move times within the range to the end of the list
            if (isBetween(departTime1, startTime, endTime)) {
                return -1; // Move time1 to the end of the list
            } else if (isBetween(departTime2, startTime, endTime)) {
                return 1; // Move time2 to the end of the list
            } else {
                return 0; // No change in order if both times are outside the range
            }
        }
    }

    private boolean isBetween(String departTime1, String startTime, String endTime) {
        // Convert time to hours for comparison
        int hour = Integer.parseInt(departTime1.split(":")[0]);
        int startHour = Integer.parseInt(startTime.split(":")[0]);
        int endHour = Integer.parseInt(endTime.split(":")[0]);

        // Check if time falls within the specified range
        return hour >= startHour && hour < endHour;
    }

    private void openDialogSort() {
        final Dialog dialog = new Dialog(ResultList1Activity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.activity_result_list5);

        Window window = dialog.getWindow();

        if (window == null) {
            return;
        }

        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        WindowManager.LayoutParams windowAttribute = window.getAttributes();
        windowAttribute.gravity = Gravity.CENTER;
        window.setAttributes(windowAttribute);

        dialog.setCancelable(true);


        RadioButton radResultList5Default = dialog.findViewById(R.id.radResultList5Default);
        RadioButton radResultList5Earliest = dialog.findViewById(R.id.radResultList5Earliest);
        RadioButton radResultList5Latest = dialog.findViewById(R.id.radResultList5Latest);
        RadioButton radResultList5Most = dialog.findViewById(R.id.radResultList5Most);
        RadioButton radResultList5PriceDecreased = dialog.findViewById(R.id.radResultList5PriceDecreased);
        RadioButton radResultList5PriceIncreased = dialog.findViewById(R.id.radResultList5PriceIncreased);

        ImageButton btnResultList5Close = dialog.findViewById(R.id.btnResultList5Close);

        radResultList5Default.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    loadData();
                }
            }
        });

        radResultList5Earliest.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // Handle radResultList5Latest click
                    // For example, perform an action or load data accordingly
                    sortByEarliestDepartureTime();
                }
            }
        });

        radResultList5Latest.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // Handle radResultList5Latest click
                    // For example, perform an action or load data accordingly
                    sortByLatestDepartureTime();
                }
            }
        });

        radResultList5Most.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // Handle radResultList5Most click
                    // For example, perform an action or load data accordingly
                    sortByMostReviews();
                }
            }
        });

        radResultList5PriceDecreased.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // Handle radResultList5PriceDecreased click
                    // For example, perform an action or load data accordingly
                    sortByHighestPrice();
                }
            }
        });

        radResultList5PriceIncreased.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // Handle radResultList5PriceIncreased click
                    // For example, perform an action or load data accordingly
                    sortByCheapestPrice();
                }
            }
        });

        btnResultList5Close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();


    }

    private void sortByHighestPrice() {
        Collections.sort(ticketAdapter.getItems(), new Comparator<Ticket>() {
            @Override
            public int compare(Ticket ticket1, Ticket ticket2) {
                // Extract prices of tickets
                int price1 = ticket1.getPrice();
                int price2 = ticket2.getPrice();

                // Compare prices in reverse order
                return Integer.compare(price2, price1); // Higher price means more expensive
            }
        });

        // Notify the adapter that data set has changed
        ticketAdapter.notifyDataSetChanged();
    }

    private void sortByMostReviews() {
        Collections.sort(ticketAdapter.getItems(), new Comparator<Ticket>() {
            @Override
            public int compare(Ticket ticket1, Ticket ticket2) {
                // Extract number of reviews of tickets
                int reviewsCount1 = ticket1.getReviews().size();
                int reviewsCount2 = ticket2.getReviews().size();

                // Compare number of reviews in reverse order
                return Integer.compare(reviewsCount2, reviewsCount1); // Higher review count means more reviews
            }
        });

        // Notify the adapter that data set has changed
        ticketAdapter.notifyDataSetChanged();
    }

    private void addViews() {
        imgResultList1Back=findViewById(R.id.imgResultList1Back);
        txtResultList1ArrivalLocationTitle=findViewById(R.id.txtResultList1ArrivalLocationTitle);
        txtResultList1DepartLocationTitle=findViewById(R.id.txtResultList1DepartLocationTitle);
        txtResultList1TripTypeTitle=findViewById(R.id.txtResultList1TripTypeTitle);
        txtResultList1DepartTimeTitle=findViewById(R.id.txtResultList1DepartTimeTitle); // Corrected variable name here
        lvResultList1=findViewById(R.id.lvResultList1);
        lvResultList1.setDivider(null);
//        tripAdapter = new TripAdapter(ResultList1Activity.this,R.layout.result_list_1_items);
        ticketAdapter = new TicketAdapter(ResultList1Activity.this, R.layout.result_list_1_items);
        ticketAdapter.setOnBookNowClickListener(this);
        lvResultList1.setAdapter(ticketAdapter);
        llNoResultsLayout=findViewById(R.id.llNoResultsLayout);
        txtResultList1All=findViewById(R.id.txtResultList1All);
        txtResultList1Latest=findViewById(R.id.txtResultList1Latest);
        txtResultList1Ealiest=findViewById(R.id.txtResultList1Ealiest);
        txtResultList1Fastest=findViewById(R.id.txtResultList1Fastest);
        txtResultList1Cheapest=findViewById(R.id.txtResultList1Cheapest);
        btnResultList1Filter=findViewById(R.id.btnResultList1Filter);
        btnResultList1Sort=findViewById(R.id.btnResultList1Sort);
        btnResultList1Time=findViewById(R.id.btnResultList1Time);

        loadData();
    }

    private void loadData() {
        Intent intent = getIntent();
        ArrayList<String> search = new ArrayList<>();

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        String DLocation = sharedPreferences.getString("DLocation","");
        String ALocation = sharedPreferences.getString("ALocation","");
        String DDate = sharedPreferences.getString("DDate","");
        String RDate = sharedPreferences.getString("RDate","");

        search.add(DLocation);
        search.add(ALocation);
        search.add(DDate);
        search.add(RDate);

        ArrayList<String> _id = new ArrayList<>();

        txtResultList1DepartLocationTitle.setText(search.get(0));
        txtResultList1ArrivalLocationTitle.setText(search.get(1));
        if (search.get(3).equals("Select Return Date")) {
            txtResultList1TripTypeTitle.setText("One Way Trip");
        } else {
            txtResultList1TripTypeTitle.setText("Round Trip");
        }
        txtResultList1DepartTimeTitle.setText(search.get(2));


        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRoute = database.getReference("RouteWithPoints");
        myRoute.addValueEventListener(new ValueEventListener() {
            @Override            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot data : snapshot.getChildren()) {
                    String DLocation = data.child("DLocation").getValue(String.class);
                    String ALocation = data.child("ALocation").getValue(String.class);
                    if (DLocation!=null && DLocation.equals(search.get(0)) && ALocation != null && ALocation.equals(search.get(1))) {
                        _id.add(data.child("_id").getValue(String.class));
                        editor.putString("RouteId",data.child("_id").getValue(String.class));
                        editor.apply();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        DatabaseReference myRef = database.getReference("Tickets");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                boolean dataFound = false;
                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    String tripId = data.getKey();
                    assert tripId != null;
                    String route = data.child("Route").getValue(String.class);
                    String date = data.child("Date").getValue(String.class);
                    if (route != null && route.equals(_id.get(0)) && date != null && date.equals(search.get(2))) {
                        Long Price = data.child("Price").getValue(Long.class);
                        dataFound = true;
                        if (Price != null) {
                            String _id = data.child("_id").getValue(String.class);
                            String AOffice = data.child("AOffice").getValue(String.class);
                            String DOffice = data.child("DOffice").getValue(String.class);
                            String ATime = data.child("ATime").getValue(String.class);
                            String DTime = data.child("DTime").getValue(String.class);
                            String Bus = data.child("Bus").getValue(String.class);
                            String Date = data.child("Date").getValue(String.class);
                            String Image = data.child("Image").getValue(String.class);

                            ArrayList<String> Seat = new ArrayList<>();
                            ArrayList<String> Amenities = new ArrayList<>();
                            ArrayList<String> Reviews = new ArrayList<>();
                            ArrayList<String> Drivers = new ArrayList<>();
                            for (DataSnapshot amenities : data.child("Amenities").getChildren()) {
                                Amenities.add(amenities.getValue(String.class));
                            }
                            for (DataSnapshot amenities : data.child("Reviews").getChildren()) {
                                Reviews.add(amenities.getValue(String.class));
                            }
                            for (DataSnapshot amenities : data.child("Driver").getChildren()) {
                                Drivers.add(amenities.getValue(String.class));
                            }
                            for (DataSnapshot amenities : data.child("Seat").getChildren()) {
                                Seat.add(amenities.getValue(String.class));
                            }
                            Ticket ticket = new Ticket();
                            ticket.set_id(_id);
                            ticket.setAOffice(AOffice);
                            ticket.setDOffice(DOffice);
                            ticket.setATime(ATime);
                            ticket.setDTime(DTime);
                            ticket.setDate(Date);
                            ticket.setPrice(Price.intValue());
                            ticket.setDriver(Drivers);
                            ticket.setAmenities(Amenities);
                            ticket.setReviews(Reviews);
                            ticket.setRoute(route);
                            ticket.setSeat(Seat);
                            ticket.setImage(Image);
                            DatabaseReference myBus = database.getReference("Bus");
                            myBus.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    for (DataSnapshot data: snapshot.getChildren()) {
                                        String _id = data.child("_id").getValue(String.class);
                                        assert _id != null;
                                        if (_id.equals(Bus)) {
                                            String BusName = data.child("Name").getValue(String.class);
                                            String BusDes = data.child("Description").getValue(String.class);
                                            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                                            SharedPreferences.Editor editor = sharedPreferences.edit();
                                            editor.putString("BusDes",BusDes);
                                            editor.apply();
                                            ticket.setBus(BusName);
                                            ticketAdapter.add(ticket);
                                        }
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                        }
                    }
                }

                // Check if dataFound is false (no data found)
                if (!dataFound) {
                    // Set the visibility of the LinearLayout to VISIBLE
                    llNoResultsLayout.setVisibility(View.VISIBLE);
                    // Set the adapter of lvResultList1 to null
                    lvResultList1.setVisibility(View.GONE);
                } else {
                    // Set the visibility of the LinearLayout to GONE
                    llNoResultsLayout.setVisibility(View.GONE);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle errors
            }
        });

    }

    @Override
    public void onBookNowClick(int position) {
        Ticket selectedTicket = ticketAdapter.getItem(position);

        Intent getIntent = getIntent();
        String accountId = getIntent.getStringExtra("accountId");

        Intent intent = new Intent(ResultList1Activity.this, ChooseSeat_Depart_1Activity.class);

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("departureTicketId", selectedTicket.get_id());
        editor.apply();

        ArrayList<String> search = getIntent.getStringArrayListExtra("search");

        intent.putExtra("ticket",selectedTicket);
        intent.putStringArrayListExtra("search",search);
        boolean isReturn = sharedPreferences.getBoolean("isReturn",false);
        if (isReturn) {
            MySharedPreferences.saveObject(this, "RTicket", selectedTicket);
            Toast.makeText(this, selectedTicket.get_id(), Toast.LENGTH_SHORT).show();
        } else {
            MySharedPreferences.saveObject(this, "DTicket", selectedTicket);
            Toast.makeText(this, selectedTicket.get_id(), Toast.LENGTH_SHORT).show();
        }

        startActivity(intent);
    }
}